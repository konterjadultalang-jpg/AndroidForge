# Struk Printer 58mm

Cetak struk transfer BRImo ke printer thermal Bluetooth 58mm (format 32 kolom, ESC/POS),
dengan preview dan edit sebelum cetak.

## Cara pakai aplikasi
1. Pasangkan (pair) printer di Pengaturan Bluetooth HP.
2. Buka aplikasi, izinkan Bluetooth, pilih printer, isi nama toko.
3. Di BRImo: riwayat, Bagikan, pilih "Struk Printer" (atau pilih gambar dari galeri di aplikasi).
4. Periksa preview, perbaiki bila OCR salah baca, tekan Cetak.

## Cara membuat APK

### Opsi A: Android Studio
1. Install Android Studio, pilih File > Open, buka folder ini.
2. Tunggu Gradle sync selesai.
3. Menu Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/app-debug.apk

### Opsi B: GitHub Actions (tanpa install apa pun)
1. Buat repository GitHub baru, upload seluruh isi folder ini (termasuk folder .github).
2. Buka tab Actions, jalankan "Build APK" (otomatis jalan saat push).
3. Setelah selesai, unduh artifact "StrukPrinter-debug-apk" lalu ekstrak, kirim app-debug.apk ke HP.

Pasang APK di HP: izinkan "Install dari sumber tidak dikenal".
