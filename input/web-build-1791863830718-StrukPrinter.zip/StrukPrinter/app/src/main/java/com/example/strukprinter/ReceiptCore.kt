package com.example.strukprinter

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.UUID

// build.gradle (app):
//   implementation("com.google.mlkit:text-recognition:16.0.1")   // cek versi terbaru
// Manifest: BLUETOOTH_CONNECT + BLUETOOTH_SCAN (Android 12+), BLUETOOTH (Android 11 ke bawah)

/* ------------------------------------------------------------------ */
/* 1. Model data struk (diisi dari OCR, lalu bisa diedit di form)      */
/* ------------------------------------------------------------------ */
data class Receipt(
    val shopName: String = "NAMA TOKO",
    val date: String = "",          // 2026-10-11
    val time: String = "",          // 09:03:00
    val refCode: String = "",
    val bank: String = "BANK BRI",
    val accountNo: String = "",
    val recipient: String = "",
    val amount: Long = 0,
    val admin: Long = 0,
    val footerNote: String = "SALINAN",
    val thanks: String = "TERIMA KASIH",
    val terminalId: String = ""
) {
    val total: Long get() = amount + admin
}

/* ------------------------------------------------------------------ */
/* 2. Format teks 32 kolom (58mm, Font A 12x24 dot => 384 / 12 = 32)   */
/*    Preview dan cetak memakai daftar Line yang sama => hasil sama.   */
/* ------------------------------------------------------------------ */
const val COLS = 32

data class Line(val text: String, val bold: Boolean = false)

fun rp(n: Long) = "RP " + String.format(Locale.US, "%,d", n).replace(',', '.')

private fun center(s: String): String {
    val t = s.take(COLS)
    return " ".repeat((COLS - t.length) / 2) + t
}

/** Kiri-kanan: label di kiri, nilai rata kanan. */
private fun lr(left: String, right: String): String {
    val r = right.take(COLS - 1)
    val l = left.take(COLS - r.length - 1)
    return l + " ".repeat(COLS - l.length - r.length) + r
}

fun Receipt.toLines(): List<Line> = buildList<Line> {
    val eq = "=".repeat(COLS)
    val dash = "-".repeat(COLS)

    add(Line(center(shopName), bold = true))
    add(Line(eq))
    add(Line(lr("TANGGAL", date)))
    add(Line(lr("WAKTU", time)))
    add(Line(dash))
    add(Line(center("KODE REFERENSI")))
    add(Line(center(refCode), bold = true))
    add(Line(dash))
    add(Line(center("DATA PENERIMA"), bold = true))
    add(Line(lr("BANK TUJUAN", bank)))
    add(Line(lr("NO REKENING", accountNo)))
    add(Line(lr("PENERIMA", recipient.take(20))))
    add(Line(dash))
    add(Line(lr("NOMINAL", rp(amount))))
    add(Line(lr("ADMIN", rp(admin))))
    add(Line(eq))
    add(Line(lr("TOTAL", rp(total)), bold = true))
    add(Line(eq))
    add(Line(""))
    add(Line(dash))
    add(Line(center("** TRANSAKSI BERHASIL **"), bold = true))
    if (footerNote.isNotBlank()) add(Line(center(footerNote)))
    add(Line(center(thanks), bold = true))
    if (terminalId.isNotBlank()) add(Line(center("TID: $terminalId")))
}.map { it.copy(text = it.text.uppercase()) }

/* ------------------------------------------------------------------ */
/* 3. ESC/POS                                                          */
/* ------------------------------------------------------------------ */
object EscPos {
    private fun bold(on: Boolean) = byteArrayOf(0x1B, 0x45, (if (on) 1 else 0).toByte())

    fun build(lines: List<Line>): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))            // ESC @  : reset printer
        for (l in lines) {
            out.write(bold(l.bold))                    // ESC E n: bold on/off
            out.write((l.text + "\n").toByteArray(Charsets.US_ASCII))
        }
        out.write(bold(false))
        out.write(byteArrayOf(0x0A, 0x0A, 0x0A))       // feed 3 baris agar struk bisa disobek
        return out.toByteArray()
    }
}

/* ------------------------------------------------------------------ */
/* 4. Kirim ke printer Bluetooth Classic (SPP)                         */
/*    Panggil dari background thread (Dispatchers.IO), bukan main.     */
/* ------------------------------------------------------------------ */
@SuppressLint("MissingPermission")
fun printBluetooth(device: BluetoothDevice, data: ByteArray) {
    val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    device.createRfcommSocketToServiceRecord(sppUuid).use { socket ->
        socket.connect()
        socket.outputStream.apply { write(data); flush() }
        Thread.sleep(500) // beri waktu buffer printer sebelum socket ditutup
    }
}

/* ------------------------------------------------------------------ */
/* 5. OCR struk BRImo (gambar hasil Bagikan) -> Receipt                */
/* ------------------------------------------------------------------ */
fun recognizeText(bitmap: Bitmap, onDone: (String) -> Unit, onError: (Exception) -> Unit = {}) {
    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        .process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { onDone(it.text) }
        .addOnFailureListener(onError)
}

private val MONTHS = mapOf(
    "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5,
    "jun" to 6, "jul" to 7, "agu" to 8, "aug" to 8, "sep" to 9,
    "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12
)

private val RP = Regex("""\b[Rr][Pp]\s?([\dOo][\dOo.]*)""")

private fun String.toRupiah(): Long =
    replace('O', '0').replace('o', '0').filter { it.isDigit() }.toLongOrNull() ?: 0L

/**
 * Parser berdasarkan layout asli struk BRImo "Transfer Bank BRI":
 *   "11 Oktober 2026, 09:03:10 WIB" / Total Transaksi / No. Ref /
 *   Sumber Dana (pengirim, TIDAK dipakai) / Tujuan (inisial, nama, bank, no rek) /
 *   Nominal / Biaya Admin
 * Dibuat tahan terhadap urutan baris OCR yang kadang tertukar.
 * Jenis transaksi lain (BI-FAST, antarbank, dll) mungkin perlu penyesuaian.
 */
fun parseBrimo(text: String): Receipt {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }

    // Tanggal & jam
    val time = Regex("""\d{2}:\d{2}:\d{2}""").find(text)?.value.orEmpty()
    val date = Regex("""\b(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})""").find(text)?.let { m ->
        val (d, mon, y) = m.destructured
        val mm = MONTHS[mon.lowercase()] ?: return@let ""
        String.format(Locale.US, "%s-%02d-%02d", y, mm, d.toInt())
    }.orEmpty()

    // Nomor referensi (12 digit)
    val ref = Regex("""No\.?\s*Ref\D*(\d{8,})""", RegexOption.IGNORE_CASE)
        .find(text)?.groupValues?.get(1)
        ?: Regex("""\b\d{12}\b""").find(text)?.value.orEmpty()

    // Bagian "Tujuan": [inisial] nama / bank / no rekening
    val t = lines.indexOfFirst { it.equals("Tujuan", ignoreCase = true) }
    val after = if (t >= 0) lines.drop(t + 1) else emptyList()
    val recipient = after.firstOrNull {
        it.length > 3 && !it.startsWith("BANK", ignoreCase = true) && !it.first().isDigit()
    }.orEmpty()
    val bank = after.firstOrNull { it.startsWith("BANK", ignoreCase = true) } ?: "BANK BRI"
    val account = after.firstNotNullOfOrNull { l ->
        Regex("""\d[\d ]{7,}\d""").find(l)?.value?.filter(Char::isDigit)
    }.orEmpty()

    // Nominal: urutan Rp di struk = Total Transaksi, Nominal, Biaya Admin
    val amounts = RP.findAll(text).map { it.groupValues[1].toRupiah() }.toList()

    return Receipt(
        date = date,
        time = time,
        refCode = ref,
        bank = bank.uppercase(),
        accountNo = account,
        recipient = recipient,
        amount = amounts.getOrNull(1) ?: amounts.firstOrNull() ?: 0L,
        admin = amounts.getOrNull(2) ?: 0L
    )
}
