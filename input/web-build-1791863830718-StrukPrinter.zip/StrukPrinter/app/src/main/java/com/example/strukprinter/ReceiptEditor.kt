package com.example.strukprinter

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Preview kertas + form edit (state diangkat ke MainScreen).
 * Preview memakai Receipt.toLines() yang sama dengan yang dikirim ke printer.
 * Kolom data transaksi dipakai untuk memperbaiki salah baca OCR.
 */
@Composable
fun ReceiptEditor(r: Receipt, onChange: (Receipt) -> Unit) {
    Column {
        Column(
            Modifier
                .fillMaxWidth()
                .border(1.dp, Color.LightGray)
                .background(Color.White)
                .horizontalScroll(rememberScrollState())
                .padding(12.dp)
        ) {
            r.toLines().forEach { l ->
                Text(
                    text = l.text.ifEmpty { " " },
                    color = Color.Black,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    softWrap = false,
                    fontWeight = if (l.bold) FontWeight.Bold else FontWeight.Normal
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        Field("Tanggal (yyyy-MM-dd)", r.date) { onChange(r.copy(date = it)) }
        Field("Waktu (HH:mm:ss)", r.time) { onChange(r.copy(time = it)) }
        Field("Kode referensi", r.refCode) { onChange(r.copy(refCode = it)) }
        Field("Bank tujuan", r.bank) { onChange(r.copy(bank = it)) }
        Field("No rekening", r.accountNo) { onChange(r.copy(accountNo = it)) }
        Field("Penerima", r.recipient) { onChange(r.copy(recipient = it)) }
        Field("Nominal", r.amount.toString()) {
            onChange(r.copy(amount = it.filter(Char::isDigit).toLongOrNull() ?: 0L))
        }
        Field("Admin", r.admin.toString()) {
            onChange(r.copy(admin = it.filter(Char::isDigit).toLongOrNull() ?: 0L))
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    )
}
