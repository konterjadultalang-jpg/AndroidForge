package com.example.strukprinter

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun MainScreen(sharedUri: MutableState<Uri?>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("struk", Context.MODE_PRIVATE) }

    var shop by remember { mutableStateOf(prefs.getString("shop", "NAMA TOKO") ?: "") }
    var footer by remember { mutableStateOf(prefs.getString("footer", "SALINAN") ?: "") }
    var tid by remember { mutableStateOf(prefs.getString("tid", "") ?: "") }
    var mac by remember { mutableStateOf(prefs.getString("mac", "") ?: "") }

    var receipt by remember { mutableStateOf<Receipt?>(null) }
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    var hasBt by remember { mutableStateOf(hasBtPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasBt = granted }

    var devices by remember { mutableStateOf(emptyList<BluetoothDevice>()) }
    LaunchedEffect(hasBt) { devices = pairedPrinters(ctx) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) sharedUri.value = uri }

    // Struk masuk (dari menu Bagikan atau tombol pilih gambar) -> OCR -> parse
    LaunchedEffect(sharedUri.value) {
        val uri = sharedUri.value ?: return@LaunchedEffect
        busy = true
        status = "Membaca struk..."
        try {
            val text = withContext(Dispatchers.Default) {
                val bmp = loadBitmap(ctx, uri) ?: error("Gambar tidak bisa dibuka")
                ocrText(bmp)
            }
            val p = parseBrimo(text)
            receipt = p.copy(shopName = shop, footerNote = footer, terminalId = tid)
            status = if (p.refCode.isEmpty() || p.amount == 0L)
                "Sebagian data tidak terbaca. Periksa dan perbaiki di bawah."
            else ""
        } catch (e: Exception) {
            status = "Gagal membaca struk: ${e.message}"
        }
        busy = false
        sharedUri.value = null
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Struk Printer 58mm", style = MaterialTheme.typography.titleLarge)
        Text(
            "Buka BRImo, pilih riwayat, tekan Bagikan, lalu pilih aplikasi ini. " +
                "Atau pilih gambar struk dari galeri.",
            style = MaterialTheme.typography.bodySmall
        )

        Spacer(Modifier.height(16.dp))
        Text("Printer Bluetooth", style = MaterialTheme.typography.titleMedium)
        if (!hasBt) {
            Button(onClick = { permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }) {
                Text("Izinkan akses Bluetooth")
            }
        } else {
            if (devices.isEmpty()) {
                Text(
                    "Belum ada printer yang dipasangkan. Pasangkan dulu di " +
                        "Pengaturan Bluetooth HP, lalu tekan Muat ulang.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
            devices.forEach { d ->
                val select = {
                    mac = d.address
                    prefs.edit().putString("mac", d.address).apply()
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { select() },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = d.address == mac, onClick = { select() })
                    Text(deviceLabel(d))
                }
            }
            OutlinedButton(onClick = { devices = pairedPrinters(ctx) }) { Text("Muat ulang") }
        }

        Spacer(Modifier.height(16.dp))
        Text("Pengaturan struk", style = MaterialTheme.typography.titleMedium)
        Field("Nama toko", shop) {
            shop = it
            prefs.edit().putString("shop", it).apply()
            receipt = receipt?.copy(shopName = it)
        }
        Field("Catatan footer (mis. SALINAN)", footer) {
            footer = it
            prefs.edit().putString("footer", it).apply()
            receipt = receipt?.copy(footerNote = it)
        }
        Field("TID (opsional)", tid) {
            tid = it
            prefs.edit().putString("tid", it).apply()
            receipt = receipt?.copy(terminalId = it)
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { picker.launch("image/*") },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Pilih gambar struk BRImo") }

        if (status.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(status)
        }

        receipt?.let { r ->
            Spacer(Modifier.height(16.dp))
            Text("Preview", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            ReceiptEditor(r) { receipt = it }
            Spacer(Modifier.height(8.dp))
            Button(
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
                onClick = {
                    val dev = if (mac.isEmpty()) null else deviceByMac(ctx, mac)
                    if (!hasBt) {
                        status = "Izinkan akses Bluetooth dulu."
                    } else if (dev == null) {
                        status = "Pilih printer dulu."
                    } else {
                        scope.launch {
                            busy = true
                            status = "Mencetak..."
                            status = withContext(Dispatchers.IO) {
                                try {
                                    printBluetooth(dev, EscPos.build(r.toLines()))
                                    "Selesai dicetak."
                                } catch (e: Exception) {
                                    "Gagal mencetak: ${e.message}"
                                }
                            }
                            busy = false
                        }
                    }
                }
            ) { Text("Cetak") }
        }
    }
}
