package com.aquaphone.strukprinter

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var title: TextView
    private lateinit var admin: EditText
    private lateinit var preview: EditText
    private var data: Map<String, String> = emptyMap()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        title = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD) }
        admin = EditText(this).apply { hint = "Biaya admin (Rp)"; inputType = InputType.TYPE_CLASS_NUMBER }
        preview = EditText(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f; gravity = Gravity.TOP; hint = "Bagikan riwayat BRImo ke aplikasi ini" }
        val print = Button(this).apply { text = "Cetak"; setOnClickListener { doPrint() } }
        val set = Button(this).apply { text = "Pengaturan"; setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } }
        root.addView(title); root.addView(admin); root.addView(preview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(print); root.addView(set)
        setContentView(root)
        admin.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { rebuild() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onResume() { super.onResume(); title.text = prefs.getString("name", "NAMA TOKO") }

    private fun handle(i: Intent) {
        val t = if (i.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT) else null
        if (t.isNullOrBlank()) return
        data = Receipt.parse(t)
        val fee = data["Biaya Admin"]?.let { Receipt.num(it) } ?: prefs.getLong("admin", 0)
        admin.setText(fee.toString())
        rebuild()
    }

    private fun rebuild() {
        if (data.isEmpty()) return
        preview.setText(Receipt.body(data, Receipt.num(admin.text.toString())))
    }

    private fun doPrint() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != 0) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return
        }
        val addr = prefs.getString("addr", null)
        if (addr == null) { toast("Pilih printer di Pengaturan"); return }
        val name = prefs.getString("name", "NAMA TOKO")!!
        val desc = prefs.getString("desc", "")!!
        val text = preview.text.toString()
        Thread {
            try { Printer.print(addr, name, desc, text); runOnUiThread { toast("Selesai dicetak") } }
            catch (e: Exception) { runOnUiThread { toast("Gagal: ${e.message}") } }
        }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
