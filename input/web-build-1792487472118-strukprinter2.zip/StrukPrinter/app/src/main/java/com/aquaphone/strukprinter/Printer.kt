package com.aquaphone.strukprinter

import android.bluetooth.BluetoothAdapter
import java.util.UUID

object Printer {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val cs = Charsets.ISO_8859_1

    fun print(addr: String, name: String, desc: String, body: String) {
        val dev = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr)
        val s = dev.createRfcommSocketToServiceRecord(SPP)
        s.connect()
        s.outputStream.use { o ->
            fun w(vararg b: Int) = o.write(ByteArray(b.size) { b[it].toByte() })
            fun t(x: String) = o.write(x.toByteArray(cs))
            w(0x1B, 0x40)
            w(0x1B, 0x61, 1); w(0x1D, 0x21, 0x11)
            t(name.uppercase().chunked(16).joinToString("\n") + "\n")
            w(0x1D, 0x21, 0x00)
            if (desc.isNotBlank()) t(Receipt.center(desc) + "\n")
            w(0x1B, 0x61, 0)
            t(body)
            w(0x1B, 0x64, 4)
            o.flush(); Thread.sleep(800)
        }
        s.close()
    }
}
