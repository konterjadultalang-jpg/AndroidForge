package com.aquaphone.strukprinter

object Receipt {
    const val W = 32
    private val keys = listOf("Tanggal", "No. Ref", "Jenis Transaksi", "Sumber Dana", "Bank Tujuan",
        "No. Rekening", "Nama Tujuan", "Tujuan", "Keterangan", "Nominal", "Biaya Admin", "Total")

    fun parse(t: String): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < ls.size) {
            val k = keys.firstOrNull { ls[i].startsWith(it, true) }
            if (k != null) {
                var v = ls[i].substring(k.length).trimStart(':', ' ', '\t')
                if (v.isEmpty() && i + 1 < ls.size && keys.none { ls[i + 1].startsWith(it, true) }) v = ls[++i]
                if (!m.containsKey(k)) m[k] = v
            }
            i++
        }
        return m
    }

    fun num(s: String?): Long = s?.substringBefore(',')?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
    fun rp(n: Long) = "Rp" + n.toString().reversed().chunked(3).joinToString(".").reversed()
    fun center(s: String, w: Int = W) = s.chunked(w).joinToString("\n") { " ".repeat(((w - it.length) / 2).coerceAtLeast(0)) + it }
    private fun line(k: String, v: String) =
        if (k.length + v.length + 1 <= W) k + " ".repeat(W - k.length - v.length) + v
        else k + "\n" + v.chunked(W).joinToString("\n")

    fun body(d: Map<String, String>, admin: Long): String {
        val sb = StringBuilder()
        val bar = "-".repeat(W)
        sb.appendLine(bar)
        for (k in keys.take(8)) d[k]?.takeIf { it.isNotBlank() }?.let { sb.appendLine(line(k, it)) }
        d["Keterangan"]?.takeIf { it.isNotBlank() }?.let {
            sb.appendLine("Keterangan")
            it.split("|").map { p -> p.trim() }.filter { p -> p.isNotEmpty() }.forEach { p -> sb.appendLine(p.chunked(W).joinToString("\n")) }
        }
        sb.appendLine(bar)
        val nom = num(d["Nominal"])
        sb.appendLine(line("Nominal", rp(nom)))
        sb.appendLine(line("Biaya Admin", rp(admin)))
        sb.appendLine(line("Total", rp(nom + admin)))
        sb.appendLine(bar)
        sb.appendLine(center("TRANSAKSI BERHASIL"))
        return sb.toString()
    }
}
