package com.aquaphone.strukprinter

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var title: TextView
    private lateinit var admin: EditText
    private lateinit var preview: EditText
    private lateinit var frame: FrameLayout
    private lateinit var beam: View
    private var data: Map<String, String> = emptyMap()
    private var fromShare = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        title = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER; setTypeface(null, Typeface.BOLD) }
        admin = EditText(this).apply { hint = "Biaya admin (Rp)"; inputType = InputType.TYPE_CLASS_NUMBER }
        preview = EditText(this).apply { typeface = Typeface.MONOSPACE; textSize = 13f; gravity = Gravity.TOP; hint = "Buka riwayat BRImo atau bagikan ke aplikasi ini" }
        beam = View(this).apply {
            visibility = View.GONE
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x0000E5FF, 0xAA00E5FF.toInt(), 0x0000E5FF))
        }
        frame = FrameLayout(this).apply {
            addView(preview, FrameLayout.LayoutParams(-1, -1))
            addView(beam, FrameLayout.LayoutParams(-1, 160))
        }
        val print = Button(this).apply { text = "Cetak"; setOnClickListener { doPrint() } }
        val set = Button(this).apply { text = "Pengaturan"; setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) } }
        root.addView(title); root.addView(admin); root.addView(frame, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(print); root.addView(set)
        setContentView(root)
        admin.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { rebuild() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        scan()
        handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onResume() { super.onResume(); title.text = prefs.getString("name", "NAMA TOKO") }

    // Animasi cahaya memindai dari atas ke bawah
    private fun scan() {
        frame.post {
            beam.visibility = View.VISIBLE
            ObjectAnimator.ofFloat(beam, "translationY", -160f, frame.height.toFloat()).apply {
                duration = 1300; repeatCount = 1; interpolator = LinearInterpolator()
                addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { beam.visibility = View.GONE } })
                start()
            }
        }
    }

    private fun handle(i: Intent) {
        if (i.action != Intent.ACTION_SEND) return
        fromShare = true
        val t = i.getStringExtra(Intent.EXTRA_TEXT)
        if (!t.isNullOrBlank()) { apply(t); return }
        @Suppress("DEPRECATION") val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        scan(); toast("Membaca struk...")
        Thread {
            try { recognize(loadBitmap(u)) }
            catch (e: Exception) { runOnUiThread { toast("Gagal baca: ${e.message}") } }
        }.start()
    }

    private fun apply(t: String) {
        data = Receipt.parse(t)
        if (data.isEmpty()) { preview.setText(t); scan(); return }
        val fee = data["Biaya Admin"]?.let { Receipt.num(it) } ?: prefs.getLong("admin", 0)
        admin.setText(fee.toString())
        rebuild(); scan()
    }

    private fun loadBitmap(u: Uri): Bitmap {
        if (contentResolver.getType(u) == "application/pdf") {
            val fd = contentResolver.openFileDescriptor(u, "r")!!
            val r = PdfRenderer(fd); val pg = r.openPage(0)
            val bmp = Bitmap.createBitmap(pg.width * 2, pg.height * 2, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            pg.close(); r.close(); fd.close()
            return bmp
        }
        return contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it) }
    }

    // OCR: gabungkan teks sebaris (label kiri + nilai kanan) jadi satu baris
    private fun recognize(bmp: Bitmap) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val ls = res.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }.sortedBy { it.boundingBox!!.centerY() }
                val rows = ArrayList<MutableList<com.google.mlkit.vision.text.Text.Line>>()
                for (l in ls) {
                    val last = rows.lastOrNull()
                    if (last != null && Math.abs(last[0].boundingBox!!.centerY() - l.boundingBox!!.centerY()) < l.boundingBox!!.height() * 0.6) last.add(l)
                    else rows.add(mutableListOf(l))
                }
                val text = rows.joinToString("\n") { r -> r.sortedBy { it.boundingBox!!.left }.joinToString(" ") { it.text } }
                runOnUiThread { apply(text) }
            }
            .addOnFailureListener { runOnUiThread { toast("OCR gagal: ${it.message}") } }
    }

    private fun rebuild() {
        if (data.isEmpty()) return
        preview.setText(Receipt.body(data, Receipt.num(admin.text.toString())))
    }

    private fun doPrint() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != 0) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return
        }
        val addr = prefs.getString("addr", null)
        if (addr == null) { toast("Pilih printer di Pengaturan"); return }
        val name = prefs.getString("name", "NAMA TOKO")!!
        val desc = prefs.getString("desc", "")!!
        val text = preview.text.toString()
        Thread {
            try {
                Printer.print(addr, name, desc, text)
                runOnUiThread { toast("Selesai dicetak"); if (fromShare) finish() }
            } catch (e: Exception) { runOnUiThread { toast("Gagal: ${e.message}") } }
        }.start()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
