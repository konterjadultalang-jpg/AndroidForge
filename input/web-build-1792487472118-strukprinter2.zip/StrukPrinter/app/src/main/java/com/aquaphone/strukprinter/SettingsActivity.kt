package com.aquaphone.strukprinter

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var name: EditText
    private lateinit var desc: EditText
    private lateinit var fee: EditText
    private lateinit var pr: Button

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        name = EditText(this).apply { hint = "Nama toko"; setText(prefs.getString("name", "NAMA TOKO")) }
        desc = EditText(this).apply { hint = "Deskripsi toko"; setText(prefs.getString("desc", "")); minLines = 3 }
        fee = EditText(this).apply { hint = "Biaya admin default"; inputType = InputType.TYPE_CLASS_NUMBER; setText(prefs.getLong("admin", 0).toString()) }
        pr = Button(this).apply { text = "Printer: " + (prefs.getString("pname", "belum dipilih")); setOnClickListener { pick() } }
        listOf(name, desc, fee, pr).forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pick() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != 0) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return
        }
        val devs = BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList()
        AlertDialog.Builder(this).setTitle("Pilih printer (pair dulu di Bluetooth HP)")
            .setItems(devs.map { it.name ?: it.address }.toTypedArray()) { _, i ->
                prefs.edit().putString("addr", devs[i].address).putString("pname", devs[i].name).apply()
                pr.text = "Printer: ${devs[i].name}"
            }.show()
    }

    override fun onPause() {
        super.onPause()
        prefs.edit().putString("name", name.text.toString()).putString("desc", desc.text.toString())
            .putLong("admin", fee.text.toString().toLongOrNull() ?: 0).apply()
    }
}
