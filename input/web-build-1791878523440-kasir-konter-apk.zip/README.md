# Kasir Konter (APK)

Cara membuat APK lewat GitHub:

1. Ekstrak zip ini, lalu buat repository baru di GitHub (boleh private).
2. Unggah SEMUA isi folder ke repository, termasuk folder `.github` (folder tersembunyi, pastikan ikut terunggah).
3. Buka tab **Actions**. Proses "Build APK" jalan otomatis, tunggu sekitar 5-10 menit sampai centang hijau.
   Kalau tidak jalan sendiri: Actions > Build APK > Run workflow.
4. Buka proses yang selesai, turun ke bagian **Artifacts**, unduh `kasir-konter-apk` (berupa zip), ekstrak, lalu salin `app-debug.apk` ke HP.
5. Di HP, buka file APK dan izinkan "Pasang dari sumber ini" jika diminta.

Catatan:
- Data tersimpan di HP itu saja. Menghapus aplikasi menghapus datanya, jadi rutin tekan **Backup** di tab Laporan.
- Tombol Backup membuka menu bagikan, pilih "Simpan ke File/Drive" atau kirim ke WhatsApp sendiri.
- Memperbarui aplikasi: ganti `www/index.html` lalu unggah ulang, APK baru dibuat otomatis. Pasang di atas yang lama agar data tetap ada (tanpa uninstall).
- APK ini bertanda tangan debug, cukup untuk dipakai sendiri tapi tidak untuk Play Store.
