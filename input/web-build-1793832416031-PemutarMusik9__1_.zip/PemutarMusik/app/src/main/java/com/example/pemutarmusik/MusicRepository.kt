package com.example.pemutarmusik

import android.app.RecoverableSecurityException
import android.content.ContentUris
import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val fileName: String,
    val path: String,
    val dateAddedSec: Long,
    val uri: Uri,
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .setAlbumTitle(album)
                .build()
        )
        .build()
}

sealed interface DeleteOutcome {
    data object Done : DeleteOutcome
    data object Failed : DeleteOutcome
    class NeedsUser(val sender: IntentSender) : DeleteOutcome
}

object MusicRepository {

    /** Ambil semua file MP3 di penyimpanan lewat MediaStore. Panggil dari thread background. */
    @Suppress("DEPRECATION")
    fun loadMp3(context: Context): List<Song> {
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            Media.EXTERNAL_CONTENT_URI
        }
        val pathColumn = if (Build.VERSION.SDK_INT >= 29) Media.RELATIVE_PATH else Media.DATA
        val projection = arrayOf(
            Media._ID, Media.TITLE, Media.ARTIST, Media.ALBUM, Media.DURATION,
            Media.SIZE, Media.DISPLAY_NAME, Media.DATE_ADDED, pathColumn,
        )

        // Durasi >= 10 detik: menyaring nada dering / suara notifikasi pendek.
        val selection = "(${Media.MIME_TYPE} = ? OR ${Media.DISPLAY_NAME} LIKE ?) AND ${Media.DURATION} >= 10000"
        val args = arrayOf("audio/mpeg", "%.mp3")

        val songs = mutableListOf<Song>()
        context.contentResolver.query(
            collection, projection, selection, args, "${Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(Media._ID)
            val titleCol = c.getColumnIndexOrThrow(Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(Media.ARTIST)
            val albumCol = c.getColumnIndexOrThrow(Media.ALBUM)
            val durCol = c.getColumnIndexOrThrow(Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(Media.SIZE)
            val nameCol = c.getColumnIndexOrThrow(Media.DISPLAY_NAME)
            val dateCol = c.getColumnIndexOrThrow(Media.DATE_ADDED)
            val pathCol = c.getColumnIndexOrThrow(pathColumn)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val artist = c.getString(artistCol)
                val album = c.getString(albumCol)
                songs += Song(
                    id = id,
                    title = c.getString(titleCol) ?: "Tanpa judul",
                    artist = if (artist.isNullOrBlank() || artist == "<unknown>") "Tidak diketahui" else artist,
                    album = if (album.isNullOrBlank() || album == "<unknown>") "Tidak diketahui" else album,
                    durationMs = c.getLong(durCol),
                    sizeBytes = c.getLong(sizeCol),
                    fileName = c.getString(nameCol) ?: "",
                    path = c.getString(pathCol) ?: "",
                    dateAddedSec = c.getLong(dateCol),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                )
            }
        }
        return songs
    }

    /**
     * Hapus file lagu dari HP.
     * Android 11+: sistem menampilkan dialog konfirmasi sendiri (NeedsUser).
     * Android 10: bisa meminta izin lewat RecoverableSecurityException.
     * Android 9 ke bawah: langsung hapus (butuh izin tulis penyimpanan).
     */
    fun deleteSong(context: Context, song: Song): DeleteOutcome {
        val cr = context.contentResolver
        return try {
            if (Build.VERSION.SDK_INT >= 30) {
                DeleteOutcome.NeedsUser(MediaStore.createDeleteRequest(cr, listOf(song.uri)).intentSender)
            } else if (cr.delete(song.uri, null, null) > 0) {
                DeleteOutcome.Done
            } else {
                DeleteOutcome.Failed
            }
        } catch (e: SecurityException) {
            if (Build.VERSION.SDK_INT >= 29 && e is RecoverableSecurityException) {
                DeleteOutcome.NeedsUser(e.userAction.actionIntent.intentSender)
            } else {
                DeleteOutcome.Failed
            }
        }
    }

    /** Android 10: setelah pengguna memberi izin, hapus perlu diulang. */
    fun deleteAgain(context: Context, song: Song) {
        runCatching { context.contentResolver.delete(song.uri, null, null) }
    }
}
