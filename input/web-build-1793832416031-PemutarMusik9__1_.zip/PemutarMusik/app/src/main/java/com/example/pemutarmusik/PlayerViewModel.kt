package com.example.pemutarmusik

import android.app.Application
import android.content.ComponentName
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlayerUi(
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
    val shuffle: Boolean = false,
    val repeatMode: Int = Player.REPEAT_MODE_ALL,   // OFF / ALL / ONE
    val volume: Float = 1f,
) {
    /** Status transport: main (isPlaying) / jeda (posisi > 0) / henti (posisi 0). Dipakai untuk menyalakan ikon tombol. */
    val isPaused: Boolean get() = !isPlaying && positionMs > 0L
    val isStopped: Boolean get() = !isPlaying && positionMs <= 0L
}

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private val _albums = MutableStateFlow(AlbumStore.load(app))
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()

    private var controller: MediaController? = null
    private var pendingDelete: Song? = null

    init {
        connectToService()
        viewModelScope.launch {
            while (true) {
                delay(250)
                val c = controller ?: continue
                if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition) }
            }
        }
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = syncFromPlayer()
                })
                syncFromPlayer()
            } catch (e: Exception) {
                // Gagal konek ke service: pemutar tidak tersedia
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun syncFromPlayer() {
        val c = controller ?: return
        val item = c.currentMediaItem
        _ui.value = PlayerUi(
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString(),
            artist = item?.mediaMetadata?.artist?.toString(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
            shuffle = c.shuffleModeEnabled,
            repeatMode = c.repeatMode,
            volume = c.volume,
        )
    }

    // ------------------------------------------------------------------ lagu

    fun loadSongs() {
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { MusicRepository.loadMp3(getApplication()) }
            } catch (e: SecurityException) {
                emptyList()
            }
            _songs.value = list
            _loaded.value = true
        }
    }

    /** Putar [song] dengan antrean = [list] (urutan album atau semua lagu). */
    fun playList(list: List<Song>, song: Song) {
        val c = controller ?: return
        val index = list.indexOfFirst { it.id == song.id }
        if (index < 0) return
        c.setMediaItems(list.map { it.toMediaItem() }, index, 0L)
        c.prepare()
        c.play()
    }

    fun play() {
        val c = controller ?: return
        if (c.currentMediaItem == null) {
            val all = _songs.value
            all.firstOrNull()?.let { playList(all, it) }
        } else {
            c.play()
        }
    }

    fun pause() {
        controller?.pause()
    }

    fun stop() {
        val c = controller ?: return
        c.pause()
        c.seekTo(0L)
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    fun toggleShuffle() {
        val c = controller ?: return
        c.shuffleModeEnabled = !c.shuffleModeEnabled
    }

    /** Siklus: OFF -> ULANG SEMUA -> ULANG 1 LAGU -> OFF. */
    fun toggleRepeat() {
        val c = controller ?: return
        c.repeatMode = when (c.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setVolume(v: Float) {
        val c = controller ?: return
        c.volume = v.coerceIn(0f, 1f)
        _ui.update { it.copy(volume = c.volume) }
    }

    // ------------------------------------------------------------------ album

    private fun mutateAlbums(block: (List<Album>) -> List<Album>) {
        val next = block(_albums.value)
        _albums.value = next
        AlbumStore.save(getApplication(), next)
    }

    fun createAlbum(name: String, songIds: List<Long>): Long {
        val id = System.currentTimeMillis()
        mutateAlbums { it + Album(id, name.trim().ifBlank { "Album" }, songIds.distinct()) }
        return id
    }

    fun renameAlbum(id: Long, name: String) = mutateAlbums { list ->
        list.map { if (it.id == id) it.copy(name = name.trim().ifBlank { it.name }) else it }
    }

    fun deleteAlbum(id: Long) = mutateAlbums { list -> list.filter { it.id != id } }

    fun addToAlbum(id: Long, songIds: List<Long>) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != id) a else a.copy(songIds = a.songIds + songIds.filter { it !in a.songIds }.distinct())
        }
    }

    fun removeFromAlbum(albumId: Long, songId: Long) = mutateAlbums { list ->
        list.map { a -> if (a.id == albumId) a.copy(songIds = a.songIds - songId) else a }
    }

    /** Geser lagu di dalam album: delta -1 = naik, +1 = turun. */
    fun moveInAlbum(albumId: Long, songId: Long, delta: Int) = mutateAlbums { list ->
        list.map { a ->
            if (a.id != albumId) return@map a
            val i = a.songIds.indexOf(songId)
            val j = i + delta
            if (i < 0 || j !in a.songIds.indices) return@map a
            val m = a.songIds.toMutableList()
            m[i] = m[j].also { m[j] = m[i] }
            a.copy(songIds = m)
        }
    }

    // ------------------------------------------------------------------ hapus lagu

    fun requestDelete(song: Song): DeleteOutcome {
        pendingDelete = song
        val outcome = MusicRepository.deleteSong(getApplication(), song)
        if (outcome is DeleteOutcome.Done) {
            pendingDelete = null
            finishDelete(song)
        }
        return outcome
    }

    fun onDeleteResult(ok: Boolean) {
        val song = pendingDelete
        pendingDelete = null
        if (!ok || song == null) return
        if (Build.VERSION.SDK_INT == 29) MusicRepository.deleteAgain(getApplication(), song)
        finishDelete(song)
    }

    private fun finishDelete(song: Song) {
        mutateAlbums { list -> list.map { it.copy(songIds = it.songIds - song.id) } }
        loadSongs()
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
