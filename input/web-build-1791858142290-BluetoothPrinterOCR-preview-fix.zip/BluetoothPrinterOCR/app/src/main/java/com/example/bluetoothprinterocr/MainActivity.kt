package com.example.bluetoothprinterocr

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.view.Gravity
import android.widget.*
import androidx.core.app.ActivityCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.OutputStream
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var result: EditText
    private lateinit var status: TextView
    private var imageBitmap: Bitmap? = null
    private val pickerCode = 71
    private val permissionCode = 72
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIncoming(intent)
        requestBluetoothPermissionIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 16); setBackgroundColor(0xFFF4F7FB.toInt()) }
        root.addView(TextView(this).apply { text = "Bluetooth Printer OCR"; textSize = 24f; setTextColor(0xFF0757B8.toInt()) })
        root.addView(TextView(this).apply { text = "OCR offline • Printer thermal 58 mm • Tanpa kuota"; textSize = 14f; setPadding(0, 8, 0, 16) })
        val open = Button(this).apply { text = "Buka gambar / screenshot"; setOnClickListener { val i = Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i, pickerCode) } }
        root.addView(open, matchWrap())
        val ocr = Button(this).apply { text = "Proses OCR"; setOnClickListener { runOcr() } }
        root.addView(ocr, matchWrap())
        result = EditText(this).apply { hint = "Hasil OCR akan muncul di sini. Kamu bisa mengeditnya."; gravity = android.view.Gravity.TOP; minLines = 8; setTextIsSelectable(true) }
        root.addView(result, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(Button(this).apply { text = "Preview struk 58 mm"; setOnClickListener { showReceiptPreview() } }, matchWrap())
        root.addView(Button(this).apply { text = "Salin teks"; setOnClickListener { val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager; cm.setPrimaryClip(android.content.ClipData.newPlainText("OCR", result.text)); Toast.makeText(this@MainActivity, "Teks disalin", Toast.LENGTH_SHORT).show() } }, matchWrap())
        root.addView(Button(this).apply { text = "Bagikan teks"; setOnClickListener { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, result.text.toString()), "Bagikan teks")) } }, matchWrap())
        root.addView(Button(this).apply { text = "Cetak ke printer Bluetooth 58 mm"; setOnClickListener { choosePrinterAndPrint(result.text.toString()) } }, matchWrap())
        status = TextView(this).apply { text = "Siap • Pilih gambar atau bagikan screenshot ke aplikasi ini"; setPadding(0, 10, 0, 0) }
        root.addView(status, matchWrap())
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); setIntent(intent); handleIncoming(intent) }

    private fun handleIncoming(i: Intent?) {
        if (i == null) return
        val uri: Uri? = when (i.action) {
            Intent.ACTION_SEND -> if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) loadImage(uri)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickerCode && resultCode == RESULT_OK) data?.data?.let { loadImage(it) }
    }

    private fun loadImage(uri: Uri) {
        try {
            contentResolver.openInputStream(uri).use { stream -> imageBitmap = BitmapFactory.decodeStream(stream) }
            status.text = if (imageBitmap != null) "Gambar siap diproses" else "Gambar tidak dapat dibuka"
            if (imageBitmap != null) runOcr()
        } catch (e: Exception) { status.text = "Gagal membuka gambar: ${e.message}" }
    }

    private fun runOcr() {
        val bmp = imageBitmap
        if (bmp == null) { Toast.makeText(this, "Pilih atau bagikan gambar terlebih dahulu", Toast.LENGTH_SHORT).show(); return }
        status.text = "Memproses OCR di perangkat…"
        val image = InputImage.fromBitmap(bmp, 0)
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image)
            .addOnSuccessListener { visionText ->
                // ML Kit line order is retained; avoid rewriting recognized content.
                result.setText(visionText.textBlocks.joinToString("\n\n") { block -> block.lines.joinToString("\n") { it.text } })
                status.text = "OCR selesai • Periksa preview struk dan koreksi teks sebelum mencetak"
                showReceiptPreview()
            }
            .addOnFailureListener { status.text = "OCR gagal: ${it.localizedMessage}" }
    }


    private fun showReceiptPreview() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 16, 24, 16)
            setBackgroundColor(Color.rgb(238, 241, 245))
        }
        val hint = TextView(this).apply {
            text = "PREVIEW CETAK • KERTAS 58 mm"
            textSize = 14f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(30, 70, 120))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        }
        outer.addView(hint, matchWrap())
        val original = imageBitmap
        if (original != null) {
            val image = ImageView(this).apply {
                setImageBitmap(original)
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                contentDescription = "Gambar screenshot asli untuk pembanding"
            }
            val imageBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(8, 8, 8, 8)
                setBackgroundColor(Color.WHITE)
                addView(TextView(this@MainActivity).apply {
                    text = "GAMBAR ASLI"
                    textSize = 11f
                    setTextColor(Color.DKGRAY)
                    gravity = Gravity.CENTER
                }, matchWrap())
                addView(image, LinearLayout.LayoutParams(-1, 180))
            }
            outer.addView(imageBox, matchWrap())
            outer.addView(Space(this).apply {}, LinearLayout.LayoutParams(1, 12))
        }
        val paper = TextView(this).apply {
            text = result.text.toString().ifBlank { "Belum ada teks OCR" }
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.BLACK)
            setBackgroundColor(Color.WHITE)
            setPadding(14, 16, 14, 16)
            gravity = Gravity.START
            setTextIsSelectable(true)
        }
        val paperBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            setBackgroundColor(Color.WHITE)
            addView(TextView(this@MainActivity).apply {
                text = "HASIL CETAK (SIMULASI 58 mm)"
                textSize = 11f
                setTextColor(Color.DKGRAY)
                gravity = Gravity.CENTER
            }, matchWrap())
            addView(paper, matchWrap())
        }
        outer.addView(paperBox, matchWrap())
        val scroll = ScrollView(this).apply { addView(outer) }
        val dialog = AlertDialog.Builder(this)
            .setTitle("Periksa preview struk")
            .setView(scroll)
            .setNeutralButton("Koreksi teks", null)
            .setNegativeButton("Bagikan", null)
            .setPositiveButton("Cetak", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
                dialog.dismiss()
                result.requestFocus()
                result.setSelection(result.text.length)
                Toast.makeText(this, "Koreksi teks di kolom hasil OCR, lalu buka preview lagi", Toast.LENGTH_LONG).show()
            }
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener {
                val share = Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, result.text.toString())
                startActivity(Intent.createChooser(share, "Bagikan hasil OCR"))
            }
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                dialog.dismiss()
                choosePrinterAndPrint(result.text.toString())
            }
        }
        dialog.show()
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), permissionCode)
        }
    }

    private fun choosePrinterAndPrint(text: String) {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestBluetoothPermissionIfNeeded(); Toast.makeText(this, "Izinkan akses Bluetooth lalu tekan Cetak lagi", Toast.LENGTH_LONG).show(); return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { status.text = "Perangkat tidak mendukung Bluetooth"; return }
        if (!adapter.isEnabled) { status.text = "Aktifkan Bluetooth dan pasangkan printer di pengaturan Android"; return }
        val devices = try { adapter.bondedDevices?.toList().orEmpty() } catch (e: SecurityException) { emptyList() }
        if (devices.isEmpty()) { status.text = "Pasangkan printer di pengaturan Bluetooth Android terlebih dahulu"; return }
        val labels = devices.map { "${it.name ?: "Printer"} (${it.address})" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Pilih printer yang sudah dipasangkan").setItems(labels) { _, which -> Thread { printToDevice(devices[which], text) }.start() }.setNegativeButton("Batal", null).show()
    }

    private fun printToDevice(device: BluetoothDevice, text: String) {
        var socket: BluetoothSocket? = null
        try {
            socket = device.createRfcommSocketToServiceRecord(spp)
            socket.connect()
            val out: OutputStream = socket.outputStream
            out.write(byteArrayOf(0x1B, 0x40)) // ESC/POS initialize
            out.write(byteArrayOf(0x1B, 0x61, 0x00)) // left alignment
            out.write(text.toByteArray(Charsets.UTF_8))
            out.write(byteArrayOf(0x0A, 0x0A, 0x0A))
            out.write(byteArrayOf(0x1D, 0x56, 0x00)) // common full cut command; ignored by printers without cutter
            out.flush()
            runOnUiThread { status.text = "Data dikirim ke ${device.name ?: "printer"}; hasil tergantung kompatibilitas printer" }
        } catch (e: Exception) {
            runOnUiThread { status.text = "Cetak gagal: ${e.localizedMessage}. Pastikan printer mendukung Bluetooth SPP/ESC-POS." }
        } finally { try { socket?.close() } catch (_: Exception) {} }
    }
}
