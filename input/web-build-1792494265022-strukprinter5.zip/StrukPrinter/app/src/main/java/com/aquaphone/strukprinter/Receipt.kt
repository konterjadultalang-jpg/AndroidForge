package com.aquaphone.strukprinter

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class L(val t: String, val bold: Boolean = false, val big: Boolean = false)

object Receipt {
    const val W = 32
    // Label BRImo bisa beda-beda (No. Rekening / No Rekening / Nomor Rekening, dst.)
    private val rx = listOf(
        "Tanggal" to "tanggal", "Tanggal" to "tgl", "No. Ref" to "no referensi", "No. Ref" to "nomor referensi",
        "No. Ref" to "no ref", "No. Ref" to "nomor ref", "No. Ref" to "ref", "Jenis Transaksi" to "jenis transaksi",
        "Sumber Dana" to "sumber dana", "Bank Tujuan" to "bank tujuan", "Bank Tujuan" to "bank penerima", "Bank Tujuan" to "bank",
        "No. Rekening" to "no rekening tujuan", "No. Rekening" to "nomor rekening tujuan", "No. Rekening" to "no rekening",
        "No. Rekening" to "nomor rekening", "No. Rekening" to "no rek", "No. Rekening" to "rekening tujuan",
        "Nama Tujuan" to "nama tujuan", "Nama Tujuan" to "nama penerima", "Nama Tujuan" to "penerima", "Tujuan" to "tujuan",
        "Keterangan" to "keterangan", "Keterangan" to "catatan", "Keterangan" to "berita",
        "Nominal" to "nominal", "Nominal" to "jumlah transfer", "Nominal" to "jumlah",
        "Biaya Admin" to "biaya admin", "Biaya Admin" to "biaya transaksi", "Biaya Admin" to "biaya",
        "Total" to "total transaksi", "Total" to "total"
    ).sortedByDescending { it.second.length }.map { (k, a) ->
        k to Regex("^" + a.split(" ").joinToString("[\\s.:]*") { Regex.escape(it) } + "\\b[\\s.:\\-]*(.*)$", RegexOption.IGNORE_CASE)
    }

    private fun match(line: String): Pair<String, String>? {
        for ((k, r) in rx) r.find(line)?.let { return k to it.groupValues[1].trim() }
        return null
    }

    fun parse(t: String): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < ls.size) {
            val mt = match(ls[i])
            if (mt != null) {
                var v = mt.second
                if (v.isEmpty() && i + 1 < ls.size && match(ls[i + 1]) == null) v = ls[++i]
                if (m[mt.first].isNullOrBlank()) m[mt.first] = v
            }
            i++
        }
        // Cadangan: cari nomor rekening (8-20 digit) dan nama bank bila labelnya tidak terbaca
        if (m["No. Rekening"].isNullOrBlank()) {
            val refD = m["No. Ref"]?.filter { it.isDigit() }
            val ok = setOf("Tujuan", "Bank Tujuan", "Nama Tujuan")
            val tok = ls.filter { l -> match(l).let { it == null || it.first in ok } }
                .flatMap { Regex("\\b\\d{8,20}\\b").findAll(it).map { x -> x.value }.toList() }
                .lastOrNull { it != refD }
            if (tok != null) m["No. Rekening"] = tok
        }
        if (m["Bank Tujuan"].isNullOrBlank()) {
            val b = Regex("\\b(BRI|BCA|BNI|MANDIRI|BSI|CIMB|PERMATA|DANAMON|BTN|MEGA|OCBC|PANIN|BTPN|JAGO|SEABANK|DANA|OVO|GOPAY|SHOPEEPAY|LINKAJA)\\b", RegexOption.IGNORE_CASE).find(t)
            if (b != null) m["Bank Tujuan"] = b.value.uppercase()
        }
        return m
    }

    fun num(s: String?): Long = s?.substringBefore(',')?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
    fun rp(n: Long) = "RP " + n.toString().reversed().chunked(3).joinToString(".").reversed()

    private fun cen(s: String, w: Int = W) = s.chunked(w).map { " ".repeat((w - it.length) / 2) + it }
    private fun row(k: String, v: String): List<String> =
        if (k.length + 1 + v.length <= W) listOf(k + " ".repeat(W - k.length - v.length) + v)
        else listOf(k) + v.chunked(W).map { " ".repeat(W - it.length) + it }

    // tanggal mentah BRImo -> (tanggal, waktu)
    private fun dt(raw: String?): Pair<String, String> {
        if (raw.isNullOrBlank()) { val n = Date(); return Pair(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(n), SimpleDateFormat("HH:mm:ss", Locale.US).format(n)) }
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(raw)
        val time = m?.let { "%02d:%s:%s".format(it.groupValues[1].toInt(), it.groupValues[2], it.groupValues[3].ifEmpty { "00" }) } ?: ""
        val date = raw.replace(m?.value ?: "", "").replace("WIB", "", true).trim(' ', ',', '-', '\u2022')
        return Pair(date.uppercase(), time)
    }

    fun lines(d: Map<String, String>, admin: Long, name: String, addr: String, foot: String): List<L> {
        val o = ArrayList<L>()
        fun rows(k: String, v: String) = row(k, v.uppercase()).forEach { o.add(L(it)) }
        name.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        addr.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it)) } }
        o.add(L(""))
        o.add(L("=".repeat(W))); o.add(L(cen("BUKTI TRANSFER")[0], true)); o.add(L("=".repeat(W)))
        val (tg, wk) = dt(d["Tanggal"])
        rows("TANGGAL", tg); rows("WAKTU", wk); rows("REF", d["No. Ref"]?.ifBlank { "-" } ?: "-")
        o.add(L("")); o.add(L("KEPADA:"))
        listOf("PENERIMA" to (d["Nama Tujuan"] ?: d["Tujuan"] ?: ""), "BANK" to (d["Bank Tujuan"] ?: ""),
            "NO REKENING" to (d["No. Rekening"] ?: ""), "KETERANGAN" to (d["Keterangan"] ?: "").replace("|", " "))
            .filter { it.second.isNotBlank() }.forEach { rows(it.first, it.second.trim()) }
        o.add(L(""))
        val nom = num(d["Nominal"])
        if (admin > 0) { rows("NOMINAL", rp(nom)); rows("BIAYA ADMIN", rp(admin)); o.add(L("")) }
        o.add(L(cen("TOTAL BAYAR")[0], true))
        o.add(L(cen(rp(nom + admin), W / 2)[0], true, true))
        o.add(L("")); o.add(L("-".repeat(W)))
        o.add(L(cen("** TRANSAKSI BERHASIL **")[0], true))
        foot.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        return o
    }
}
