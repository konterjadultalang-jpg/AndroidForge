package com.aquaphone.strukprinter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.util.UUID;

/** Kirim data ke printer Bluetooth klasik (SPP) yang sudah dipasangkan. */
public final class BtPrinter {

    public static final String PERMISSION = "android.permission.BLUETOOTH_CONNECT";
    private static final UUID SPP = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BtPrinter() {}

    public static boolean hasPermission(Activity a) {
        return Build.VERSION.SDK_INT < 31
                || a.checkSelfPermission(PERMISSION) == PackageManager.PERMISSION_GRANTED;
    }

    public static void requestPermission(Activity a, int code) {
        a.requestPermissions(new String[]{PERMISSION}, code);
    }

    @SuppressLint("MissingPermission")
    public static void print(String mac, byte[] data) throws Exception {
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) throw new IOException("Perangkat ini tidak punya Bluetooth.");
        if (!ad.isEnabled()) throw new IOException("Bluetooth belum menyala. Nyalakan dulu.");

        BluetoothDevice dev = ad.getRemoteDevice(mac);
        BluetoothSocket sock = null;
        try {
            try {
                sock = dev.createRfcommSocketToServiceRecord(SPP);
                sock.connect();
            } catch (Exception first) {
                closeQuietly(sock);
                try {
                    Method m = dev.getClass().getMethod("createRfcommSocket", int.class);
                    sock = (BluetoothSocket) m.invoke(dev, 1);
                    sock.connect();
                } catch (Exception second) {
                    closeQuietly(sock);
                    sock = null;
                    throw new IOException("Tidak bisa terhubung ke printer. Pastikan printer menyala dan sudah dipasangkan.");
                }
            }
            OutputStream os = sock.getOutputStream();
            int off = 0;
            while (off < data.length) {
                int n = Math.min(1024, data.length - off);
                os.write(data, off, n);
                os.flush();
                off += n;
                Thread.sleep(10);
            }
            Thread.sleep(800); // beri waktu printer menghabiskan data
        } finally {
            closeQuietly(sock);
        }
    }

    private static void closeQuietly(BluetoothSocket s) {
        try {
            if (s != null) s.close();
        } catch (Exception ignored) {
        }
    }
}
