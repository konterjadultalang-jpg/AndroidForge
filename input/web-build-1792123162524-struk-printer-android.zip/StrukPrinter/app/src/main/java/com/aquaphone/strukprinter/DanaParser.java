package com.aquaphone.strukprinter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Membaca teks hasil OCR struk DANA (Kirim Uang ke rekening bank). */
public final class DanaParser {

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final Pattern P_DATE = Pattern.compile("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?\\s+(\\d{4})\\D{0,6}?(\\d{1,2})[:.](\\d{2})");
    private static final Pattern P_TITLE = Pattern.compile(
            "Kirim\\s+Uang\\s+R[pP]\\s*[\\d.,]+\\s+ke\\s+(.+?)\\s+[-\u2013\u2014]\\s+(.+?)\\s*[^\\w\\s]{2,}\\s*(\\d{3,})", CI);
    private static final Pattern P_TOTAL = Pattern.compile("Total\\s+Bayar\\s*R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_KIRIM = Pattern.compile("Kirim\\s+Uang\\s+R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_ADMIN = Pattern.compile("Biaya\\s+(?:Admin|Layanan)\\s*R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_NAMA = Pattern.compile("^Nama\\b\\s*", CI);
    private static final Pattern P_AKUN = Pattern.compile("^Akun\\s+Bank\\s*(.+?)\\s*[^\\w\\s]{2,}\\s*(\\d{3,})", CI);
    private static final Pattern P_IDTRX = Pattern.compile("^ID\\s+Transaksi\\b", CI);

    /** Batas aman panjang ID Transaksi (ID asli sekitar 37 digit). */
    static final int REF_MAX = 40;

    private DanaParser() {}

    private static String p2(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    public static boolean looksLikeDana(String raw) {
        return raw != null && Pattern.compile("Total\\s+Bayar|Detail\\s+Penerima|ID\\s+DANA|Diamankan\\s+oleh", CI).matcher(raw).find();
    }

    public static Receipt parse(String raw) {
        Receipt r = new Receipt();
        r.sumber = "DANA";
        List<String> lines = new ArrayList<>();
        if (raw != null) {
            for (String a : raw.replace("\r", "").split("\n")) {
                String t = a.trim();
                if (!t.isEmpty()) lines.add(t);
            }
        }
        StringBuilder fb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) fb.append('\n');
            fb.append(lines.get(i));
        }
        String flat = fb.toString();
        String oneLine = flat.replace('\n', ' ').replaceAll("\\s+", " ");

        Matcher m = P_DATE.matcher(flat);
        while (m.find()) {
            Integer mo = BrimoParser.month(m.group(2));
            if (mo != null) {
                r.tanggal = m.group(3) + "-" + p2(mo) + "-" + p2(Integer.parseInt(m.group(1)));
                r.waktu = p2(Integer.parseInt(m.group(4))) + ":" + m.group(5) + ":00";
                break;
            }
        }

        m = P_TOTAL.matcher(flat);
        if (m.find()) {
            r.nominal = BrimoParser.toNum(m.group(1));
        } else {
            m = P_KIRIM.matcher(oneLine);
            if (m.find()) r.nominal = BrimoParser.toNum(m.group(1));
        }
        m = P_ADMIN.matcher(flat);
        r.admin = m.find() ? BrimoParser.toNum(m.group(1)) : 0;

        if (Pattern.compile("Kirim\\s+Uang", CI).matcher(oneLine).find()) r.jenis = "Kirim Uang";

        // Sumber utama: kalimat "Kirim Uang Rp... ke NAMA - BANK ••••1234" (nama lengkap, tidak terpotong)
        m = P_TITLE.matcher(oneLine);
        if (m.find()) {
            r.penerima = m.group(1).trim();
            r.bank = m.group(2).trim().toUpperCase(Locale.ROOT);
            r.rek = m.group(3);
        }

        // Cadangan: bagian "Detail Penerima"
        if (r.penerima.isEmpty()) {
            for (int i = 0; i < lines.size(); i++) {
                Matcher n = P_NAMA.matcher(lines.get(i));
                if (n.find()) {
                    String v = lines.get(i).substring(n.end()).trim();
                    if (i + 1 < lines.size() && lines.get(i + 1).matches("[A-Za-z]{1,2}")) v = v + lines.get(i + 1);
                    r.penerima = v;
                    break;
                }
            }
        }
        if (r.bank.isEmpty() || r.rek.isEmpty()) {
            for (String l : lines) {
                Matcher a = P_AKUN.matcher(l);
                if (a.find()) {
                    if (r.bank.isEmpty()) r.bank = a.group(1).trim().toUpperCase(Locale.ROOT);
                    if (r.rek.isEmpty()) r.rek = a.group(2);
                    break;
                }
            }
        }

        // Kode referensi: ID Transaksi lengkap; potongan angka di baris-baris berikutnya digabung
        for (int i = 0; i < lines.size(); i++) {
            if (P_IDTRX.matcher(lines.get(i)).find()) {
                StringBuilder d = new StringBuilder(lines.get(i).replaceFirst("(?i)^ID\\s+Transaksi", "").replaceAll("\\D", ""));
                int j = i + 1;
                while (d.length() < REF_MAX && j < lines.size() && lines.get(j).replaceAll("\\s", "").matches("\\d+")) {
                    d.append(lines.get(j).replaceAll("\\s", ""));
                    j++;
                }
                if (d.length() > 0) r.noref = d.substring(0, Math.min(REF_MAX, d.length()));
                break;
            }
        }
        if (r.noref.isEmpty()) {
            Matcher n = Pattern.compile("\\b(\\d{18,})\\b").matcher(flat);
            if (n.find()) r.noref = n.group(1);
        }
        return r;
    }
}
