package com.aquaphone.strukprinter;

/** Data struk yang dicetak. */
public class Receipt {
    public String tanggal = "";
    public String waktu = "";
    public String noref = "";
    public String bank = "";
    public String rek = "";
    public String penerima = "";
    public String jenis = "";
    /** Asal struk yang terdeteksi, misalnya BRImo atau DANA. */
    public String sumber = "";
    public long nominal = 0;
    public long admin = 0;
}
