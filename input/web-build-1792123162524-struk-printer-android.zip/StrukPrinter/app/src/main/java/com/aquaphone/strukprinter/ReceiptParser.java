package com.aquaphone.strukprinter;

import java.util.List;

/** Mengenali asal struk dari teks hasil baca, lalu memakai parser yang sesuai. */
public final class ReceiptParser {

    public static final int AUTO = 0;
    public static final int BRIMO = 1;
    public static final int DANA = 2;
    public static final int SHOPEEPAY = 3;

    private ReceiptParser() {}

    public static Receipt parse(String raw, List<String[]> prefixMap) {
        return parse(raw, prefixMap, AUTO);
    }

    /** @param mode AUTO (deteksi otomatis) atau BRIMO, DANA, SHOPEEPAY (dipaksa manual). */
    public static Receipt parse(String raw, List<String[]> prefixMap, int mode) {
        // Urutan penting: BRImo juga memuat kata "Sumber Dana", jadi diperiksa paling akhir.
        if (mode == DANA || (mode == AUTO && DanaParser.looksLikeDana(raw))) {
            return DanaParser.parse(raw);
        }
        if (mode == SHOPEEPAY || (mode == AUTO && ShopeePayParser.looksLikeShopeePay(raw))) {
            return ShopeePayParser.parse(raw);
        }
        boolean brimo = mode == BRIMO || (mode == AUTO && BrimoParser.looksLikeBrimo(raw));
        Receipt r = BrimoParser.parse(raw, prefixMap);
        r.sumber = brimo ? "BRImo" : ""; // kosong = jenis tidak dikenali
        return r;
    }
}
