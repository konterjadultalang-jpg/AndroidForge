package com.aquaphone.strukprinter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Menyusun baris struk persis seperti format trfbt (lebar tetap, monospasi). */
public final class ReceiptLayout {

    public static final class Line {
        public final String text;
        public final boolean bold;
        public final int size; // 1 normal, 2 dua kali lebih besar

        Line(String text, boolean bold, int size) {
            this.text = text;
            this.bold = bold;
            this.size = size;
        }
    }

    private ReceiptLayout() {}

    public static String rp(long n) {
        return "RP " + String.valueOf(n).replaceAll("\\B(?=(\\d{3})+(?!\\d))", ".");
    }

    private static String repeat(char c, int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(c);
        return sb.toString();
    }

    static String center(String t, int w) {
        if (t.length() > w) t = t.substring(0, w);
        return repeat(' ', (w - t.length()) / 2) + t;
    }

    static List<String> wrap(String text, int w) {
        List<String> out = new ArrayList<>();
        String cur = "";
        for (String word0 : text.trim().split("\\s+")) {
            if (word0.isEmpty()) continue;
            String word = word0;
            while (word.length() > w) {
                if (!cur.isEmpty()) {
                    out.add(cur);
                    cur = "";
                }
                out.add(word.substring(0, w));
                word = word.substring(w);
            }
            if (cur.isEmpty()) cur = word;
            else if ((cur + " " + word).length() <= w) cur = cur + " " + word;
            else {
                out.add(cur);
                cur = word;
            }
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }

    static String row(String l, String r, int w) {
        l = l.toUpperCase(Locale.ROOT);
        r = r.toUpperCase(Locale.ROOT);
        if (l.length() + 1 + r.length() > w) r = r.substring(0, Math.max(0, w - l.length() - 1));
        int sp = Math.max(1, w - l.length() - r.length());
        return l + repeat(' ', sp) + r;
    }

    private static void add(List<Line> L, String text, boolean bold, int size) {
        L.add(new Line(text.replaceAll("\\s+$", ""), bold, size));
    }

    public static List<Line> build(Receipt d, int w, String toko, String desc1, String desc2,
                                   String catatan, String tid) {
        List<Line> L = new ArrayList<>();
        String eq = repeat('=', w);
        String dash = repeat('-', w);

        String nama = toko == null ? "" : toko.trim().toUpperCase(Locale.ROOT);
        if (!nama.isEmpty()) {
            int half = w / 2;
            for (String t : wrap(nama, half)) add(L, center(t, half), true, 2);
        }
        boolean first = true;
        String[] paras = {desc1, desc2};
        for (String p : paras) {
            if (p == null || p.trim().isEmpty()) continue;
            if (!first) add(L, "", false, 1);
            first = false;
            for (String t : wrap(p.toUpperCase(Locale.ROOT), w)) add(L, center(t, w), false, 1);
        }

        add(L, eq, false, 1);
        add(L, row("TANGGAL", d.tanggal, w), false, 1);
        add(L, row("WAKTU", d.waktu, w), false, 1);
        add(L, dash, false, 1);
        add(L, center("KODE REFERENSI", w), false, 1);
        String ref = d.noref == null ? "" : d.noref.trim();
        if (ref.length() <= w) {
            add(L, center(ref, w), true, 1);
        } else {
            int n = (ref.length() + w - 1) / w;
            int per = (ref.length() + n - 1) / n;
            for (int i = 0; i < ref.length(); i += per) {
                add(L, center(ref.substring(i, Math.min(ref.length(), i + per)), w), true, 1);
            }
        }
        add(L, dash, false, 1);
        add(L, center("DATA PENERIMA", w), true, 1);
        add(L, row("BANK TUJUAN", d.bank, w), false, 1);
        add(L, row("NO REKENING", d.rek, w), false, 1);
        add(L, row("PENERIMA", d.penerima, w), false, 1);
        add(L, dash, false, 1);
        add(L, row("NOMINAL", rp(d.nominal), w), false, 1);
        add(L, row("ADMIN", rp(d.admin), w), false, 1);
        add(L, eq, false, 1);
        add(L, row("TOTAL", rp(d.nominal + d.admin), w), true, 1);
        add(L, eq, false, 1);
        add(L, "", false, 1);
        add(L, dash, false, 1);
        add(L, center("** TRANSAKSI BERHASIL **", w), true, 1);
        if (catatan != null && !catatan.trim().isEmpty()) {
            for (String t : wrap(catatan.toUpperCase(Locale.ROOT), w)) add(L, center(t, w), false, 1);
        }
        add(L, center("TERIMA KASIH", w), true, 1);
        if (tid != null && !tid.trim().isEmpty()) {
            add(L, center("TID: " + tid.trim().toUpperCase(Locale.ROOT), w), false, 1);
        }
        return L;
    }
}
