package com.aquaphone.strukprinter;

import android.graphics.Bitmap;
import android.graphics.Color;

import java.io.ByteArrayOutputStream;

/** Mengubah bitmap menjadi perintah ESC/POS (GS v 0) untuk printer termal. */
public final class EscPos {

    private EscPos() {}

    public static byte[] raster(Bitmap bmp, int bandH, int threshold) {
        final int w = bmp.getWidth();
        final int h = bmp.getHeight();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        final int bpr = (w + 7) / 8;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(0x1B);
        out.write(0x40); // inisialisasi printer
        for (int y0 = 0; y0 < h; y0 += bandH) {
            int bh = Math.min(bandH, h - y0);
            out.write(0x1D);
            out.write(0x76);
            out.write(0x30);
            out.write(0x00);
            out.write(bpr & 255);
            out.write(bpr >> 8);
            out.write(bh & 255);
            out.write(bh >> 8);
            for (int y = 0; y < bh; y++) {
                for (int bx = 0; bx < bpr; bx++) {
                    int v = 0;
                    for (int b = 0; b < 8; b++) {
                        int x = bx * 8 + b;
                        if (x < w && Color.red(px[(y0 + y) * w + x]) < threshold) v |= 0x80 >> b;
                    }
                    out.write(v);
                }
            }
        }
        out.write(0x1B);
        out.write(0x64);
        out.write(4); // dorong kertas 4 baris
        return out.toByteArray();
    }
}
