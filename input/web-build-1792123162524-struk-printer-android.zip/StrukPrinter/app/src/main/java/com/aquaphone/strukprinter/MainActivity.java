package com.aquaphone.strukprinter;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final int REQ_PICK = 11;
    private static final int REQ_BT = 12;
    private static final int TEAL = Color.parseColor("#12677D");

    private Settings settings;
    private EditText eTanggal, eWaktu, eNoref, eBank, eRek, ePenerima, eNominal, eAdmin;
    private ImageView preview;
    private TextView status;
    private Button btnPrint;
    private boolean filling = false;
    private boolean pendingPrint = false;
    private Spinner spMode;
    private int modeIndex = 0;
    private String lastRaw = "";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable previewTask = new Runnable() {
        @Override
        public void run() {
            refreshPreview();
        }
    };
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private TextRecognizer recognizer;

    private final TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int a, int b, int c) {
        }

        @Override
        public void onTextChanged(CharSequence s, int a, int b, int c) {
        }

        @Override
        public void afterTextChanged(Editable e) {
            if (!filling) {
                handler.removeCallbacks(previewTask);
                handler.postDelayed(previewTask, 150);
            }
        }
    };

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        settings = Settings.load(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        buildUi();
        fill(new Receipt());
        setStatus("Bagikan screenshot struk BRImo ke aplikasi ini, atau pilih dari galeri.", false);
        if (savedInstanceState == null) handleIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        settings = Settings.load(this);
        refreshPreview();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(previewTask);
        recognizer.close();
        io.shutdown();
    }

    /* ---------- tampilan ---------- */

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#E6EAED"));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(TEAL);
        header.setPadding(dp(16), dp(10), dp(8), dp(10));
        TextView title = new TextView(this);
        title.setText("Printer Struk");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button bSet = new Button(this);
        bSet.setText("Pengaturan");
        bSet.setAllCaps(false);
        bSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        header.addView(bSet, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(12), dp(16), dp(24));
        sv.addView(body, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        status = new TextView(this);
        status.setTextSize(14);
        body.addView(status, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout desk = new FrameLayout(this);
        desk.setBackgroundColor(Color.parseColor("#CDD5DB"));
        desk.setPadding(dp(12), dp(12), dp(12), dp(12));
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        desk.addView(preview, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.topMargin = dp(10);
        body.addView(desk, dlp);

        btnPrint = new Button(this);
        btnPrint.setText("Cetak");
        btnPrint.setAllCaps(false);
        btnPrint.setTextColor(Color.WHITE);
        btnPrint.setBackgroundColor(TEAL);
        btnPrint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onPrintClicked();
            }
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        plp.topMargin = dp(12);
        body.addView(btnPrint, plp);

        Button btnPick = new Button(this);
        btnPick.setText("Pilih struk dari galeri");
        btnPick.setAllCaps(false);
        btnPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/*");
                startActivityForResult(Intent.createChooser(i, "Pilih struk"), REQ_PICK);
            }
        });
        body.addView(btnPick, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView ml = new TextView(this);
        ml.setText("Jenis struk");
        ml.setTextColor(Color.parseColor("#5B6B78"));
        ml.setTextSize(13);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mlp.topMargin = dp(16);
        body.addView(ml, mlp);
        spMode = new Spinner(this);
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item,
                new String[]{"Otomatis (deteksi sendiri)", "BRImo", "DANA", "ShopeePay"});
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMode.setAdapter(ad);
        spMode.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == modeIndex) return;
                modeIndex = position;
                if (!lastRaw.isEmpty()) applyText(lastRaw);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        body.addView(spMode, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView h = new TextView(this);
        h.setText("Data struk (bisa diubah)");
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = dp(20);
        body.addView(h, hlp);

        eTanggal = addField(body, "Tanggal (contoh 2026-10-15)", false);
        eWaktu = addField(body, "Waktu (contoh 17:40:00)", false);
        eNoref = addField(body, "Kode referensi", true);
        eBank = addField(body, "Bank tujuan", false);
        eRek = addField(body, "No rekening", true);
        ePenerima = addField(body, "Penerima", false);
        eNominal = addField(body, "Nominal (Rp)", true);
        eAdmin = addField(body, "Biaya admin (Rp)", true);

        setContentView(root);
    }

    private EditText addField(LinearLayout parent, String label, boolean numeric) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#5B6B78"));
        tv.setTextSize(13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(tv, lp);
        EditText et = new EditText(this);
        et.setSingleLine(true);
        if (numeric) et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.addTextChangedListener(watcher);
        parent.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return et;
    }

    private void setStatus(String msg, boolean error) {
        status.setText(msg);
        status.setTextColor(error ? Color.parseColor("#A4452C") : Color.parseColor("#5B6B78"));
    }

    /* ---------- data struk ---------- */

    private Receipt readFields() {
        Receipt r = new Receipt();
        r.tanggal = eTanggal.getText().toString().trim();
        r.waktu = eWaktu.getText().toString().trim();
        r.noref = eNoref.getText().toString().trim();
        r.bank = eBank.getText().toString().trim();
        r.rek = eRek.getText().toString().trim();
        r.penerima = ePenerima.getText().toString().trim();
        r.nominal = BrimoParser.toNum(eNominal.getText().toString());
        r.admin = BrimoParser.toNum(eAdmin.getText().toString());
        return r;
    }

    private void fill(Receipt r) {
        Date now = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat tf = new SimpleDateFormat("HH:mm:ss", Locale.US);
        filling = true;
        eTanggal.setText(r.tanggal.isEmpty() ? df.format(now) : r.tanggal);
        eWaktu.setText(r.waktu.isEmpty() ? tf.format(now) : r.waktu);
        eNoref.setText(r.noref);
        eBank.setText(r.bank);
        eRek.setText(r.rek);
        ePenerima.setText(r.penerima);
        eNominal.setText(r.nominal > 0 ? String.valueOf(r.nominal) : "");
        eAdmin.setText(String.valueOf(r.admin));
        filling = false;
        refreshPreview();
    }

    private void refreshPreview() {
        if (settings == null || preview == null) return;
        List<ReceiptLayout.Line> lines = ReceiptLayout.build(readFields(), settings.width,
                settings.toko, settings.desc1, settings.desc2, settings.catatan, settings.tid);
        Bitmap bmp = ReceiptRenderer.render(this, lines, settings.width, settings.thick, 3);
        preview.setImageBitmap(bmp);
    }

    /* ---------- bagikan / baca struk ---------- */

    @SuppressWarnings("deprecation")
    private void handleIntent(Intent in) {
        if (in == null) return;
        String type = in.getType();
        if (!Intent.ACTION_SEND.equals(in.getAction()) || type == null) return;
        if (type.startsWith("image/")) {
            Uri u;
            if (Build.VERSION.SDK_INT >= 33) u = in.getParcelableExtra(Intent.EXTRA_STREAM, Uri.class);
            else u = in.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) runOcr(u);
        } else if (type.startsWith("text/")) {
            String t = in.getStringExtra(Intent.EXTRA_TEXT);
            if (t != null && !t.trim().isEmpty()) {
                resetMode();
                applyText(t);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_PICK && resultCode == RESULT_OK && data != null && data.getData() != null) {
            runOcr(data.getData());
        }
    }

    /** Struk baru selalu dimulai dengan deteksi otomatis. */
    private void resetMode() {
        modeIndex = 0;
        if (spMode != null) spMode.setSelection(0);
    }

    private void runOcr(Uri uri) {
        resetMode();
        setStatus("Membaca struk...", false);
        try {
            InputImage img = InputImage.fromFilePath(this, uri);
            recognizer.process(img)
                    .addOnSuccessListener(t -> applyText(rowsText(t)))
                    .addOnFailureListener(e -> setStatus("Gagal membaca gambar. Isi data secara manual.", true));
        } catch (Exception e) {
            setStatus("Gambar tidak bisa dibuka. Isi data secara manual.", true);
        }
    }

    /** Menyatukan potongan teks yang sejajar menjadi satu baris, supaya "label  nilai" tetap berdampingan. */
    private String rowsText(Text t) {
        List<Text.Line> all = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks()) all.addAll(b.getLines());
        Collections.sort(all, (a, b) -> {
            Rect ra = a.getBoundingBox();
            Rect rb = b.getBoundingBox();
            int ya = ra == null ? 0 : ra.centerY();
            int yb = rb == null ? 0 : rb.centerY();
            return Integer.compare(ya, yb);
        });
        List<List<Text.Line>> rows = new ArrayList<>();
        int curY = Integer.MIN_VALUE;
        int curH = 0;
        for (Text.Line l : all) {
            Rect r = l.getBoundingBox();
            if (r == null) {
                List<Text.Line> single = new ArrayList<>();
                single.add(l);
                rows.add(single);
                curY = Integer.MIN_VALUE;
                continue;
            }
            if (!rows.isEmpty() && curY != Integer.MIN_VALUE
                    && Math.abs(r.centerY() - curY) < Math.max(curH, r.height()) * 0.6) {
                rows.get(rows.size() - 1).add(l);
            } else {
                List<Text.Line> nr = new ArrayList<>();
                nr.add(l);
                rows.add(nr);
                curY = r.centerY();
                curH = r.height();
            }
        }
        StringBuilder sb = new StringBuilder();
        for (List<Text.Line> row : rows) {
            Collections.sort(row, (a, b) -> {
                Rect ra = a.getBoundingBox();
                Rect rb = b.getBoundingBox();
                int xa = ra == null ? 0 : ra.left;
                int xb = rb == null ? 0 : rb.left;
                return Integer.compare(xa, xb);
            });
            for (int i = 0; i < row.size(); i++) {
                if (i > 0) sb.append(' ');
                sb.append(row.get(i).getText());
            }
            sb.append('\n');
        }
        return sb.toString();
    }

    private void applyText(String raw) {
        lastRaw = raw == null ? "" : raw;
        Receipt r = ReceiptParser.parse(raw, BrimoParser.parsePrefix(settings.prefix), modeIndex);
        fill(r);
        if (modeIndex == 0 && r.sumber.isEmpty()) {
            setStatus("Jenis struk belum dikenali. Pilih jenis struk di bawah tombol Cetak (BRImo, DANA, atau ShopeePay), atau isi data secara manual.", true);
            return;
        }
        List<String> miss = new ArrayList<>();
        if (r.nominal == 0) miss.add("nominal");
        if (r.noref.isEmpty()) miss.add("kode referensi");
        if (r.penerima.isEmpty()) miss.add("penerima");
        if (r.rek.isEmpty()) miss.add("no rekening");
        if (miss.isEmpty()) {
            setStatus((r.sumber.isEmpty() ? "Struk" : "Struk " + r.sumber) + " terbaca. Periksa preview, ubah biaya admin bila perlu, lalu cetak.", false);
        } else {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < miss.size(); i++) {
                if (i > 0) sb.append(", ");
                sb.append(miss.get(i));
            }
            setStatus("Belum terbaca: " + sb + ". Lengkapi di kolom bawah.", true);
        }
    }

    /* ---------- cetak ---------- */

    private void onPrintClicked() {
        if (settings.printerMac == null || settings.printerMac.isEmpty()) {
            Toast.makeText(this, "Pilih printer dulu di Pengaturan.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(this, SettingsActivity.class));
            return;
        }
        if (!BtPrinter.hasPermission(this)) {
            pendingPrint = true;
            BtPrinter.requestPermission(this, REQ_BT);
            return;
        }
        doPrint();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            boolean ok = grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED;
            if (ok && pendingPrint) doPrint();
            else if (!ok) setStatus("Izin Bluetooth ditolak. Izinkan di pengaturan aplikasi.", true);
            pendingPrint = false;
        }
    }

    private void doPrint() {
        final Receipt r = readFields();
        final Settings s = settings;
        btnPrint.setEnabled(false);
        setStatus("Mencetak...", false);
        io.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    List<ReceiptLayout.Line> lines = ReceiptLayout.build(r, s.width, s.toko, s.desc1, s.desc2, s.catatan, s.tid);
                    Bitmap bmp = ReceiptRenderer.render(MainActivity.this, lines, s.width, s.thick, 1);
                    byte[] data = EscPos.raster(bmp, 96, 190);
                    bmp.recycle();
                    BtPrinter.print(s.printerMac, data);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnPrint.setEnabled(true);
                            setStatus("Struk terkirim ke printer.", false);
                        }
                    });
                } catch (final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            btnPrint.setEnabled(true);
                            setStatus(e.getMessage() == null ? "Gagal mencetak." : e.getMessage(), true);
                        }
                    });
                }
            }
        });
    }
}
