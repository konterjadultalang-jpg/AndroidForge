package com.aquaphone.strukprinter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Membaca teks hasil OCR struk riwayat BRImo (Transfer dan Pembayaran BRIVA). */
public final class BrimoParser {

    private static final Map<String, Integer> BULAN = new HashMap<>();

    static {
        String[] n = {"januari", "februari", "maret", "april", "mei", "juni", "juli",
                "agustus", "september", "oktober", "november", "desember"};
        for (int i = 0; i < n.length; i++) BULAN.put(n[i], i + 1);
        String[] k = {"jan", "feb", "mar", "apr", "jun", "jul", "agu", "agt", "aug", "sep", "sept", "okt", "oct", "nov", "des", "dec"};
        int[] v = {1, 2, 3, 4, 6, 7, 8, 8, 8, 9, 9, 10, 10, 11, 12, 12};
        for (int i = 0; i < k.length; i++) BULAN.put(k[i], v[i]);
    }

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final Pattern P_DATE = Pattern.compile("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?\\s+(\\d{4})[,\\s]+(\\d{1,2})[:.](\\d{2})");
    private static final Pattern P_REF = Pattern.compile("No\\.?\\s*Ref[^\\d\\n]*(\\d{8,})", CI);
    private static final Pattern P_12 = Pattern.compile("\\b(\\d{12})\\b");
    private static final Pattern P_TOTAL = Pattern.compile("Total\\s+Transaksi[\\s\\S]{0,40}?R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_NOMINAL = Pattern.compile("Nominal\\s*R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_ADMIN = Pattern.compile("Biaya\\s+Admin\\s*R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_JENIS = Pattern.compile("Jenis\\s+Transaksi\\s*[:\\-]?\\s*(.+)", CI);
    private static final Pattern P_TUJUAN = Pattern.compile("^Tujuan\\b", CI);
    private static final Pattern P_END = Pattern.compile("^(Jenis\\s+Transaksi|Keterangan|Nominal)", CI);
    private static final Pattern P_PT = Pattern.compile("^(PT|CV)\\b\\.?", CI);
    private static final Pattern P_BANK = Pattern.compile("^BANK\\b", CI);
    private static final Pattern P_LOGO = Pattern.compile("^[A-Za-z]?BRI$", CI);
    private static final Pattern P_MASKED = Pattern.compile("[\\d*xX-]{6,}");

    private BrimoParser() {}

    public static boolean looksLikeBrimo(String raw) {
        return raw != null && Pattern.compile("Total\\s+Transaksi|Sumber\\s+Dana|No\\.?\\s*Ref|BRIVA|BRImo", CI).matcher(raw).find();
    }

    /** Nomor bulan (1-12) dari nama bulan Indonesia, atau null. */
    static Integer month(String name) {
        return name == null ? null : BULAN.get(name.toLowerCase(Locale.ROOT));
    }

    private static String p2(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    /** Mengambil angka dari teks seperti "Rp101.000". */
    public static long toNum(String s) {
        if (s == null) return 0;
        String t = s.trim().replaceAll(",\\d{2}$", "");
        String d = t.replaceAll("[^\\d]", "");
        if (d.isEmpty()) return 0;
        try {
            return Long.parseLong(d);
        } catch (Exception e) {
            return 0;
        }
    }

    /** Format pengaturan: satu baris per aturan, contoh 13282=DANA. */
    public static List<String[]> parsePrefix(String text) {
        List<String[]> out = new ArrayList<>();
        if (text == null) return out;
        Pattern p = Pattern.compile("^\\s*(\\d+)\\s*=\\s*(.+?)\\s*$");
        for (String l : text.split("\n")) {
            Matcher m = p.matcher(l);
            if (m.find()) out.add(new String[]{m.group(1), m.group(2)});
        }
        return out;
    }

    private static int digits(String s) {
        int c = 0;
        for (int i = 0; i < s.length(); i++) if (Character.isDigit(s.charAt(i))) c++;
        return c;
    }

    public static Receipt parse(String raw, List<String[]> prefixMap) {
        Receipt r = new Receipt();
        List<String> lines = new ArrayList<>();
        if (raw != null) {
            for (String a : raw.replace("\r", "").split("\n")) {
                String t = a.trim();
                if (!t.isEmpty()) lines.add(t);
            }
        }
        StringBuilder fb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) fb.append('\n');
            fb.append(lines.get(i));
        }
        String flat = fb.toString();

        Matcher m = P_DATE.matcher(flat);
        while (m.find()) {
            Integer mo = BULAN.get(m.group(2).toLowerCase(Locale.ROOT));
            if (mo != null) {
                r.tanggal = m.group(3) + "-" + p2(mo) + "-" + p2(Integer.parseInt(m.group(1)));
                r.waktu = p2(Integer.parseInt(m.group(4))) + ":" + m.group(5) + ":00";
                break;
            }
        }

        m = P_REF.matcher(flat);
        if (m.find()) {
            r.noref = m.group(1);
        } else {
            m = P_12.matcher(flat);
            if (m.find()) r.noref = m.group(1);
        }

        m = P_TOTAL.matcher(flat);
        if (m.find()) {
            r.nominal = toNum(m.group(1));
        } else {
            m = P_NOMINAL.matcher(flat);
            if (m.find()) r.nominal = toNum(m.group(1));
        }

        m = P_ADMIN.matcher(flat);
        r.admin = m.find() ? toNum(m.group(1)) : 0;

        m = P_JENIS.matcher(flat);
        if (m.find()) r.jenis = m.group(1).trim();

        int iT = -1;
        for (int i = 0; i < lines.size(); i++) {
            if (P_TUJUAN.matcher(lines.get(i)).find()) {
                iT = i;
                break;
            }
        }
        if (iT >= 0) {
            int iE = -1;
            for (int i = iT + 1; i < lines.size(); i++) {
                if (P_END.matcher(lines.get(i)).find()) {
                    iE = i;
                    break;
                }
            }
            if (iE < 0) iE = Math.min(lines.size(), iT + 8);
            List<String> nameParts = new ArrayList<>();
            boolean stop = false;
            for (int i = iT; i < iE; i++) {
                String l = lines.get(i);
                if (i == iT) l = l.replaceFirst("(?i)^Tujuan\\s*", "");
                l = l.replaceFirst("^[KkXx]?BRI\\s+", "").trim();
                if (l.length() < 3 || P_LOGO.matcher(l).find()) continue;
                String compact = l.replaceAll("\\s", "");
                if (P_MASKED.matcher(compact).matches() && digits(compact) >= 4) {
                    r.rek = compact;
                } else if (P_PT.matcher(l).find()) {
                    stop = true;
                } else if (P_BANK.matcher(l).find()) {
                    r.bank = l.toUpperCase(Locale.ROOT);
                    stop = true;
                } else if (!stop) {
                    nameParts.add(l);
                }
            }
            StringBuilder nb = new StringBuilder();
            for (String s : nameParts) {
                if (nb.length() > 0) nb.append(' ');
                nb.append(s);
            }
            r.penerima = nb.toString();
        }

        if (r.rek.isEmpty()) {
            for (String l : lines) {
                String c = l.replaceAll("\\s", "");
                if (c.matches("\\d{10,}") && !c.equals(r.noref)) {
                    r.rek = c;
                    break;
                }
            }
        }

        if (!r.rek.isEmpty() && r.bank.isEmpty()) {
            String hit = null;
            if (prefixMap != null) {
                for (String[] pr : prefixMap) {
                    if (r.rek.startsWith(pr[0])) {
                        hit = pr[1];
                        break;
                    }
                }
            }
            if (hit != null) r.bank = hit.toUpperCase(Locale.ROOT);
            else if (r.jenis.toUpperCase(Locale.ROOT).contains("BRIVA")) r.bank = "BRIVA";
        }
        return r;
    }
}
