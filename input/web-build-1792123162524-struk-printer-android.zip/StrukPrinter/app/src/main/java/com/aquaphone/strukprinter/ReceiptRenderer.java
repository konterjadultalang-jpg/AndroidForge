package com.aquaphone.strukprinter;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;

import java.util.List;

/** Menggambar struk menjadi bitmap. Bitmap yang sama dipakai untuk preview dan cetak. */
public final class ReceiptRenderer {

    private static Typeface regular;
    private static Typeface bold;

    private ReceiptRenderer() {}

    private static synchronized void loadFonts(Context c) {
        if (regular != null) return;
        try {
            regular = Typeface.createFromAsset(c.getAssets(), "fonts/DejaVuSansMono.ttf");
            bold = Typeface.createFromAsset(c.getAssets(), "fonts/DejaVuSansMono-Bold.ttf");
        } catch (Exception e) {
            regular = Typeface.MONOSPACE;
            bold = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);
        }
    }

    /**
     * @param scale 1 untuk cetak (384 titik = kertas 58mm), lebih besar untuk preview yang tajam.
     */
    public static Bitmap render(Context c, List<ReceiptLayout.Line> lines, int width, boolean thick, int scale) {
        loadFonts(c);
        final int dots = 384 * scale;
        final int cw = Math.max(1, dots / width);
        final float fs = cw / 0.602f;
        final int pad = 8 * scale;
        final int lh = Math.round(fs + 8 * scale);

        int h = 2 * pad;
        for (ReceiptLayout.Line l : lines) h += lh * (l.size == 2 ? 2 : 1);

        Bitmap bmp = Bitmap.createBitmap(dots, h, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(bmp);
        cv.drawColor(Color.WHITE);

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(Color.BLACK);
        p.setTextAlign(Paint.Align.CENTER);

        final int x0 = (dots - cw * width) / 2;
        float y = pad;
        for (ReceiptLayout.Line l : lines) {
            int sz = l.size == 2 ? 2 : 1;
            p.setTypeface(l.bold ? bold : regular);
            p.setTextSize(fs * sz);
            Paint.FontMetrics fm = p.getFontMetrics();
            float rowH = lh * sz;
            float base = y + (rowH - (fm.descent - fm.ascent)) / 2f - fm.ascent;
            float adv = cw * sz;
            String t = l.text;
            for (int i = 0; i < t.length(); i++) {
                char ch = t.charAt(i);
                if (ch == ' ') continue;
                float x = x0 + i * adv + adv / 2f;
                String s = String.valueOf(ch);
                cv.drawText(s, x, base, p);
                if (thick && !l.bold) cv.drawText(s, x + 0.6f * scale, base, p);
            }
            y += rowH;
        }
        return bmp;
    }
}
