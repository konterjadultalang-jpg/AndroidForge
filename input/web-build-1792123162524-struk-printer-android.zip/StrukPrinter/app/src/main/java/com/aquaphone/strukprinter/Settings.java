package com.aquaphone.strukprinter;

import android.content.Context;
import android.content.SharedPreferences;

/** Pengaturan toko dan printer, disimpan di perangkat. */
public class Settings {
    public String toko;
    public String desc1;
    public String desc2;
    public String catatan;
    public String tid;
    public String prefix;
    public String printerMac;
    public String printerName;
    public int width;
    public boolean thick;

    private static final String PREFS = "struk_settings";

    public static Settings load(Context c) {
        SharedPreferences sp = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Settings s = new Settings();
        s.toko = sp.getString("toko", "NAMA TOKO");
        s.desc1 = sp.getString("desc1", "Melayani transfer bank, e-wallet, dan pembayaran tagihan.");
        s.desc2 = sp.getString("desc2", "");
        s.catatan = sp.getString("catatan", "");
        s.tid = sp.getString("tid", "61D23B");
        s.prefix = sp.getString("prefix", "13282=DANA");
        s.printerMac = sp.getString("printerMac", "");
        s.printerName = sp.getString("printerName", "");
        s.width = Math.min(48, Math.max(20, sp.getInt("width", 32)));
        s.thick = sp.getBoolean("thick", true);
        return s;
    }

    public void save(Context c) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString("toko", toko)
                .putString("desc1", desc1)
                .putString("desc2", desc2)
                .putString("catatan", catatan)
                .putString("tid", tid)
                .putString("prefix", prefix)
                .putString("printerMac", printerMac)
                .putString("printerName", printerName)
                .putInt("width", Math.min(48, Math.max(20, width)))
                .putBoolean("thick", thick)
                .apply();
    }
}
