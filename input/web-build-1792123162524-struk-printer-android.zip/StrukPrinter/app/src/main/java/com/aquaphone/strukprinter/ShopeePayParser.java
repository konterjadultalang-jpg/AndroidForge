package com.aquaphone.strukprinter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Membaca teks hasil OCR struk ShopeePay (Kirim Ke sesama pengguna ShopeePay). */
public final class ShopeePayParser {

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final Pattern P_DATE = Pattern.compile("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?\\s+(\\d{4})\\D{0,6}?(\\d{1,2})[:.](\\d{2})");
    private static final Pattern P_AMOUNT_LINE = Pattern.compile("^R[pP]\\s*([\\d.,]+)\\s*$", Pattern.MULTILINE);
    private static final Pattern P_AMOUNT_ANY = Pattern.compile("R[pP]\\s*([\\d.,]+)");
    private static final Pattern P_ADMIN = Pattern.compile("Biaya\\s+(?:Admin|Layanan)\\s*R[pP]\\s*([\\d.,]+)", CI);
    private static final Pattern P_KIRIM = Pattern.compile("^Kirim\\s+Ke\\b\\s*", CI);
    private static final Pattern P_SN = Pattern.compile("^Order\\s+SN\\b\\s*", CI);
    private static final Pattern P_SN_LINE = Pattern.compile("^[A-Z0-9]{4,}$");
    private static final Pattern P_NUMTOKEN = Pattern.compile("^[\\d*\u2022-]*\\d[\\d*\u2022-]*$");

    /** Batas aman panjang Order SN (aslinya sekitar 29 karakter). */
    static final int SN_MAX = 40;

    private ShopeePayParser() {}

    private static String p2(int n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }

    public static boolean looksLikeShopeePay(String raw) {
        return raw != null && Pattern.compile("Shopee\\s*Pay|Order\\s+SN|Rincian\\s+Referensi|Dikirim\\s+Dari|Waktu\\s+Selesai", CI).matcher(raw).find();
    }

    public static Receipt parse(String raw) {
        Receipt r = new Receipt();
        r.sumber = "ShopeePay";
        r.bank = "SHOPEEPAY";
        r.jenis = "Kirim Ke";
        List<String> lines = new ArrayList<>();
        if (raw != null) {
            for (String a : raw.replace("\r", "").split("\n")) {
                String t = a.trim();
                if (!t.isEmpty()) lines.add(t);
            }
        }
        StringBuilder fb = new StringBuilder();
        for (int i = 0; i < lines.size(); i++) {
            if (i > 0) fb.append('\n');
            fb.append(lines.get(i));
        }
        String flat = fb.toString();

        Matcher m = P_DATE.matcher(flat);
        while (m.find()) {
            Integer mo = BrimoParser.month(m.group(2));
            if (mo != null) {
                r.tanggal = m.group(3) + "-" + p2(mo) + "-" + p2(Integer.parseInt(m.group(1)));
                r.waktu = p2(Integer.parseInt(m.group(4))) + ":" + m.group(5) + ":00";
                break;
            }
        }

        m = P_AMOUNT_LINE.matcher(flat);
        if (m.find()) {
            r.nominal = BrimoParser.toNum(m.group(1));
        } else {
            m = P_AMOUNT_ANY.matcher(flat);
            if (m.find()) r.nominal = BrimoParser.toNum(m.group(1));
        }
        m = P_ADMIN.matcher(flat);
        r.admin = m.find() ? BrimoParser.toNum(m.group(1)) : 0;

        // "Kirim Ke  aris tri 333 444": nama di depan, angka di belakang dianggap nomor tujuan
        for (int i = 0; i < lines.size(); i++) {
            Matcher k = P_KIRIM.matcher(lines.get(i));
            if (!k.find()) continue;
            String v = lines.get(i).substring(k.end()).trim();
            if (v.isEmpty() && i + 1 < lines.size()) v = lines.get(i + 1).trim();
            String[] tk = v.split("\\s+");
            int end = tk.length;
            while (end > 0 && P_NUMTOKEN.matcher(tk[end - 1]).matches()) end--;
            StringBuilder name = new StringBuilder();
            for (int t = 0; t < end; t++) {
                if (name.length() > 0) name.append(' ');
                name.append(tk[t]);
            }
            StringBuilder num = new StringBuilder();
            for (int t = end; t < tk.length; t++) num.append(tk[t]);
            r.penerima = name.toString();
            r.rek = num.toString();
            break;
        }

        // Order SN: bisa terpecah ke baris berikutnya, digabung jadi satu
        for (int i = 0; i < lines.size(); i++) {
            Matcher s = P_SN.matcher(lines.get(i));
            if (!s.find()) continue;
            StringBuilder sn = new StringBuilder(lines.get(i).substring(s.end()).replaceAll("\\s", ""));
            int j = i + 1;
            while (sn.length() < SN_MAX && j < lines.size() && P_SN_LINE.matcher(lines.get(j).replaceAll("\\s", "")).matches()) {
                sn.append(lines.get(j).replaceAll("\\s", ""));
                j++;
            }
            if (sn.length() > 0) r.noref = sn.toString().toUpperCase(Locale.ROOT);
            break;
        }
        if (r.noref.isEmpty()) {
            Matcher n = Pattern.compile("\\b[A-Z0-9]{16,}\\b").matcher(flat);
            if (n.find()) r.noref = n.group();
        }
        return r;
    }
}
