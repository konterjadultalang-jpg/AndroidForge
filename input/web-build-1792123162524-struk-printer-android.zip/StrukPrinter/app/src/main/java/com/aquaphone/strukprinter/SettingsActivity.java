package com.aquaphone.strukprinter;

import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class SettingsActivity extends Activity {

    private static final int REQ_BT = 21;
    private static final int TEAL = Color.parseColor("#12677D");

    private Settings s;
    private EditText eToko, eDesc1, eDesc2, eCatatan, eTid, eWidth, ePrefix;
    private CheckBox cThick;
    private TextView tPrinter;

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        s = Settings.load(this);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#E6EAED"));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setBackgroundColor(TEAL);
        header.setPadding(dp(16), dp(10), dp(8), dp(10));
        TextView title = new TextView(this);
        title.setText("Pengaturan");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button done = new Button(this);
        done.setText("Selesai");
        done.setAllCaps(false);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        header.addView(done, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(header, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        ScrollView sv = new ScrollView(this);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(16), dp(8), dp(16), dp(24));
        sv.addView(body, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // Printer
        heading(body, "Printer");
        tPrinter = new TextView(this);
        tPrinter.setTextSize(15);
        body.addView(tPrinter, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button pick = new Button(this);
        pick.setText("Pilih printer Bluetooth");
        pick.setAllCaps(false);
        pick.setTextColor(Color.WHITE);
        pick.setBackgroundColor(TEAL);
        pick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickPrinter();
            }
        });
        body.addView(pick, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView hint = new TextView(this);
        hint.setText("Pasangkan printer dulu lewat pengaturan Bluetooth HP, baru pilih di sini.");
        hint.setTextSize(12);
        hint.setTextColor(Color.parseColor("#5B6B78"));
        body.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // Toko
        heading(body, "Toko");
        eToko = field(body, "Nama toko (dicetak besar)", false, false);
        eDesc1 = field(body, "Deskripsi toko, paragraf 1", false, true);
        eDesc2 = field(body, "Deskripsi toko, paragraf 2", false, true);
        eCatatan = field(body, "Catatan footer (kosongkan jika tidak dipakai)", false, false);
        eTid = field(body, "TID", false, false);

        // Cetak
        heading(body, "Cetak");
        eWidth = field(body, "Lebar baris (karakter, 32 untuk kertas 58mm)", true, false);
        cThick = new CheckBox(this);
        cThick.setText("Cetak lebih tebal dan gelap");
        body.addView(cThick, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ePrefix = field(body, "Awalan BRIVA menjadi nama bank (satu per baris, contoh 13282=DANA)", false, true);

        eToko.setText(s.toko);
        eDesc1.setText(s.desc1);
        eDesc2.setText(s.desc2);
        eCatatan.setText(s.catatan);
        eTid.setText(s.tid);
        eWidth.setText(String.valueOf(s.width));
        cThick.setChecked(s.thick);
        ePrefix.setText(s.prefix);
        showPrinter();

        setContentView(root);
    }

    private void heading(LinearLayout parent, String text) {
        TextView h = new TextView(this);
        h.setText(text);
        h.setTextSize(16);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(18);
        parent.addView(h, lp);
    }

    private EditText field(LinearLayout parent, String label, boolean numeric, boolean multiline) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextColor(Color.parseColor("#5B6B78"));
        tv.setTextSize(13);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(10);
        parent.addView(tv, lp);
        EditText et = new EditText(this);
        if (numeric) {
            et.setInputType(InputType.TYPE_CLASS_NUMBER);
            et.setSingleLine(true);
        } else if (multiline) {
            et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            et.setMinLines(2);
        } else {
            et.setSingleLine(true);
        }
        parent.addView(et, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return et;
    }

    private void showPrinter() {
        if (s.printerMac == null || s.printerMac.isEmpty()) {
            tPrinter.setText("Belum ada printer dipilih.");
        } else {
            String n = (s.printerName == null || s.printerName.isEmpty()) ? "Printer" : s.printerName;
            tPrinter.setText(n + " (" + s.printerMac + ")");
        }
    }

    private void saveFields() {
        s.toko = eToko.getText().toString();
        s.desc1 = eDesc1.getText().toString();
        s.desc2 = eDesc2.getText().toString();
        s.catatan = eCatatan.getText().toString();
        s.tid = eTid.getText().toString();
        s.prefix = ePrefix.getText().toString();
        s.thick = cThick.isChecked();
        int w = 32;
        try {
            w = Integer.parseInt(eWidth.getText().toString().trim());
        } catch (Exception ignored) {
        }
        s.width = Math.min(48, Math.max(20, w));
        s.save(this);
    }

    @Override
    protected void onPause() {
        super.onPause();
        saveFields();
    }

    @SuppressWarnings("MissingPermission")
    private void pickPrinter() {
        if (!BtPrinter.hasPermission(this)) {
            BtPrinter.requestPermission(this, REQ_BT);
            return;
        }
        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null || !ad.isEnabled()) {
            Toast.makeText(this, "Nyalakan Bluetooth dulu.", Toast.LENGTH_LONG).show();
            return;
        }
        Set<BluetoothDevice> bonded = ad.getBondedDevices();
        final List<BluetoothDevice> devs = new ArrayList<>(bonded);
        if (devs.isEmpty()) {
            Toast.makeText(this, "Belum ada perangkat terpasang. Pasangkan printer di pengaturan Bluetooth HP.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[devs.size()];
        for (int i = 0; i < devs.size(); i++) {
            BluetoothDevice d = devs.get(i);
            names[i] = (d.getName() == null ? "Perangkat" : d.getName()) + "\n" + d.getAddress();
        }
        new AlertDialog.Builder(this)
                .setTitle("Pilih printer")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        BluetoothDevice d = devs.get(which);
                        s.printerMac = d.getAddress();
                        s.printerName = d.getName() == null ? "" : d.getName();
                        saveFields();
                        showPrinter();
                    }
                })
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            pickPrinter();
        }
    }
}
