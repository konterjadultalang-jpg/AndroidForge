package com.example.ytsimple

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.YouTubePlayer
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.listeners.AbstractYouTubePlayerListener
import com.pierfrancescosoffritti.androidyoutubeplayer.core.player.views.YouTubePlayerView
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

// Shorts bisa sampai 3 menit, jadi hanya video di atas batas ini yang ditampilkan
const val MIN_DETIK = 180

class MainActivity : AppCompatActivity() {

    data class Vid(val id: String, val title: String)

    private val hasil = mutableListOf<Vid>()
    private var player: YouTubePlayer? = null
    private lateinit var adapter: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val pv = YouTubePlayerView(this)
        lifecycle.addObserver(pv)
        pv.addYouTubePlayerListener(object : AbstractYouTubePlayerListener() {
            override fun onReady(youTubePlayer: YouTubePlayer) { player = youTubePlayer }
        })

        val box = EditText(this).apply {
            hint = "Cari video…"
            setSingleLine()
            imeOptions = EditorInfo.IME_ACTION_SEARCH
        }

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf<String>())
        val list = ListView(this).apply { this.adapter = this@MainActivity.adapter }

        root.addView(pv, LinearLayout.LayoutParams(-1, -2))
        root.addView(box, LinearLayout.LayoutParams(-1, -2))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        box.setOnEditorActionListener { v, _, _ ->
            val q = v.text.toString().trim()
            if (q.isNotEmpty()) cari(q)
            true
        }
        list.setOnItemClickListener { _, _, pos, _ ->
            player?.loadVideo(hasil[pos].id, 0f)
        }
    }

    private fun cari(q: String) = Thread {
        try {
            val key = BuildConfig.API_KEY
            val s = JSONObject(
                ambil(
                    "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video" +
                        "&maxResults=40&q=${URLEncoder.encode(q, "UTF-8")}&key=$key"
                )
            ).getJSONArray("items")

            val ids = (0 until s.length()).joinToString(",") {
                s.getJSONObject(it).getJSONObject("id").getString("videoId")
            }

            val v = JSONObject(
                ambil(
                    "https://www.googleapis.com/youtube/v3/videos?part=contentDetails,snippet" +
                        "&id=$ids&key=$key"
                )
            ).getJSONArray("items")

            val baru = mutableListOf<Vid>()
            for (i in 0 until v.length()) {
                val o = v.getJSONObject(i)
                val durasi = detik(o.getJSONObject("contentDetails").getString("duration"))
                val judul = o.getJSONObject("snippet").getString("title")
                if (durasi > MIN_DETIK && !judul.contains("#short", ignoreCase = true)) {
                    baru.add(Vid(o.getString("id"), judul))
                }
            }

            runOnUiThread {
                hasil.clear(); hasil.addAll(baru)
                adapter.clear(); adapter.addAll(baru.map { it.title })
            }
        } catch (e: Exception) {
            runOnUiThread { Toast.makeText(this, "Gagal: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }.start()

    private fun ambil(url: String): String = URL(url).readText()

    // Contoh format: PT1H2M30S
    private fun detik(iso: String): Int {
        val m = Regex("PT(?:(\\d+)H)?(?:(\\d+)M)?(?:(\\d+)S)?").matchEntire(iso) ?: return 0
        val (h, mn, s) = m.destructured
        return (h.toIntOrNull() ?: 0) * 3600 + (mn.toIntOrNull() ?: 0) * 60 + (s.toIntOrNull() ?: 0)
    }
}
