plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ytsimple"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.ytsimple"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        // API key diambil dari secret GitHub bernama YT_API_KEY (atau variabel lingkungan saat build lokal)
        val key = System.getenv("YT_API_KEY") ?: "ISI_API_KEY"
        buildConfigField("String", "API_KEY", "\"$key\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.pierfrancescosoffritti.androidyoutubeplayer:core:12.1.0")
}
