package id.aquaphone.struk

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.ViewGroup
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.OutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private lateinit var merchant: EditText
    private lateinit var customer: EditText
    private lateinit var amount: EditText
    private lateinit var date: EditText
    private lateinit var note: EditText
    private lateinit var ocrResult: EditText
    private lateinit var preview: TextView
    private lateinit var printerStatus: TextView
    private var selectedImage: Uri? = null
    private var selectedDevice: BluetoothDevice? = null
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedImage = uri
            runOcr(uri)
        }
    }

    private val permissionRequest = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.any { it }) choosePairedPrinter()
        else toast("Izin Bluetooth tidak diberikan.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updatePreview()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(layout)
        setContentView(scroll)

        layout.addView(TextView(this).apply {
            text = "AQUA PHONE STRUK"
            textSize = 25f
            setTextColor(0xFF087E8B.toInt())
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        layout.addView(TextView(this).apply {
            text = "Pembuat struk transaksi • OCR • Printer thermal 58 mm"
            textSize = 13f
        })
        layout.addView(TextView(this).apply {
            text = "Catatan: aplikasi ini membuat struk informasi transaksi, bukan bukti transfer resmi bank."
            textSize = 13f
            setPadding(0, dp(10), 0, dp(10))
        })

        addField(layout, "Nama toko / usaha", "AQUA PHONE") { merchant = it }
        addField(layout, "Nama pelanggan / pihak terkait", "") { customer = it }
        addField(layout, "Nominal (angka)", "") { amount = it; it.inputType = android.text.InputType.TYPE_CLASS_NUMBER }
        addField(layout, "Tanggal transaksi", SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("id", "ID")).format(Date())) { date = it }
        addField(layout, "Catatan transaksi", "") { note = it }

        addButton(layout, "Pilih screenshot & baca otomatis (OCR)") {
            imagePicker.launch("image/*")
        }
        addField(layout, "Teks hasil OCR (bisa diperiksa/diedit)", "") { ocrResult = it }

        addButton(layout, "Isi data dari hasil OCR") { parseOcrIntoFields() }
        addButton(layout, "Perbarui pratinjau struk") { updatePreview() }

        preview = TextView(this).apply {
            textSize = 14f
            typeface = android.graphics.Typeface.MONOSPACE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFF0F3F4.toInt())
        }
        layout.addView(preview, marginParams())

        addButton(layout, "Pilih printer Bluetooth yang sudah dipasangkan") { requestBluetoothThenChoose() }
        printerStatus = TextView(this).apply { text = "Printer: belum dipilih"; textSize = 13f }
        layout.addView(printerStatus)
        addButton(layout, "Cetak struk 58 mm") { printReceipt() }
    }

    private fun addField(parent: LinearLayout, label: String, initial: String, assign: (EditText) -> Unit) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setPadding(0, dp(10), 0, dp(4))
        })
        val edit = EditText(this).apply {
            setText(initial)
            textSize = 15f
            singleLine = false
            minHeight = dp(46)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        parent.addView(edit, marginParams())
        assign(edit)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        parent.addView(button, marginParams())
    }

    private fun marginParams(): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
            bottomMargin = dp(4)
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun runOcr(uri: Uri) {
        try {
            val image = if (Build.VERSION.SDK_INT >= 28) {
                val source = ImageDecoder.createSource(contentResolver, uri)
                ImageDecoder.decodeBitmap(source)
            } else {
                @Suppress("DEPRECATION")
                MediaStore.Images.Media.getBitmap(contentResolver, uri)
            }
            val input = InputImage.fromBitmap(image, 0)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                .process(input)
                .addOnSuccessListener { result ->
                    ocrResult.setText(result.text)
                    parseOcrIntoFields()
                    toast("OCR selesai. Periksa kembali data sebelum mencetak.")
                }
                .addOnFailureListener { e -> toast("OCR gagal: ${e.localizedMessage ?: "coba gambar lain"}") }
        } catch (e: Exception) {
            toast("Gambar tidak dapat dibaca: ${e.localizedMessage ?: "kesalahan"}")
        }
    }

    private fun parseOcrIntoFields() {
        val raw = ocrResult.text ?: ""
        if (raw.isBlank()) {
            toast("Pilih gambar atau masukkan teks OCR terlebih dahulu.")
            return
        }
        // OCR hanya membantu mengisi draf; data keuangan wajib diverifikasi pengguna.
        val moneyRegex = Regex("""(?:Rp\s*)?([0-9][0-9.,]{2,})""", RegexOption.IGNORE_CASE)
        val amounts = moneyRegex.findAll(raw).mapNotNull { m ->
            val digits = m.groupValues[1].filter { it.isDigit() }
            digits.toLongOrNull()
        }.filter { it >= 1000 }.toList()
        if (amount.text.isNullOrBlank() && amounts.isNotEmpty()) amount.setText(amounts.maxOrNull().toString())

        val dateRegex = Regex("""\b([0-3]?\d[-/ ][01]?\d[-/ ](?:20)?\d{2})(?:\s+([0-2]?\d:[0-5]\d))?\b""")
        val foundDate = dateRegex.find(raw)
        if (foundDate != null) date.setText(foundDate.value.replace('/', '-'))

        if (customer.text.isNullOrBlank()) {
            val candidate = raw.lines().map { it.trim() }
                .firstOrNull { it.length in 3..40 && it.any(Char::isLetter) &&
                    !it.contains("transfer", true) && !it.contains("berhasil", true) &&
                    !it.contains("saldo", true) && !it.contains("bank", true) &&
                    !it.contains("rp", true) }
            if (candidate != null) customer.setText(candidate)
        }
        updatePreview()
        toast("Draf diisi dari OCR. Pastikan nominal, nama, dan tanggal benar.")
    }

    private fun receiptText(): String {
        val money = amount.text.toString().trim().toLongOrNull()?.let {
            NumberFormat.getNumberInstance(Locale("id", "ID")).format(it)
        } ?: amount.text.toString().trim().ifBlank { "Belum diisi" }
        return """
            ${merchant.text.toString().ifBlank { "AQUA PHONE" }.uppercase(Locale("id", "ID"))}
            --------------------------------
            STRUK INFORMASI TRANSAKSI
            BUKAN BUKTI TRANSFER BANK
            --------------------------------
            Pihak terkait : ${customer.text.toString().ifBlank { "-"}}
            Nominal       : Rp $money
            Tanggal       : ${date.text.toString().ifBlank { "-"}}
            Catatan       : ${note.text.toString().ifBlank { "-"}}
            --------------------------------
            Struk dibuat oleh AQUA PHONE STRUK
            Verifikasi transaksi pada aplikasi bank.

        """.trimIndent()
    }

    private fun updatePreview() {
        if (::preview.isInitialized) preview.text = receiptText()
    }

    private fun requestBluetoothThenChoose() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_CONNECT)
            if (needed.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
                permissionRequest.launch(needed)
                return
            }
        }
        choosePairedPrinter()
    }

    private fun choosePairedPrinter() {
        try {
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter == null) {
                toast("Perangkat ini tidak mendukung Bluetooth.")
                return
            }
            if (!adapter.isEnabled) {
                startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                return
            }
            val devices = adapter.bondedDevices?.toList().orEmpty()
            if (devices.isEmpty()) {
                toast("Pasangkan printer lewat Pengaturan Bluetooth Android terlebih dahulu.")
                return
            }
            val labels = devices.map { "${it.name ?: "Perangkat"} — ${it.address}" }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle("Pilih printer yang sudah dipasangkan")
                .setItems(labels) { _, which ->
                    selectedDevice = devices[which]
                    printerStatus.text = "Printer: ${selectedDevice?.name ?: selectedDevice?.address}"
                    toast("Printer dipilih.")
                }
                .setNegativeButton("Batal", null)
                .show()
        } catch (e: SecurityException) {
            toast("Izin Bluetooth diperlukan.")
        }
    }

    private fun printReceipt() {
        updatePreview()
        val device = selectedDevice
        if (device == null) {
            toast("Pilih printer Bluetooth terlebih dahulu.")
            return
        }
        val content = receiptText()
        thread {
            var socket: BluetoothSocket? = null
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                    ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread { toast("Izin Bluetooth belum diberikan.") }
                    return@thread
                }
                socket = device.createRfcommSocketToServiceRecord(sppUuid)
                socket.connect()
                val out: OutputStream = socket.outputStream
                out.write(byteArrayOf(0x1B, 0x40)) // ESC @: initialize printer
                out.write(byteArrayOf(0x1B, 0x61, 0x00)) // left align
                out.write(content.toByteArray(Charsets.UTF_8))
                out.write("\n\n\n".toByteArray(Charsets.UTF_8))
                out.write(byteArrayOf(0x1D, 0x56, 0x00)) // cut command (ignored by printers without cutter)
                out.flush()
                runOnUiThread { toast("Perintah cetak dikirim.") }
            } catch (e: Exception) {
                runOnUiThread { toast("Gagal mencetak: ${e.localizedMessage ?: "periksa printer dan koneksi"}") }
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
