package com.aquaphone.strukprinter

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.lifecycle.MutableLiveData
import java.util.concurrent.Executors

/**
 * Memproses struk yang dibagikan di thread latar belakang milik proses (bukan milik Activity),
 * sehingga tetap jalan saat aplikasi tidak dibuka, dan tidak diulang saat aplikasi dibuka lagi.
 */
object Processor {
    class State(
        val loading: Boolean,
        val raw: String? = null,
        val detected: Sumber? = null,
        val error: String? = null
    )

    val state = MutableLiveData<State>()
    private val exec = Executors.newSingleThreadExecutor()
    private var lastKey: String? = null

    @Suppress("DEPRECATION")
    private fun streamUri(i: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else i.getParcelableExtra(Intent.EXTRA_STREAM) as? Uri

    @Synchronized
    fun submit(ctx: Context, intent: Intent) {
        val app = ctx.applicationContext
        val uri = streamUri(intent)
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        val key = uri?.toString() ?: text ?: return
        if (key == lastKey) return // sudah diproses / sedang diproses
        lastKey = key
        state.postValue(State(loading = true))
        val mime = intent.type
        exec.execute {
            try {
                val raw = if (uri != null) TextExtractor.fromUri(app, uri, mime) else text!!
                state.postValue(State(false, raw, Detector.detect(raw)))
            } catch (e: Exception) {
                lastKey = null
                state.postValue(State(false, error = e.message ?: "Gagal membaca struk"))
            }
        }
    }
}
