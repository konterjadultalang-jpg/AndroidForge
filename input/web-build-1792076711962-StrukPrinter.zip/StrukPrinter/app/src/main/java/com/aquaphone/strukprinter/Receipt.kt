package com.aquaphone.strukprinter

/** Satu template cetak untuk semua aplikasi, lebar 32 karakter (kertas 58mm). */
object Receipt {
    const val W = 32

    fun wrap(s: String, w: Int): List<String> {
        val out = mutableListOf<String>()
        var cur = ""
        for (word in s.trim().split(Regex("\\s+"))) {
            var wd = word
            while (wd.length > w) {
                if (cur.isNotEmpty()) { out.add(cur); cur = "" }
                out.add(wd.take(w)); wd = wd.drop(w)
            }
            cur = when {
                cur.isEmpty() -> wd
                cur.length + 1 + wd.length <= w -> "$cur $wd"
                else -> { out.add(cur); wd }
            }
        }
        if (cur.isNotEmpty()) out.add(cur)
        return out
    }

    private fun pair(label: String, value: String, bold: Boolean): List<Line> {
        if (value.isEmpty()) return wrap(label, W).map { Line(it, 0, bold) }
        if (label.length + 1 + value.length <= W) {
            return listOf(Line(label + " ".repeat(W - label.length - value.length) + value, 0, bold))
        }
        return wrap(label, W).map { Line(it, 0, bold) } +
            wrap(value, W).map { Line(it.padStart(W), 0, bold) }
    }

    fun build(nama: String, deskripsi: String, rows: List<Row>): List<Line> {
        val out = mutableListOf<Line>()
        val sep = Line("-".repeat(W))

        // Nama toko (diperbesar) + deskripsi 2 paragraf
        if (nama.isNotBlank()) wrap(nama, W / 2).forEach { out.add(Line(it, 1, true, 2)) }
        val paras = deskripsi.split(Regex("\n\\s*\n")).map { it.replace("\n", " ").trim() }
            .filter { it.isNotEmpty() }.take(2)
        paras.forEachIndexed { idx, p ->
            if (idx > 0) out.add(Line(""))
            wrap(p, W).forEach { out.add(Line(it, 1)) }
        }
        if (out.isNotEmpty()) out.add(sep)

        val judul = rows.firstOrNull { it.label.equals("judul", true) }
        val tgl = rows.firstOrNull { it.label.equals("tanggal", true) }
        if (judul != null) wrap(judul.value.uppercase(), W).forEach { out.add(Line(it, 1, true)) }
        if (tgl != null) wrap(tgl.value, W).forEach { out.add(Line(it, 1)) }
        if (judul != null || tgl != null) out.add(sep)

        for (r in rows) {
            if (r === judul || r === tgl) continue
            val bold = r.label.equals("nominal", true) || r.label.equals("total", true)
            out.addAll(pair(r.label, r.value, bold))
        }
        out.add(sep)
        return out
    }

    fun preview(lines: List<Line>): String = lines.joinToString("\n") { it.padded() }
}
