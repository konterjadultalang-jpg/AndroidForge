package com.aquaphone.strukprinter

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import com.google.android.material.chip.ChipGroup

class MainActivity : AppCompatActivity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvPreview: TextView
    private lateinit var etData: EditText
    private lateinit var chipGroup: ChipGroup

    private var raw: String? = null
    private var updating = false
    private var pending: (() -> Unit)? = null

    private val prefs by lazy { getSharedPreferences("struk", MODE_PRIVATE) }

    private val chipMap by lazy {
        mapOf(
            R.id.chipBrimo to Sumber.BRIMO,
            R.id.chipDana to Sumber.DANA,
            R.id.chipSuperbank to Sumber.SUPERBANK,
            R.id.chipSeabank to Sumber.SEABANK,
            R.id.chipShopeepay to Sumber.SHOPEEPAY
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvStatus = findViewById(R.id.tvStatus)
        tvPreview = findViewById(R.id.tvPreview)
        etData = findViewById(R.id.etData)
        chipGroup = findViewById(R.id.chipGroup)

        chipGroup.setOnCheckedStateChangeListener { _, ids ->
            if (updating) return@setOnCheckedStateChangeListener
            val s = chipMap[ids.firstOrNull()] ?: return@setOnCheckedStateChangeListener
            loadRows(s)
        }
        etData.doAfterTextChanged { updatePreview() }

        findViewById<Button>(R.id.btnPrinter).setOnClickListener { withBtPermission { pilihPrinter() } }
        findViewById<Button>(R.id.btnToko).setOnClickListener { dialogToko() }
        findViewById<Button>(R.id.btnCetak).setOnClickListener { cetak() }

        Processor.state.observe(this) { render(it) }
        updatePreview()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND) Processor.submit(this, i)
    }

    private fun render(s: Processor.State) {
        when {
            s.loading -> tvStatus.text = "Membaca struk…"
            s.error != null -> tvStatus.text = "Gagal: ${s.error}"
            else -> {
                raw = s.raw
                val d = s.detected ?: Sumber.UMUM
                tvStatus.text = if (d == Sumber.UMUM)
                    "Format tidak dikenali. Pilih jenis struk secara manual."
                else "Terdeteksi: ${d.label}. Ketuk jenis lain bila salah."
                pilihChip(d)
                loadRows(d)
            }
        }
    }

    private fun pilihChip(s: Sumber) {
        updating = true
        val id = chipMap.entries.firstOrNull { it.value == s }?.key
        if (id != null) chipGroup.check(id) else chipGroup.clearCheck()
        updating = false
    }

    private fun loadRows(s: Sumber) {
        val r = raw ?: return
        etData.setText(Parser.toEditable(Parser.parse(r, s)))
    }

    private fun lines(): List<Line> = Receipt.build(
        prefs.getString("nama", "Nama Toko Anda") ?: "",
        prefs.getString("deskripsi", "") ?: "",
        Parser.fromEditable(etData.text.toString())
    )

    private fun updatePreview() {
        tvPreview.text = Receipt.preview(lines())
    }

    // ---------- Pengaturan toko ----------
    private fun dialogToko() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 24, 48, 0)
        }
        val n = EditText(this).apply {
            hint = "Nama toko"
            setText(prefs.getString("nama", "Nama Toko Anda"))
        }
        val d = EditText(this).apply {
            hint = "Deskripsi toko (2 paragraf, pisahkan dengan baris kosong)"
            minLines = 5
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(prefs.getString("deskripsi", ""))
        }
        box.addView(n)
        box.addView(d)
        AlertDialog.Builder(this)
            .setTitle("Pengaturan toko")
            .setView(box)
            .setPositiveButton("Simpan") { _, _ ->
                prefs.edit()
                    .putString("nama", n.text.toString())
                    .putString("deskripsi", d.text.toString())
                    .apply()
                updatePreview()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ---------- Bluetooth ----------
    private fun withBtPermission(block: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT)
            != PackageManager.PERMISSION_GRANTED
        ) {
            pending = block
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1)
            return
        }
        block()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            pending?.invoke()
        } else if (requestCode == 1) {
            toast("Izin Bluetooth diperlukan untuk mencetak")
        }
        pending = null
    }

    @SuppressLint("MissingPermission")
    private fun pilihPrinter() {
        val devs = BtPrinter.bonded(this)
        if (devs.isEmpty()) {
            toast("Belum ada printer yang dipasangkan. Pasangkan dulu di pengaturan Bluetooth HP.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Pilih printer")
            .setItems(devs.map { "${it.name}\n${it.address}" }.toTypedArray()) { _, i ->
                prefs.edit().putString("printer", devs[i].address).apply()
                toast("Printer dipilih: ${devs[i].name}")
            }
            .show()
    }

    private fun cetak() {
        withBtPermission {
            val addr = prefs.getString("printer", null)
            if (addr == null) {
                pilihPrinter()
            } else {
                val data = EscPos.encode(lines())
                val app = applicationContext
                Thread {
                    try {
                        BtPrinter.print(app, addr, data)
                        runOnUiThread { toast("Terkirim ke printer") }
                    } catch (e: Exception) {
                        runOnUiThread { toast("Gagal cetak: ${e.message}") }
                    }
                }.start()
            }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
