package com.aquaphone.strukprinter

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import java.util.UUID

object BtPrinter {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    @SuppressLint("MissingPermission")
    fun bonded(ctx: Context): List<BluetoothDevice> {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter ?: return emptyList()
        return adapter.bondedDevices?.toList() ?: emptyList()
    }

    @SuppressLint("MissingPermission")
    fun print(ctx: Context, address: String, data: ByteArray) {
        val adapter = ctx.getSystemService(BluetoothManager::class.java)?.adapter
            ?: throw IllegalStateException("Bluetooth tidak tersedia")
        if (!adapter.isEnabled) throw IllegalStateException("Bluetooth belum aktif")
        adapter.cancelDiscovery()
        val socket = adapter.getRemoteDevice(address).createRfcommSocketToServiceRecord(SPP)
        try {
            socket.connect()
            val out = socket.outputStream
            var off = 0
            while (off < data.size) {
                val n = minOf(512, data.size - off)
                out.write(data, off, n)
                off += n
                Thread.sleep(30)
            }
            out.flush()
            Thread.sleep(600)
        } finally {
            try { socket.close() } catch (_: Exception) {}
        }
    }
}
