package com.aquaphone.strukprinter

/** Mendeteksi aplikasi asal struk dari kata kunci pada teks hasil OCR. */
object Detector {
    private val kunci: Map<Sumber, List<Pair<String, Int>>> = mapOf(
        Sumber.BRIMO to listOf("brimo" to 3, "brlmo" to 3, "bank rakyat indonesia" to 2, "bri" to 1),
        Sumber.DANA to listOf("dana" to 2, "kirim uang" to 2, "dana id" to 1),
        Sumber.SHOPEEPAY to listOf("shopeepay" to 3, "shopee pay" to 3, "shopee" to 2),
        Sumber.SEABANK to listOf("seabank" to 3, "sea bank" to 3),
        Sumber.SUPERBANK to listOf("superbank" to 3, "super bank" to 3)
    )

    fun detect(raw: String): Sumber {
        // "Sumber Dana" muncul di banyak aplikasi; jangan dihitung sebagai DANA
        val t = raw.lowercase().replace("sumber dana", " ").replace("dana tujuan", " ")
        var best = Sumber.UMUM
        var skor = 0
        for ((s, ks) in kunci) {
            val n = ks.sumOf { (k, w) ->
                if (Regex("\\b" + Regex.escape(k) + "\\b").containsMatchIn(t)) w else 0
            }
            if (n > skor) { skor = n; best = s }
        }
        return best
    }
}
