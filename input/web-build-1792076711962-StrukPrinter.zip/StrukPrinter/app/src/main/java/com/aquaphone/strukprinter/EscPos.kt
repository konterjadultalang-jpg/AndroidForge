package com.aquaphone.strukprinter

import java.io.ByteArrayOutputStream

object EscPos {
    private fun ascii(s: String): ByteArray =
        s.map { if (it.code in 32..126) it else '?' }.joinToString("").toByteArray(Charsets.US_ASCII)

    fun encode(lines: List<Line>): ByteArray {
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0x1B, 0x40)) // init
        for (l in lines) {
            o.write(byteArrayOf(0x1B, 0x61, l.align.toByte()))
            o.write(byteArrayOf(0x1B, 0x45, if (l.bold) 1 else 0))
            o.write(byteArrayOf(0x1D, 0x21, if (l.scale == 2) 0x11 else 0x00))
            o.write(ascii(l.text))
            o.write(0x0A)
        }
        o.write(byteArrayOf(0x1B, 0x61, 0x00))
        o.write(byteArrayOf(0x1B, 0x45, 0x00))
        o.write(byteArrayOf(0x1D, 0x21, 0x00))
        o.write(byteArrayOf(0x1B, 0x64, 0x04)) // feed 4 baris
        return o.toByteArray()
    }
}
