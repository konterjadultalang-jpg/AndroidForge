package com.aquaphone.strukprinter

/**
 * Parser berbasis label: mencari label umum (Nominal, Penerima, dst) di teks OCR,
 * baik nilainya satu baris dengan label maupun di baris berikutnya.
 * Tata letak cetak tetap satu template (lihat Receipt).
 */
object Parser {
    private class F(val label: String, val alias: List<String>)

    private val fields = listOf(
        F("Tanggal", listOf("tanggal transaksi", "waktu transaksi", "tanggal", "tgl")),
        F("Jenis", listOf("jenis transaksi", "tipe transaksi", "jenis")),
        F("Sumber Dana", listOf("sumber dana", "rekening sumber", "metode pembayaran", "dibayar dengan")),
        F("Penerima", listOf("nama penerima", "penerima")),
        F("Bank Tujuan", listOf("bank tujuan", "bank penerima")),
        F("No. Rekening", listOf("no. rekening tujuan", "nomor rekening tujuan", "rekening tujuan",
            "no. rekening", "nomor rekening", "no rekening")),
        F("Nominal", listOf("nominal transfer", "jumlah transfer", "nominal", "jumlah")),
        F("Biaya", listOf("biaya admin", "biaya layanan", "biaya transaksi", "biaya")),
        F("Total", listOf("total transaksi", "total pembayaran", "total bayar", "total")),
        F("Catatan", listOf("catatan", "berita")),
        F("No. Ref", listOf("nomor referensi", "no. referensi", "no referensi", "no. ref", "no ref",
            "id transaksi", "no. transaksi", "nomor transaksi")),
        F("Status", listOf("status transaksi", "status"))
    )

    private val pairs = fields.flatMap { f -> f.alias.map { it to f } }.sortedByDescending { it.first.length }

    private val RP = Regex("""Rp\s?[\d.,]+""", RegexOption.IGNORE_CASE)
    private val TGL = Regex(
        """\d{1,2}\s+(jan|feb|mar|apr|mei|jun|jul|agu|ags|sep|okt|nov|des)[a-z]*\.?\s+\d{4}(,?\s*\d{1,2}[:.]\d{2}([:.]\d{2})?(\s*WIB)?)?""",
        RegexOption.IGNORE_CASE
    )
    private val TGL2 = Regex("""\d{1,2}[/-]\d{1,2}[/-]\d{4}(\s+\d{1,2}[:.]\d{2}([:.]\d{2})?)?""")
    private val STATUS = Regex("""berhasil|sukses|success|gagal|pending|diproses""", RegexOption.IGNORE_CASE)

    private fun match(line: String): Pair<F, String>? {
        val l = line.lowercase()
        for ((a, f) in pairs) {
            if (!l.startsWith(a)) continue
            if (l.length > a.length && l[a.length].isLetterOrDigit()) continue
            val rem = line.substring(a.length).trim().trimStart(':', '-', ' ').trim()
            return f to rem
        }
        return null
    }

    fun parse(teks: String, sumber: Sumber): List<Row> {
        val lines = teks.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val m = lines.map { match(it) }
        val h = LinkedHashMap<String, String>()
        fun put(k: String, v: String) {
            if (v.isNotBlank() && !h.containsKey(k)) h[k] = v.trim()
        }

        var i = 0
        while (i < lines.size) {
            val cur = m[i]
            if (cur == null) { i++; continue }
            if (cur.second.isNotEmpty()) { put(cur.first.label, cur.second); i++; continue }
            // Label tanpa nilai: kumpulkan blok label berurutan, lalu ambil nilai sesudahnya berurutan
            val block = mutableListOf<F>()
            var j = i
            while (j < lines.size && m[j] != null && m[j]!!.second.isEmpty()) {
                block.add(m[j]!!.first); j++
            }
            var v = j
            for (f in block) {
                if (v < lines.size && m[v] == null) { put(f.label, lines[v]); v++ } else break
            }
            i = j
        }

        if (!h.containsKey("Nominal")) RP.find(teks)?.let { put("Nominal", it.value) }
        if (!h.containsKey("Tanggal")) (TGL.find(teks) ?: TGL2.find(teks))?.let { put("Tanggal", it.value) }
        if (!h.containsKey("Status")) STATUS.find(teks)?.let {
            put("Status", it.value.replaceFirstChar { c -> c.uppercase() })
        }

        val rows = mutableListOf(Row("Judul", sumber.judul))
        h["Tanggal"]?.let { rows.add(Row("Tanggal", it)) }
        for (f in fields) {
            if (f.label == "Tanggal") continue
            h[f.label]?.let { rows.add(Row(f.label, it)) }
        }
        return rows
    }

    /** Teks editor "Label: Nilai" -> daftar Row */
    fun fromEditable(text: String): List<Row> =
        text.lines().filter { it.isNotBlank() }.map { ln ->
            val idx = ln.indexOf(':')
            if (idx < 0) Row(ln.trim(), "") else Row(ln.substring(0, idx).trim(), ln.substring(idx + 1).trim())
        }

    fun toEditable(rows: List<Row>): String = rows.joinToString("\n") { "${it.label}: ${it.value}" }
}
