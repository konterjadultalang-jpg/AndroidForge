package com.aquaphone.strukprinter

enum class Sumber(val label: String, val judul: String) {
    BRIMO("BRImo", "Transfer Berhasil"),
    DANA("DANA", "Transaksi Berhasil"),
    SUPERBANK("Superbank", "Transfer Berhasil"),
    SEABANK("SeaBank", "Transfer Berhasil"),
    SHOPEEPAY("ShopeePay", "Transaksi Berhasil"),
    UMUM("Umum", "Bukti Transaksi")
}

class Row(val label: String, val value: String)

/** align: 0 kiri, 1 tengah, 2 kanan. scale: 1 normal, 2 diperbesar. */
class Line(val text: String, val align: Int = 0, val bold: Boolean = false, val scale: Int = 1) {
    fun padded(): String {
        val w = Receipt.W / scale
        return when (align) {
            1 -> " ".repeat(maxOf(0, (w - text.length) / 2)) + text
            2 -> text.padStart(w)
            else -> text
        }
    }
}
