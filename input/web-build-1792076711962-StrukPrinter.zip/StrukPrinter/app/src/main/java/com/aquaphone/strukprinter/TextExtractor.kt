package com.aquaphone.strukprinter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** Gambar/PDF -> teks lewat OCR on-device (ML Kit). Dipanggil dari thread latar belakang. */
object TextExtractor {
    fun fromUri(ctx: Context, uri: Uri, mime: String?): String {
        val type = ctx.contentResolver.getType(uri) ?: mime ?: ""
        val bitmaps = if (type.contains("pdf")) renderPdf(ctx, uri) else listOf(decode(ctx, uri))
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        try {
            return bitmaps.joinToString("\n") { bmp ->
                Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0))).text
            }
        } finally {
            rec.close()
        }
    }

    private fun decode(ctx: Context, uri: Uri): Bitmap {
        val stream = ctx.contentResolver.openInputStream(uri)
            ?: throw IllegalStateException("Tidak bisa membuka file")
        return stream.use { BitmapFactory.decodeStream(it) }
            ?: throw IllegalStateException("Gambar tidak valid")
    }

    private fun renderPdf(ctx: Context, uri: Uri): List<Bitmap> {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
            ?: throw IllegalStateException("Tidak bisa membuka PDF")
        val renderer = PdfRenderer(pfd)
        try {
            val list = mutableListOf<Bitmap>()
            for (i in 0 until minOf(renderer.pageCount, 3)) {
                val page = renderer.openPage(i)
                try {
                    val bmp = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    list.add(bmp)
                } finally {
                    page.close()
                }
            }
            return list
        } finally {
            renderer.close()
            pfd.close()
        }
    }
}
