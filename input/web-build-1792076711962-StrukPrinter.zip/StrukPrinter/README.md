# Struk Printer (58mm Bluetooth)

Cetak struk transaksi BRImo, DANA, Superbank, SeaBank, dan ShopeePay ke printer thermal Bluetooth 58mm.

## Cara pakai
1. Pasangkan printer di pengaturan Bluetooth HP.
2. Di aplikasi bank/e-wallet, buka riwayat transaksi lalu Bagikan -> pilih "Struk Printer".
3. Aplikasi membaca struk (OCR), mendeteksi jenisnya, lalu menampilkan isi + pratinjau.
4. Edit bila perlu, tekan "Printer" (sekali, untuk memilih printer), lalu "Cetak".
5. "Toko" untuk mengubah nama toko (dicetak besar) dan deskripsi 2 paragraf.

## Build APK lewat GitHub
Upload semua isi folder ini ke repo GitHub (branch main). Buka tab Actions -> "Build APK" ->
setelah selesai, unduh artifact `struk-printer-apk` (berisi app-debug.apk).

## Menyesuaikan parser
- Kata kunci deteksi: `Detector.kt`
- Label yang dikenali per kolom: `Parser.kt` (daftar `fields`)
- Tata letak cetak: `Receipt.kt`
