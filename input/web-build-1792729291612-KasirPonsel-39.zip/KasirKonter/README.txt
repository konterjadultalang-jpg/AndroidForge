Kasir Ponsel - proyek Android (WebView)
Upload ZIP ini ke AndroidForge (Android APK, variant: auto atau debug).
Aplikasi ada di app/src/main/assets/index.html
