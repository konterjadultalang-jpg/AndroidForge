package com.konter.kasir;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 1001;
    private static final int REQ_SAVE_FILE = 1002;
    private static final int REQ_PICK_TREE = 1003;

    private WebView webView;
    private AlertDialog exitDialog;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingName;
    private String pendingContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Diperlukan agar tombol "Impor" (input type=file) bisa membuka pemilih file.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Pilih file CSV"), REQ_PICK_FILE);
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK_TREE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri u = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(u,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                } catch (Exception ignored) { }
                getSharedPreferences("kasir", MODE_PRIVATE).edit().putString("tree", u.toString()).apply();
                webView.evaluateJavascript("window.onFolderPicked && window.onFolderPicked()", null);
            }
            return;
        }

        if (requestCode == REQ_PICK_FILE) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQ_SAVE_FILE) {
            String content = pendingContent;
            pendingContent = null;
            pendingName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || content == null) {
                return; // dibatalkan
            }
            try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                os.write(content.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Backup berhasil disimpan", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        if (exitDialog != null && exitDialog.isShowing()) {
            return;
        }
        exitDialog = new AlertDialog.Builder(this)
                .setTitle("Keluar dari aplikasi?")
                .setMessage("Aplikasi akan di-minimize.")
                .setPositiveButton("Ya", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        moveTaskToBack(true);
                    }
                })
                .setNegativeButton("Tidak", null)
                .create();
        exitDialog.show();
    }

    /** Dipanggil dari JavaScript: membuka dialog "Simpan sebagai" agar pengguna memilih lokasi. */
    private class Bridge {
        @JavascriptInterface
        public boolean saveFile(final String filename, final String content) {
            pendingName = filename;
            pendingContent = content;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("text/csv");
                        intent.putExtra(Intent.EXTRA_TITLE, filename);
                        startActivityForResult(intent, REQ_SAVE_FILE);
                    } catch (Exception e) {
                        pendingContent = null;
                        Toast.makeText(MainActivity.this, "Gagal membuka dialog simpan", Toast.LENGTH_LONG).show();
                    }
                }
            });
            return true;
        }

        /** Backup manual: simpan ke Documents/Kasir Ponsel (folder dibuat otomatis). Mengembalikan lokasi, "PERM" bila perlu izin, atau "" bila gagal. */
        @JavascriptInterface
        public String saveBackup(String filename, String content) {
            try {
                byte[] data = content.getBytes(StandardCharsets.UTF_8);
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues v = new ContentValues();
                    v.put(MediaStore.MediaColumns.DISPLAY_NAME, filename);
                    v.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv");
                    v.put(MediaStore.MediaColumns.RELATIVE_PATH, "Documents/Kasir Ponsel");
                    Uri uri = getContentResolver().insert(MediaStore.Files.getContentUri("external"), v);
                    if (uri == null) return "";
                    OutputStream os = getContentResolver().openOutputStream(uri);
                    try { os.write(data); } finally { os.close(); }
                    return "Documents/Kasir Ponsel/" + filename;
                }
                if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1010);
                        }
                    });
                    return "PERM";
                }
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "Kasir Ponsel");
                if (!dir.exists() && !dir.mkdirs()) return "";
                File f = new File(dir, filename);
                FileOutputStream fo = new FileOutputStream(f);
                try { fo.write(data); } finally { fo.close(); }
                MediaScannerConnection.scanFile(MainActivity.this, new String[]{f.getAbsolutePath()}, new String[]{"text/csv"}, null);
                return "Documents/Kasir Ponsel/" + filename;
            } catch (Exception e) {
                return "";
            }
        }

        @JavascriptInterface
        public boolean hasFolder() {
            return getSharedPreferences("kasir", MODE_PRIVATE).getString("tree", null) != null;
        }

        /** Membuka pemilih folder; izin tulis disimpan permanen agar backup harian tanpa dialog. */
        @JavascriptInterface
        public void pickFolder() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                        startActivityForResult(i, REQ_PICK_TREE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih folder", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        /** Menulis file backup langsung ke folder pilihan tanpa dialog. */
        @JavascriptInterface
        public boolean autoSave(String filename, String content) {
            String t = getSharedPreferences("kasir", MODE_PRIVATE).getString("tree", null);
            if (t == null) return false;
            try {
                Uri tree = Uri.parse(t);
                Uri dir = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
                Uri f = DocumentsContract.createDocument(getContentResolver(), dir, "text/csv", filename);
                if (f == null) return false;
                try (OutputStream os = getContentResolver().openOutputStream(f, "wt")) {
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                }
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareFile(String filename, String content) {
            return shareInternal(filename, content, null);
        }

        /** Membuka aplikasi email dengan penerima terisi dan file backup terlampir. */
        @JavascriptInterface
        public boolean emailFile(String to, String filename, String content) {
            return shareInternal(filename, content, to);
        }

        /** Menulis backup ke cache lalu membuka menu kirim Android (opsional dengan penerima email). */
        private boolean shareInternal(final String filename, final String content, final String to) {
            try {
                String safeName = filename.replaceAll("[^A-Za-z0-9._-]", "_");
                File dir = new File(getCacheDir(), "share");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File[] old = dir.listFiles();
                if (old != null) {
                    for (File o : old) { o.delete(); }
                }
                File f = new File(dir, safeName);
                try (FileOutputStream fos = new FileOutputStream(f)) {
                    fos.write(content.getBytes(StandardCharsets.UTF_8));
                }
                final Uri uri = Uri.parse("content://com.konter.kasir.share/" + Uri.encode(safeName));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("text/csv");
                            send.putExtra(Intent.EXTRA_STREAM, uri);
                            send.putExtra(Intent.EXTRA_SUBJECT, "Backup Kasir Ponsel");
                            if (to != null && !to.isEmpty()) {
                                send.putExtra(Intent.EXTRA_EMAIL, new String[]{to});
                            }
                            send.setClipData(ClipData.newRawUri("", uri));
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(send, "Bagikan backup"));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Tidak bisa membuka menu bagikan", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
