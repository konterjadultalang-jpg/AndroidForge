package com.aquaphone.strukprinter

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class L(val t: String, val bold: Boolean = false, val big: Boolean = false)

object Receipt {
    const val W = 32
    // Label bisa beda-beda dan OCR kadang salah huruf (TANGGAI), jadi dicocokkan dengan toleransi 1 huruf
    private val al = listOf(
        "Tanggal" to "tanggal", "Tanggal" to "tgl", "Waktu" to "waktu transaksi", "Waktu" to "waktu", "Waktu" to "jam",
        "No. Ref" to "no referensi", "No. Ref" to "nomor referensi", "No. Ref" to "no ref", "No. Ref" to "nomor ref", "No. Ref" to "ref",
        "Jenis Transaksi" to "jenis transaksi", "Sumber Dana" to "sumber dana",
        "Bank Tujuan" to "bank tujuan", "Bank Tujuan" to "bank penerima", "Bank Tujuan" to "bank",
        "No. Rekening" to "no rekening tujuan", "No. Rekening" to "nomor rekening tujuan", "No. Rekening" to "no rekening",
        "No. Rekening" to "nomor rekening", "No. Rekening" to "no rek", "No. Rekening" to "rekening tujuan",
        "Nama Tujuan" to "nama tujuan", "Nama Tujuan" to "nama penerima", "Nama Tujuan" to "penerima", "Tujuan" to "tujuan",
        "Keterangan" to "keterangan", "Keterangan" to "catatan", "Keterangan" to "berita",
        "Nominal" to "nominal", "Nominal" to "jumlah transfer", "Nominal" to "jumlah",
        "Biaya Admin" to "biaya admin", "Biaya Admin" to "biaya transaksi", "Biaya Admin" to "biaya",
        "Total" to "total transaksi", "Total" to "total"
    ).sortedByDescending { it.second.length }

    private val noise = Regex("(?i)^[a-z]{0,2}BR[IN]?$")
    private fun clean(s: String) = s.split(" ").filter { it.isNotBlank() && !(noise.matches(it) && !it.equals("BRI", true)) }.joinToString(" ")

    private val wd = Regex("[A-Za-z0-9]+")

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var p = d[0]; d[0] = i
            for (j in 1..b.length) { val t = d[j]; d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + if (a[i - 1] == b[j - 1]) 0 else 1); p = t }
        }
        return d[b.length]
    }

    private fun match(line: String): Pair<String, String>? {
        val ws = wd.findAll(line).toList()
        for ((k, a) in al) {
            val n = a.split(" ").size
            if (ws.size < n) continue
            val cand = ws.take(n).joinToString("") { it.value.lowercase() }
            val tgt = a.replace(" ", "")
            if (lev(cand, tgt) <= (if (tgt.length >= 6) 1 else 0))
                return k to line.substring(ws[n - 1].range.last + 1).trimStart(' ', ':', '.', '-', '\t')
        }
        return null
    }

    // Baris angka hasil OCR -> digit saja. Huruf mirip angka dikoreksi, sisa noise pendek (BR/BRI) dibuang.
    private fun fixDigits(l: String): String? {
        val like = mapOf('B' to '8', 'O' to '0', 'o' to '0', 'D' to '0', 'I' to '1', 'l' to '1', 'i' to '1', '|' to '1',
            'S' to '5', 's' to '5', 'Z' to '2', 'z' to '2', 'G' to '6', 'g' to '9', 'q' to '9')
        val sb = StringBuilder()
        for (tok in l.trim().split(Regex("[\\s\\-]+"))) {
            if (tok.isEmpty()) continue
            val dg = tok.count { it.isDigit() }
            if (dg * 2 >= tok.length) { for (c in tok) { val x = if (c.isDigit()) c else like[c]; if (x != null) sb.append(x) } }
            else if (tok.length > 3) return null
        }
        return if (sb.length >= 3) sb.toString() else null
    }

    fun parse(t: String): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < ls.size) {
            val mt = match(ls[i])
            if (mt != null) {
                var v = mt.second
                if (v.isEmpty() && i + 1 < ls.size && match(ls[i + 1]) == null) v = ls[++i]
                if (m[mt.first].isNullOrBlank()) m[mt.first] = v
            }
            i++
        }
        // Format BRImo: bagian "Tujuan" berisi nama, "BANK xxx", dan nomor rekening (kadang terpisah spasi)
        val ti = ls.indexOfFirst { l -> match(l).let { it != null && it.first == "Tujuan" && it.second.isBlank() } }
        if (ti >= 0) {
            val sec = ArrayList<String>()
            var j = ti + 1
            while (j < ls.size && match(ls[j]) == null) sec.add(ls[j++])
            sec.firstOrNull { it.trim().length > 1 }?.let { m["Nama Tujuan"] = clean(it) }
            sec.firstNotNullOfOrNull { Regex("(?i)\\bBANK\\s+([A-Za-z]+)").find(it)?.groupValues?.get(1) }?.let { m["Bank Tujuan"] = it.uppercase() }
            // Nomor rekening sering salah baca karena watermark BRI (mis. 8 jadi B) atau terpotong jadi beberapa baris
            val frag = StringBuilder()
            for (l in sec) {
                val d = fixDigits(l)
                if (d != null) frag.append(d) else if (frag.isNotEmpty()) break
            }
            if (frag.length in 8..20) m["No. Rekening"] = frag.toString()
        }
        // Tanggal BRImo: "20 Oktober 2026, 14:02:29 WIB" -> 2026-10-20 + 14:02:29
        if (m["Tanggal"].isNullOrBlank()) {
            val mn = mapOf("jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5, "jun" to 6, "jul" to 7, "agu" to 8, "agt" to 8,
                "aug" to 8, "sep" to 9, "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12)
            val x = Regex("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?,?\\s+(\\d{4})(?:[,\\s]+(\\d{1,2}:\\d{2}(?::\\d{2})?))?").findAll(t)
                .firstOrNull { mn.containsKey(it.groupValues[2].take(3).lowercase()) }
            if (x != null) {
                m["Tanggal"] = "%04d-%02d-%02d".format(x.groupValues[3].toInt(), mn[x.groupValues[2].take(3).lowercase()]!!, x.groupValues[1].toInt())
                if (x.groupValues[4].isNotEmpty()) m["Waktu"] = x.groupValues[4].let { if (it.count { c -> c == ':' } == 1) "$it:00" else it }
            }
        }
        // Nominal/biaya: ambil hanya bagian "Rp123.456" (buang huruf sisa logo seperti "BR")
        val rpx = Regex("(?i)Rp\\s*[\\d.,]+")
        for (k in listOf("Nominal", "Biaya Admin", "Total")) m[k]?.let { v -> val x = rpx.find(v); if (x != null) m[k] = x.value else m.remove(k) }
        if (m["Nominal"].isNullOrBlank()) rpx.find(t)?.let { m["Nominal"] = it.value }
        // Cadangan: cari nomor rekening (8-20 digit) dan nama bank bila labelnya tidak terbaca
        if (m["No. Rekening"].isNullOrBlank()) {
            val refD = m["No. Ref"]?.filter { it.isDigit() }
            val ok = setOf("Tujuan", "Bank Tujuan", "Nama Tujuan", "No. Rekening")
            val c = ArrayList<String>()
            for (l in ls) {
                val k = match(l)?.first
                if ((k != null && k !in ok) || Regex("\\d{4}-\\d{2}-\\d{2}").containsMatchIn(l)) continue
                fixDigits(l)?.let { dg -> if (dg.length in 8..20 && dg != refD) c.add(dg) }
                for (x in Regex("\\d[\\d \\-]{6,26}\\d").findAll(l)) {
                    val dg = x.value.filter { it.isDigit() }
                    if (dg.length in 8..20 && dg != refD) c.add(dg)
                }
            }
            c.lastOrNull()?.let { m["No. Rekening"] = it }
        }
        if (m["Bank Tujuan"].isNullOrBlank()) {
            val b = Regex("\\b(BRI|BCA|BNI|MANDIRI|BSI|CIMB|PERMATA|DANAMON|BTN|MEGA|OCBC|PANIN|BTPN|JAGO|SEABANK|DANA|OVO|GOPAY|SHOPEEPAY|LINKAJA)\\b", RegexOption.IGNORE_CASE).find(t)
            if (b != null) m["Bank Tujuan"] = b.value.uppercase()
        }
        return m
    }

    fun num(s: String?): Long = s?.substringBefore(',')?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
    fun rp(n: Long) = "RP " + n.toString().reversed().chunked(3).joinToString(".").reversed()

    private fun cen(s: String, w: Int = W) = s.chunked(w).map { " ".repeat((w - it.length) / 2) + it }
    private fun row(k: String, v: String): List<String> =
        if (k.length + 1 + v.length <= W) listOf(k + " ".repeat(W - k.length - v.length) + v)
        else listOf(k) + v.chunked(W).map { " ".repeat(W - it.length) + it }

    // tanggal mentah BRImo -> (tanggal, waktu)
    private fun dt(raw: String?): Pair<String, String> {
        if (raw.isNullOrBlank()) { val n = Date(); return Pair(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(n), SimpleDateFormat("HH:mm:ss", Locale.US).format(n)) }
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(raw)
        val time = m?.let { "%02d:%s:%s".format(it.groupValues[1].toInt(), it.groupValues[2], it.groupValues[3].ifEmpty { "00" }) } ?: ""
        val date = raw.replace(m?.value ?: "", "").replace("WIB", "", true).trim(' ', ',', '-', '\u2022')
        return Pair(date.uppercase(), time)
    }

    fun lines(d: Map<String, String>, admin: Long, name: String, addr: String, foot: String): List<L> {
        val o = ArrayList<L>()
        fun rows(k: String, v: String) = row(k, v.uppercase()).forEach { o.add(L(it)) }
        name.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        addr.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it)) } }
        o.add(L(""))
        o.add(L("=".repeat(W))); o.add(L(cen("BUKTI TRANSFER")[0], true)); o.add(L("=".repeat(W)))
        val (tg, wk) = dt(listOf(d["Tanggal"], d["Waktu"]).filter { !it.isNullOrBlank() }.joinToString(" "))
        rows("TANGGAL", tg); if (wk.isNotBlank()) rows("WAKTU", wk); rows("REF", d["No. Ref"]?.ifBlank { "-" } ?: "-")
        o.add(L("")); o.add(L("KEPADA:"))
        listOf("PENERIMA" to (d["Nama Tujuan"] ?: d["Tujuan"] ?: ""), "BANK" to (d["Bank Tujuan"] ?: ""),
            "NO REKENING" to (d["No. Rekening"] ?: ""), "KETERANGAN" to (d["Keterangan"] ?: "").replace("|", " "))
            .filter { it.second.isNotBlank() }.forEach { rows(it.first, it.second.trim()) }
        o.add(L(""))
        val nom = num(d["Nominal"])
        if (admin > 0) { rows("NOMINAL", rp(nom)); rows("BIAYA ADMIN", rp(admin)); o.add(L("")) }
        o.add(L(cen("TOTAL BAYAR")[0], true))
        o.add(L(cen(rp(nom + admin), W / 2)[0], true, true))
        o.add(L("")); o.add(L("-".repeat(W)))
        o.add(L(cen("** TRANSAKSI BERHASIL **")[0], true))
        foot.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        return o
    }
}
