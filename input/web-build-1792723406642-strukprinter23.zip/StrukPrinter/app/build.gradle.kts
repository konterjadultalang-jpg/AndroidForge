plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
    implementation("androidx.core:core:1.12.0")
}
// Nomor build dari GitHub Actions: tiap build lebih tinggi sehingga APK baru bisa menimpa (update) yang lama
val buildNo = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1

android {
    namespace = "com.aquaphone.strukprinter"
    compileSdk = 34
    defaultConfig { applicationId = "com.aquaphone.strukprinter"; minSdk = 21; targetSdk = 34; versionCode = buildNo; versionName = "1.0.$buildNo"; ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") } }
    // Kunci tanda tangan tetap (bukan debug keystore acak milik runner), supaya APK berikutnya terpasang sebagai update
    signingConfigs { create("printstruk") { storeFile = file("printstruk.jks"); storePassword = "printstruk2026"; keyAlias = "printstruk"; keyPassword = "printstruk2026" } }
    buildTypes { debug { signingConfig = signingConfigs.getByName("printstruk"); isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
