package com.aquaphone.strukprinter

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.ClipData
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ACC = 0xFF5046E5.toInt()
    private val BG = 0xFFF3F4F6.toInt()
    private val GRAY = 0xFF6B7280.toInt()
    private lateinit var prefs: SharedPreferences
    private lateinit var rootF: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private lateinit var beam: View
    private var tab = 0
    private var data = LinkedHashMap<String, String>()
    private var adminV = 0L
    private var raw = ""
    private var curTitle = "Struk"
    private var fromShare = false
    private var srcSel = "Otomatis"
    private var inPreview = false
    private var pendingPrint = false
    private var fallbackText: String? = null
    private var logoPct = 100
    private var fontSel = 1
    private var scanAnim: ObjectAnimator? = null
    private lateinit var fName: EditText
    private lateinit var fAddr: EditText
    private lateinit var fFoot: EditText
    private lateinit var fFee: EditText

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(2), stroke) }
    private fun tv(s: String, sz: Float = 15f, col: Int = 0xFF111827.toInt(), bold: Boolean = false) =
        TextView(this).apply { text = s; textSize = sz; setTextColor(col); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun label(s: String) = tv(s.uppercase(), 12f, GRAY, true).apply { setPadding(0, dp(16), 0, dp(8)) }
    private fun card(stroke: Int = 0) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(Color.WHITE, 18, stroke)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) }
    }
    private fun btn(s: String, fill: Int, fg: Int, f: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(fg); background = rounded(fill, 14); setOnClickListener { f() }
    }
    private fun field(h: String, v: String, multi: Boolean = false) = EditText(this).apply {
        hint = h; setText(v); background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        if (multi) { minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
    }
    private fun watch(f: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f() }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    }
    private fun page(v: LinearLayout): View { v.setPadding(dp(20), dp(28), dp(20), dp(8)); return ScrollView(this).apply { addView(v) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", 0)
        rootF = FrameLayout(this).apply { setBackgroundColor(BG) }
        content = FrameLayout(this)
        nav = LinearLayout(this).apply { background = rounded(Color.WHITE, 24); setPadding(dp(8), dp(10), dp(8), dp(10)) }
        listOf("🏠 Beranda", "🖨 Printer", "⚙ Setelan").forEachIndexed { i, s ->
            nav.addView(tv(s, 14f).apply { gravity = Gravity.CENTER; setOnClickListener { show(i) } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(4), dp(16), dp(16)) })
        beam = View(this).apply {
            visibility = View.GONE
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x0000E5FF, 0xAA00E5FF.toInt(), 0x0000E5FF))
        }
        rootF.addView(col, FrameLayout.LayoutParams(-1, -1))
        rootF.addView(beam, FrameLayout.LayoutParams(-1, dp(90)))
        setContentView(rootF)
        show(0); handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (pendingPrint) { pendingPrint = false; if (!needPerm()) doPrint() else toast("Izin Bluetooth dibutuhkan untuk mencetak"); return }
        if (inPreview) showPreview() else show(tab)
    }

    // Garis scan berjalan terus selama struk dibaca, berhenti saat preview siap
    private fun startScan() {
        stopScan()
        rootF.post {
            beam.visibility = View.VISIBLE
            scanAnim = ObjectAnimator.ofFloat(beam, "translationY", -dp(90).toFloat(), rootF.height.toFloat()).apply {
                duration = 1100; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
                start()
            }
        }
    }

    private fun stopScan() {
        scanAnim?.cancel(); scanAnim = null
        beam.visibility = View.GONE
    }

    private fun showScanning() {
        inPreview = false
        nav.visibility = View.GONE
        content.removeAllViews()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        box.addView(tv("Memindai struk...", 20f, bold = true).apply { gravity = Gravity.CENTER })
        box.addView(tv("Mohon tunggu sebentar", 14f, GRAY).apply { gravity = Gravity.CENTER })
        content.addView(box, FrameLayout.LayoutParams(-1, -1))
        startScan()
    }

    private fun show(i: Int) {
        tab = i
        inPreview = false
        nav.visibility = if (i == 2) View.GONE else View.VISIBLE
        content.removeAllViews()
        content.addView(when (i) { 0 -> home(); 1 -> printerTab(); else -> settings() }, FrameLayout.LayoutParams(-1, -1))
        for (k in 0 until nav.childCount) (nav.getChildAt(k) as TextView).apply { setTextColor(if (k == i) ACC else GRAY); setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL) }
    }

    // ---------- Beranda: riwayat cetak ----------
    private fun hist() = JSONArray(prefs.getString("hist", "[]"))
    private fun addHist(t: String, m: Map<String, String>, a: Long) {
        val h = hist(); val n = JSONArray()
        n.put(JSONObject().put("t", t).put("d", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).put("m", JSONObject(m)).put("a", a))
        for (i in 0 until minOf(h.length(), 49)) n.put(h.get(i))
        prefs.edit().putString("hist", n.toString()).apply()
    }

    private fun openHist(o: JSONObject) {
        val m = o.optJSONObject("m") ?: return
        data = LinkedHashMap(); m.keys().forEach { data[it] = m.getString(it) }
        raw = ""; adminV = o.optLong("a"); curTitle = o.getString("t"); fromShare = false; showPreview()
    }

    private fun home(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val on = try { prefs.getString("addr", null) != null && BluetoothAdapter.getDefaultAdapter()?.isEnabled == true } catch (e: SecurityException) { false }
        val h = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        h.addView(ImageView(this).apply { setImageResource(R.drawable.logo_app) }, LinearLayout.LayoutParams(dp(44), dp(44)))
        h.addView(tv("AQUA PHONE", 26f, 0xFF3F3F46.toInt(), true).apply { setTypeface(null, Typeface.BOLD_ITALIC); setPadding(dp(8), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv(if (on) "●  Online" else "●  Offline", 14f, if (on) 0xFF10B981.toInt() else GRAY, true).apply {
            background = rounded(Color.WHITE, 20); setPadding(dp(14), dp(8), dp(14), dp(8))
        })
        v.addView(h)

        val blue = LinearLayout(this).apply {
            background = rounded(0xFF3347DB.toInt(), 28); setPadding(dp(24), dp(24), dp(24), dp(24)); setOnClickListener { pickImage() }
        }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(tv("Cetak Bukti\nTransfer", 26f, Color.WHITE, true))
        left.addView(tv("Pilih bukti transfer dari galeri, ubah menjadi struk.", 15f, 0xFFE0E7FF.toInt()).apply { setPadding(0, dp(12), 0, 0) })
        blue.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        blue.addView(tv("🖼", 32f).apply { gravity = Gravity.CENTER; background = rounded(0x40FFFFFF, 20) },
            LinearLayout.LayoutParams(dp(72), dp(72)).apply { setMargins(dp(12), dp(8), 0, 0) })
        v.addView(blue, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(20), 0, 0) })

        v.addView(label("Riwayat Cetak"))
        val a = hist()
        if (a.length() == 0) v.addView(tv("Belum ada riwayat. Pilih bukti dari galeri, atau bagikan bukti dari aplikasi bank/dompet digital ke aplikasi ini.", 14f, GRAY))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val sm = o.optJSONObject("m")?.optString("Sumber", "") ?: ""
            v.addView(card().apply {
                addView(tv(o.getString("t"), 17f, bold = true)); addView(tv(o.getString("d") + (if (sm.isNotBlank()) " · $sm" else ""), 13f, GRAY))
                setOnClickListener { openHist(o) }
            })
        }
        return page(v)
    }

    @Suppress("DEPRECATION")
    private fun pickImage() { startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 8) }

    // Pilih manual sumber bukti (DANA, ShopeePay, dst); struk dibaca ulang dengan aturan sumber itu
    private fun pickSource(done: () -> Unit) {
        val names = listOf("Otomatis") + Receipt.sources
        android.app.AlertDialog.Builder(this).setTitle("Sumber bukti transfer")
            .setSingleChoiceItems(names.toTypedArray<CharSequence>(), names.indexOf(srcSel).coerceAtLeast(0)) { dlg, w ->
                srcSel = names[w]; applyParsed(); dlg.dismiss(); done()
            }.show()
    }

    // ---------- Pratinjau & cetak ----------
    private fun lines() = Receipt.lines(data, adminV, prefs.getString("name", "")!!, prefs.getString("saddr", "")!!, prefs.getString("foot", "")!!, prefs.getInt("namesize", 1))

    // Kertas 32 kolom, sama persis dengan hasil cetak (tebal, besar, rata).
    // Ukuran otomatis mengecil supaya seluruh struk muat 1 layar tanpa scroll.
    private fun paper(ls: List<L>, aw: Int, ah: Int): View {
        val pad = dp(14)
        var u = 0; for (l in ls) u += if (l.big) 2 else 1
        val pw = minOf((aw - 2 * pad).toFloat(), (ah - 2 * pad).toFloat() * Receipt.W / (2f * u)).toInt().coerceAtLeast(dp(120))
        val p = Paint().apply { typeface = Typeface.MONOSPACE; textSize = 100f }
        val sz = 100f * pw / p.measureText("M".repeat(Receipt.W)) * 0.99f
        val cw = pw / Receipt.W.toFloat()
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 10); setPadding(pad, pad, pad, pad) }
        for (l in ls) v.addView(TextView(this).apply {
            text = if (l.t.isEmpty()) " " else l.t
            typeface = Typeface.create(Typeface.MONOSPACE, if (l.bold) Typeface.BOLD else Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, if (l.big) sz * 2 else sz)
            setTextColor(Color.BLACK); includeFontPadding = false; setSingleLine(); setHorizontallyScrolling(true); gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(pw, (cw * 2 * (if (l.big) 2 else 1)).toInt()))
        return v
    }

    private fun showPreview() {
        stopScan()
        inPreview = true
        nav.visibility = View.GONE
        content.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(16)) }

        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("‹", 28f, bold = true).apply {
            gravity = Gravity.CENTER; background = rounded(Color.WHITE, 14); setOnClickListener { goBack() }
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(0, 0, dp(14), 0) })
        head.addView(tv("Preview Struk", 22f, bold = true))
        col.addView(head)
        val srcTv = tv("", 13f, ACC, true).apply { setPadding(dp(58), dp(6), 0, 0); visibility = if (raw.isBlank()) View.GONE else View.VISIBLE }
        col.addView(srcTv)
        fun updSrc() { srcTv.text = "Sumber: ${data["Sumber"] ?: "-"} (${if (srcSel == "Otomatis") "otomatis" else "manual"}) · Ubah ›" }
        updSrc()

        val holder = FrameLayout(this)
        col.addView(holder, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(12), 0, dp(12)) })
        fun redraw() {
            if (holder.width == 0 || holder.height == 0) return
            holder.removeAllViews()
            holder.addView(paper(lines(), holder.width, holder.height), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        srcTv.setOnClickListener { pickSource { updSrc(); redraw() } }
        holder.addOnLayoutChangeListener { _, l, t, r, b, ol, ot, orr, ob -> if (r - l != orr - ol || b - t != ob - ot) holder.post { redraw() } }

        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(btn("✎", Color.WHITE, 0xFF111827.toInt()) { editDialog { redraw() } }.apply { textSize = 20f; minWidth = 0; minimumWidth = 0 },
            LinearLayout.LayoutParams(dp(56), dp(56)).apply { setMargins(0, 0, dp(10), 0) })
        bar.addView(btn("BAGIKAN", 0xFF10B981.toInt(), Color.WHITE) { shareReceipt() }.apply { setTypeface(null, Typeface.BOLD) },
            LinearLayout.LayoutParams(0, dp(56), 1f).apply { setMargins(0, 0, dp(10), 0) })
        bar.addView(btn("CETAK SEKARANG", ACC, Color.WHITE) { doPrint() }.apply { setTypeface(null, Typeface.BOLD) },
            LinearLayout.LayoutParams(0, dp(56), 1.3f))
        col.addView(bar)

        content.addView(col, FrameLayout.LayoutParams(-1, -1))
    }

    private fun goBack() { fromShare = false; show(0) }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (inPreview) goBack() else if (tab == 2) show(0) else super.onBackPressed() }

    // Ubah data lewat dialog; struk di belakangnya langsung ikut berubah
    private fun editDialog(onChange: () -> Unit) {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(8)); setBackgroundColor(BG) }
        fun add(h: String, key: String) { col.addView(field(h, data[key] ?: "").apply { addTextChangedListener(watch { data[key] = text.toString(); onChange() }) }) }
        add("Penerima", "Nama Tujuan"); add("Bank", "Bank Tujuan"); add("No rekening", "No. Rekening"); add("Keterangan", "Keterangan"); add("Nominal", "Nominal")
        col.addView(field("Biaya admin (Rp)", adminV.toString()).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            addTextChangedListener(watch { adminV = text.toString().toLongOrNull() ?: 0; onChange() })
        })
        if (raw.isNotBlank()) { col.addView(label("Teks hasil baca")); col.addView(tv(raw, 11f, GRAY).apply { typeface = Typeface.MONOSPACE }) }
        val d = android.app.AlertDialog.Builder(this).setTitle("Ubah data").setView(ScrollView(this).apply { addView(col) }).setPositiveButton("Selesai", null).create()
        d.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        d.show()
    }

    // ---------- Bagikan struk sebagai gambar ----------
    private fun receiptBitmap(ls: List<L>): Bitmap {
        val cw = 18f; val m = 24f
        val w = (cw * Receipt.W + 2 * m).toInt()
        val lh = cw * 2
        var u = 0; for (l in ls) u += if (l.big) 2 else 1
        val lg = logo()
        val lgH = if (lg != null) lg.height + 16 else 0
        val bmp = Bitmap.createBitmap(w, (lh * u + 2 * m + lgH).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp); cv.drawColor(Color.WHITE)
        val ref = Paint().apply { typeface = Typeface.MONOSPACE; textSize = 100f }
        val sz = 100f * cw * Receipt.W / ref.measureText("M".repeat(Receipt.W))
        val pt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
        var y = m
        if (lg != null) { cv.drawBitmap(lg, (w - lg.width) / 2f, y, null); y += lg.height + 16 }
        for (l in ls) {
            val rh = lh * (if (l.big) 2 else 1)
            pt.typeface = Typeface.create(Typeface.MONOSPACE, if (l.bold) Typeface.BOLD else Typeface.NORMAL)
            pt.textSize = if (l.big) sz * 2 else sz
            val fm = pt.fontMetrics
            cv.drawText(l.t, m, y + rh / 2f - (fm.ascent + fm.descent) / 2f, pt)
            y += rh
        }
        return bmp
    }

    private fun shareReceipt() {
        try {
            val f = File(cacheDir, "struk.png")
            f.outputStream().use { receiptBitmap(lines()).compress(Bitmap.CompressFormat.PNG, 100, it) }
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val si = Intent(Intent.ACTION_SEND).setType("image/png").putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION).apply { clipData = ClipData.newRawUri("", uri) }
            val ch = Intent.createChooser(si, "Bagikan struk")
            if (Build.VERSION.SDK_INT >= 24) ch.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(this, MainActivity::class.java)))
            startActivity(ch)
        } catch (e: Exception) { toast("Gagal bagikan: ${e.message}") }
    }

    private fun needPerm() = Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != 0
    private fun logoFile() = File(filesDir, "logo.png")
    private fun logoBase(): Bitmap? = if (logoFile().exists()) BitmapFactory.decodeFile(logoFile().path) else null
    private fun logo(): Bitmap? {
        val b = logoBase() ?: return null
        val pct = prefs.getInt("logopct", 100).coerceIn(10, 100)
        return if (pct == 100) b else Bitmap.createScaledBitmap(b, (b.width * pct / 100).coerceAtLeast(1), (b.height * pct / 100).coerceAtLeast(1), true)
    }

    // ---------- Cetak: sambung otomatis ke printer yang pernah dipakai; kalau tidak aktif tampilkan pilihan ----------
    private fun knownList(): List<Pair<String, String>> = try {
        val a = JSONArray(prefs.getString("known", "[]"))
        (0 until a.length()).map { i -> a.getJSONObject(i).let { o -> o.getString("a") to o.getString("n") } }
    } catch (e: Exception) { emptyList() }

    private fun rememberPrinter(addr: String, name: String) {
        val l = listOf(addr to name) + knownList().filter { it.first != addr }
        val a = JSONArray(); for ((x, n) in l.take(5)) a.put(JSONObject().put("a", x).put("n", n))
        prefs.edit().putString("known", a.toString()).putString("addr", addr).putString("pname", name).apply()
    }

    // Printer terakhir dipakai lebih dulu, lalu printer lain yang pernah tersambung (hanya yang masih dipasangkan di HP)
    private fun printerCandidates(): List<Pair<String, String>> {
        val bonded = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.map { it.address } ?: emptyList() } catch (e: SecurityException) { emptyList() }
        val saved = prefs.getString("addr", null)?.let { a -> a to (prefs.getString("pname", null) ?: a) }
        return (listOfNotNull(saved) + knownList()).distinctBy { it.first }.filter { it.first in bonded }
    }

    private fun doPrint() {
        if (needPerm()) { pendingPrint = true; requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return }
        val ad = BluetoothAdapter.getDefaultAdapter()
        if (ad == null) { toast("HP ini tidak mendukung Bluetooth"); return }
        if (!ad.isEnabled) { pendingPrint = true; startActivityForResult(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), 9); return }
        val c = printerCandidates()
        if (c.isEmpty()) pickPrinter() else printTo(c, 0)
    }

    private fun progress(msg: String): android.app.AlertDialog {
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(24), dp(20), dp(24), dp(20)) }
        row.addView(ProgressBar(this), LinearLayout.LayoutParams(dp(36), dp(36)))
        row.addView(tv(msg, 16f).apply { setPadding(dp(16), 0, 0, 0) })
        return android.app.AlertDialog.Builder(this).setView(row).setCancelable(false).create().also { it.show() }
    }

    // Coba cetak ke printer ke-i; kalau tidak aktif lanjut ke berikutnya, habis -> pilihan printer
    private fun printTo(c: List<Pair<String, String>>, i: Int) {
        val (addr, name) = c[i]
        val ls = lines(); val lg = logo(); val title = curTitle; val m = LinkedHashMap(data); val ad = adminV
        val dlg = progress("Menyambung ke $name...")
        Thread {
            try {
                Printer.print(addr, lg, ls)
                rememberPrinter(addr, name); addHist(title, m, ad)
                runOnUiThread { dlg.dismiss(); toast("Selesai dicetak"); if (fromShare) finish() else show(0) }
            } catch (e: Printer.ConnectFail) {
                runOnUiThread { dlg.dismiss(); if (i + 1 < c.size) printTo(c, i + 1) else { toast("$name tidak aktif"); pickPrinter() } }
            } catch (e: Exception) { runOnUiThread { dlg.dismiss(); toast("Gagal mencetak: ${e.message}") } }
        }.start()
    }

    private fun pickPrinter() {
        val devs = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }
        val openBt = { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        if (devs.isEmpty()) {
            android.app.AlertDialog.Builder(this).setTitle("Printer belum dipasangkan")
                .setMessage("Pair printer dulu di pengaturan Bluetooth HP, lalu kembali dan tekan Cetak.")
                .setPositiveButton("Buka Bluetooth") { _, _ -> openBt() }.setNegativeButton("Batal", null).show()
            return
        }
        val known = knownList().map { it.first }
        val sorted = devs.sortedBy { if (it.address in known) 0 else 1 }
        val names = sorted.map { (it.name ?: it.address) + (if (it.address in known) "  ★" else "") }
        android.app.AlertDialog.Builder(this).setTitle("Pilih printer Bluetooth")
            .setItems(names.toTypedArray<CharSequence>()) { _, w -> val dv = sorted[w]; printTo(listOf(dv.address to (dv.name ?: dv.address)), 0) }
            .setNeutralButton("Pair Baru") { _, _ -> openBt() }.setNegativeButton("Batal", null).show()
    }

    // ---------- Printer ----------
    private fun printerTab(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        v.addView(tv("Koneksi Printer", 24f, bold = true))
        if (needPerm()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return page(v) }
        v.addView(label("Status saat ini"))
        val pn = prefs.getString("pname", null)
        v.addView(card().apply {
            addView(tv("Printer", 18f, bold = true))
            addView(tv(if (pn != null) "● Terpilih: $pn" else "● Belum dipilih", 14f, if (pn != null) 0xFF10B981.toInt() else GRAY))
            val r = LinearLayout(this@MainActivity).apply { setPadding(0, dp(10), 0, 0) }
            r.addView(btn("Hapus", 0xFFFEE2E2.toInt(), 0xFFDC2626.toInt()) { prefs.edit().remove("addr").remove("pname").remove("known").apply(); show(1) }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
            r.addView(btn("Test Print", ACC, Color.WHITE) { testPrint() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(r)
        })
        val h = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        h.addView(label("Perangkat tersedia"), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv("↻ Cari Ulang", 14f, ACC, true).apply { setOnClickListener { show(1) } })
        v.addView(h)
        val devs = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }
        if (devs.isEmpty()) v.addView(tv("Tidak ada perangkat. Pair printer dulu di Bluetooth HP/PDA.", 14f, GRAY))
        val sel = prefs.getString("addr", null)
        for (d in devs) v.addView(card(if (d.address == sel) ACC else 0).apply {
            addView(tv(d.name ?: d.address, 17f, bold = true)); addView(tv(d.address, 13f, GRAY))
            setOnClickListener { rememberPrinter(d.address, d.name ?: d.address); show(1) }
        })
        return page(v)
    }

    private fun testPrint() {
        val addr = prefs.getString("addr", null) ?: run { toast("Pilih printer dulu"); return }
        Thread {
            try { Printer.print(addr, null, listOf(L("TEST PRINT", true), L("PRINTER OK"))); runOnUiThread { toast("Test terkirim") } }
            catch (e: Exception) { runOnUiThread { toast("Gagal: ${e.message}") } }
        }.start()
    }

    // ---------- Setelan ----------
    private fun settings(): View {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        logoPct = prefs.getInt("logopct", 100).coerceIn(10, 100)
        fontSel = prefs.getInt("namesize", 1).coerceIn(0, 2)
        val line = 0xFFE5E7EB.toInt()
        fun lab(s: String) = tv(s, 15f, bold = true).apply { setPadding(0, dp(18), 0, dp(8)) }
        fun fld(h: String, v: String, multi: Boolean = false) = field(h, v, multi).apply { background = rounded(0xFFF8F9FB.toInt(), 14, line) }
        fun divider() = View(this).apply { setBackgroundColor(line) }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(28), 0, 0) }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(20), 0, dp(20), dp(12)) }
        head.addView(tv("‹", 28f, bold = true).apply { gravity = Gravity.CENTER; background = rounded(Color.WHITE, 14, line); setOnClickListener { show(0) } },
            LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(0, 0, dp(14), 0) })
        head.addView(tv("Setelan", 24f, bold = true))
        root.addView(head)

        val c = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 24); setPadding(dp(20), dp(24), dp(20), dp(20)) }

        // kotak logo (garis putus-putus) + ukuran logo
        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply { setColor(0xFFF8F9FC.toInt()); cornerRadius = dp(20).toFloat(); setStroke(dp(2), 0xFFD9DCE3.toInt(), dp(6).toFloat(), dp(4).toFloat()) }
        }
        val base = logoBase()
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; if (base != null) setImageBitmap(base) }
        fun fitLogo() { img.layoutParams = FrameLayout.LayoutParams(dp(170) * logoPct / 100, dp(80) * logoPct / 100, Gravity.CENTER) }
        if (base != null) { fitLogo(); box.addView(img) } else box.addView(tv("Tidak Ada Logo", 15f, 0xFF9CA3AF.toInt()), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        c.addView(box, LinearLayout.LayoutParams(dp(200), dp(100)).apply { gravity = Gravity.CENTER_HORIZONTAL })

        val sr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        sr.addView(tv("Ukuran Logo", 15f, bold = true), LinearLayout.LayoutParams(0, -2, 1f))
        val pctTv = tv("$logoPct%", 15f, ACC, true)
        sr.addView(pctTv)
        c.addView(sr, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(20), 0, 0) })
        val sb = SeekBar(this).apply {
            max = 90; progress = logoPct - 10
            thumbTintList = ColorStateList.valueOf(ACC); progressTintList = ColorStateList.valueOf(ACC); progressBackgroundTintList = ColorStateList.valueOf(line)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sk: SeekBar?, p: Int, u: Boolean) { logoPct = p + 10; pctTv.text = "$logoPct%"; if (base != null) { fitLogo(); img.requestLayout() } }
                override fun onStartTrackingTouch(sk: SeekBar?) {}
                override fun onStopTrackingTouch(sk: SeekBar?) {}
            })
        }
        c.addView(sb, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(10)) })

        val br = LinearLayout(this).apply { gravity = Gravity.CENTER }
        br.addView(btn("Ganti Logo", 0xFFEEF0FF.toInt(), ACC) { save(false); startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7) }
            .apply { setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(dp(130), dp(44)).apply { setMargins(0, 0, dp(12), 0) })
        br.addView(btn("Hapus", 0xFFFEECEC.toInt(), 0xFFDC2626.toInt()) { save(false); logoFile().delete(); show(2) }
            .apply { setTypeface(null, Typeface.BOLD) }, LinearLayout.LayoutParams(dp(110), dp(44)))
        c.addView(br)
        c.addView(divider(), LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(0, dp(20), 0, 0) })

        fName = fld("Contoh: AQUA PHONE", prefs.getString("name", "")!!)
        c.addView(lab("Nama Usaha / Toko")); c.addView(fName)

        val fontNames = listOf("Kecil", "Normal", "Besar")
        val fontTv = tv(fontNames[fontSel], 17f)
        val fontRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; background = rounded(0xFFF8F9FB.toInt(), 14, line); setPadding(dp(14), dp(14), dp(14), dp(14))
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity).setTitle("Ukuran Font Toko")
                    .setItems(fontNames.toTypedArray<CharSequence>()) { dlg, w -> fontSel = w; fontTv.text = fontNames[w]; dlg.dismiss() }.show()
            }
        }
        fontRow.addView(fontTv, LinearLayout.LayoutParams(0, -2, 1f))
        fontRow.addView(tv("⌄", 20f, GRAY))
        c.addView(lab("Ukuran Font Toko")); c.addView(fontRow)

        fAddr = fld("Contoh: BRILink - Jasa Transfer - Tarik Tunai", prefs.getString("saddr", "")!!, true)
        c.addView(lab("Deskripsi Toko")); c.addView(fAddr)

        fFoot = fld("Terima Kasih", prefs.getString("foot", "")!!, true)
        c.addView(lab("Pesan Footer")); c.addView(fFoot)

        c.addView(divider(), LinearLayout.LayoutParams(-1, dp(1)).apply { setMargins(0, dp(20), 0, 0) })
        fFee = fld("0", prefs.getLong("admin", 0).toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        c.addView(lab("Biaya Admin Default (Rp)")); c.addView(fFee)

        val sv = ScrollView(this).apply { addView(c, FrameLayout.LayoutParams(-1, -2).apply { setMargins(dp(20), dp(4), dp(20), dp(16)) }) }
        root.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(btn("Simpan Pengaturan", 0xFF4F46E5.toInt(), Color.WHITE) { save(true); show(0) }.apply { setTypeface(null, Typeface.BOLD); textSize = 17f },
            LinearLayout.LayoutParams(-1, dp(58)).apply { setMargins(dp(20), dp(8), dp(20), dp(20)) })
        return root
    }

    private fun save(msg: Boolean) {
        prefs.edit().putString("name", fName.text.toString()).putString("saddr", fAddr.text.toString())
            .putString("foot", fFoot.text.toString()).putLong("admin", fFee.text.toString().toLongOrNull() ?: 0)
            .putInt("logopct", logoPct).putInt("namesize", fontSel).apply()
        if (msg) toast("Tersimpan")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 9) {
            if (pendingPrint) { pendingPrint = false; if (res == RESULT_OK) rootF.postDelayed({ doPrint() }, 600) else toast("Bluetooth harus aktif untuk mencetak") }
            return
        }
        if (rc == 8) {
            val u = d?.data
            if (res == RESULT_OK && u != null) { fromShare = false; fallbackText = null; showScanning(); runOcr(u) }
            return
        }
        if (rc == 7 && res == RESULT_OK && d?.data != null) {
            try {
                val bmp = contentResolver.openInputStream(d.data!!)!!.use { BitmapFactory.decodeStream(it) }
                val sc = minOf(384f / bmp.width, 160f / bmp.height, 1f)
                val out = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt().coerceAtLeast(1), (bmp.height * sc).toInt().coerceAtLeast(1), true)
                logoFile().outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (e: Exception) { toast("Logo gagal: ${e.message}") }
        }
        show(2)
    }

    // ---------- Terima share (teks / gambar / PDF) ----------
    @Suppress("DEPRECATION")
    private fun handle(i: Intent) {
        if (i.action != Intent.ACTION_SEND) return
        fromShare = true
        val t = i.getStringExtra(Intent.EXTRA_TEXT)
        val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: i.clipData?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.uri
        // Gambar didahulukan: ShopeePay dkk. ikut mengirim teks singkat ("Rp100.000 ...") bersama gambar bukti,
        // dan teks itu dulu terbaca sebagai bukti sehingga nama/rekening/tanggal kosong. Teks hanya cadangan bila OCR gagal.
        if (u != null) { fallbackText = t; showScanning(); runOcr(u); return }
        if (!t.isNullOrBlank()) { fallbackText = null; showScanning(); rootF.postDelayed({ onText(t) }, 1200) }
    }

    private fun runOcr(u: Uri) {
        Thread {
            try { recognize(loadBitmap(u)) } catch (e: Exception) { runOnUiThread { scanFail("Gagal baca: ${e.message}") } }
        }.start()
    }

    private fun onText(t: String) {
        raw = t; srcSel = "Otomatis"
        applyParsed()
        showPreview()
    }

    private fun applyParsed() {
        data = Receipt.parse(raw, srcSel)
        if (!data.containsKey("Nama Tujuan") && data.containsKey("Tujuan")) data["Nama Tujuan"] = data["Tujuan"]!!
        curTitle = data["Nama Tujuan"] ?: "Struk"
        adminV = data["Biaya Admin"]?.let { Receipt.num(it) } ?: prefs.getLong("admin", 0)
    }

    private fun loadBitmap(u: Uri): Bitmap {
        if (contentResolver.getType(u) == "application/pdf") {
            val fd = contentResolver.openFileDescriptor(u, "r")!!
            val r = PdfRenderer(fd); val pg = r.openPage(0)
            val bmp = Bitmap.createBitmap(pg.width * 2, pg.height * 2, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            pg.close(); r.close(); fd.close()
            return bmp
        }
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var sm = 1; while (maxOf(o.outWidth, o.outHeight) / sm > 3000) sm *= 2
        return contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = sm }) }!!
    }

    // Watermark biasanya sangat terang: piksel terang diputihkan, teks asli (gelap/abu) tetap
    private fun whiten(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val p = px[i]
            if ((Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000 >= 215) px[i] = Color.WHITE
        }
        return Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
    }

    private fun lineAngle(l: com.google.mlkit.vision.text.Text.Line): Double {
        val cp = l.cornerPoints
        return if (cp != null && cp.size >= 2) Math.toDegrees(Math.atan2((cp[1].y - cp[0].y).toDouble(), (cp[1].x - cp[0].x).toDouble())) else 0.0
    }

    // Hasil OCR -> teks per baris. Baris yang miring sendiri (watermark) dibuang; baris digabung bila sejajar.
    private fun toText(res: com.google.mlkit.vision.text.Text): String {
        val all = res.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }
        val angs = all.map { lineAngle(it) }.sorted()
        val med = if (angs.isEmpty()) 0.0 else angs[angs.size / 2]
        val keep = all.filter { Math.abs(lineAngle(it) - med) <= 10.0 }.ifEmpty { all }
        val ls = keep.sortedBy { it.boundingBox!!.centerY() }
        val rows = ArrayList<MutableList<com.google.mlkit.vision.text.Text.Line>>()
        for (l in ls) {
            val last = rows.lastOrNull()
            if (last != null && Math.abs(last[0].boundingBox!!.centerY() - l.boundingBox!!.centerY()) < minOf(last[0].boundingBox!!.height(), l.boundingBox!!.height()) * 0.6) last.add(l)
            else rows.add(mutableListOf(l))
        }
        return rows.joinToString("\n") { r -> r.sortedBy { it.boundingBox!!.left }.joinToString(" ") { it.text } }
    }

    private fun score(t: String): Int = try {
        val m = Receipt.parse(t)
        listOf("Nama Tujuan", "No. Rekening", "Bank Tujuan", "Tanggal", "No. Ref", "Nominal").count { !m[it].isNullOrBlank() }
    } catch (e: Exception) { 0 }

    // Dua lintasan: gambar asli dan gambar tanpa watermark; dipakai yang paling lengkap terbaca
    private fun recognize(bmp: Bitmap) {
        val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val inputs = listOf(bmp, whiten(bmp))
        val texts = ArrayList<String>(); var done = 0; var err: String? = null
        fun fin() {
            done++
            if (done < inputs.size) return
            if (texts.isEmpty()) { scanFail("OCR gagal: ${err ?: "teks tidak terbaca"}"); return }
            onText(texts.maxWithOrNull(compareBy<String>({ score(it) }, { -it.length }))!!)
        }
        for (b in inputs) rec.process(InputImage.fromBitmap(b, 0))
            .addOnSuccessListener { res -> runOnUiThread { texts.add(toText(res)); fin() } }
            .addOnFailureListener { e -> runOnUiThread { err = e.message; fin() } }
    }

    private fun scanFail(msg: String) {
        val fb = fallbackText; fallbackText = null
        if (!fb.isNullOrBlank()) { onText(fb); return }
        toast(msg); fromShare = false; show(0)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
