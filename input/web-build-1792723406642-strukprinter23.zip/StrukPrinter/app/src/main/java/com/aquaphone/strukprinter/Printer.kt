package com.aquaphone.strukprinter

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.UUID

object Printer {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val cs = Charsets.ISO_8859_1

    private fun raster(b: Bitmap): ByteArray {
        val w = b.width; val h = b.height; val wb = (w + 7) / 8
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, (wb and 255).toByte(), (wb shr 8).toByte(), (h and 255).toByte(), (h shr 8).toByte()))
        for (y in 0 until h) for (xb in 0 until wb) {
            var v = 0
            for (k in 0 until 8) {
                val x = xb * 8 + k
                if (x < w) {
                    val p = b.getPixel(x, y)
                    val lum = (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
                    if (Color.alpha(p) > 128 && lum < 128) v = v or (0x80 shr k)
                }
            }
            o.write(v)
        }
        return o.toByteArray()
    }

    // Gagal tersambung (printer mati / di luar jangkauan) dibedakan dari gagal saat mencetak
    class ConnectFail(msg: String) : Exception(msg)

    private fun connect(dev: BluetoothDevice): BluetoothSocket {
        try {
            val a = dev.createRfcommSocketToServiceRecord(SPP)
            try { a.connect(); return a } catch (e: IOException) { try { a.close() } catch (e2: Exception) {} }
            val b = dev.createInsecureRfcommSocketToServiceRecord(SPP)
            b.connect(); return b
        } catch (e: IOException) { throw ConnectFail("Printer tidak aktif atau di luar jangkauan") }
    }

    fun print(addr: String, logo: Bitmap?, lines: List<L>) {
        val ad = BluetoothAdapter.getDefaultAdapter()
        try { ad.cancelDiscovery() } catch (e: Exception) {}
        val s = connect(ad.getRemoteDevice(addr))
        try { s.outputStream.use { o ->
            fun w(vararg b: Int) = o.write(ByteArray(b.size) { b[it].toByte() })
            fun t(x: String) = o.write(x.toByteArray(cs))
            w(0x1B, 0x40)
            if (logo != null) { w(0x1B, 0x61, 1); o.write(raster(logo)); t("\n") }
            w(0x1B, 0x61, 0)
            for (l in lines) { w(0x1B, 0x45, if (l.bold) 1 else 0); w(0x1D, 0x21, if (l.big) 0x11 else 0); t(l.t.trimEnd() + "\n") }
            w(0x1B, 0x45, 0); w(0x1D, 0x21, 0); w(0x1B, 0x64, 4)
            o.flush(); Thread.sleep(800)
        } } finally { try { s.close() } catch (e: Exception) {} }
    }
}
