plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
dependencies { implementation("com.google.mlkit:text-recognition:16.0.1") }
android {
    namespace = "com.aquaphone.strukprinter"
    compileSdk = 34
    defaultConfig { applicationId = "com.aquaphone.strukprinter"; minSdk = 21; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
