package com.konter.kasir;

import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 1001;
    private static final int REQ_SAVE_FILE = 1002;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private String pendingName;
    private String pendingContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        // Diperlukan agar tombol "Impor" (input type=file) bisa membuka pemilih file.
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Pilih file CSV"), REQ_PICK_FILE);
                } catch (Exception e) {
                    filePathCallback.onReceiveValue(null);
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih file", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        webView.addJavascriptInterface(new Bridge(), "AndroidBridge");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_PICK_FILE) {
            if (filePathCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null) {
                    result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                }
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }

        if (requestCode == REQ_SAVE_FILE) {
            String content = pendingContent;
            pendingContent = null;
            pendingName = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null || content == null) {
                return; // dibatalkan
            }
            try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                os.write(content.getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this, "Backup berhasil disimpan", Toast.LENGTH_LONG).show();
            } catch (Exception e) {
                Toast.makeText(this, "Gagal menyimpan file", Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    /** Dipanggil dari JavaScript: membuka dialog "Simpan sebagai" agar pengguna memilih lokasi. */
    private class Bridge {
        @JavascriptInterface
        public boolean saveFile(final String filename, final String content) {
            pendingName = filename;
            pendingContent = content;
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("text/csv");
                        intent.putExtra(Intent.EXTRA_TITLE, filename);
                        startActivityForResult(intent, REQ_SAVE_FILE);
                    } catch (Exception e) {
                        pendingContent = null;
                        Toast.makeText(MainActivity.this, "Gagal membuka dialog simpan", Toast.LENGTH_LONG).show();
                    }
                }
            });
            return true;
        }

        /** Dipanggil dari JavaScript: menulis backup ke cache lalu membuka menu "Bagikan" Android. */
        @JavascriptInterface
        public boolean shareFile(final String filename, final String content) {
            try {
                String safeName = filename.replaceAll("[^A-Za-z0-9._-]", "_");
                File dir = new File(getCacheDir(), "share");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File[] old = dir.listFiles();
                if (old != null) {
                    for (File o : old) { o.delete(); }
                }
                File f = new File(dir, safeName);
                try (FileOutputStream fos = new FileOutputStream(f)) {
                    fos.write(content.getBytes(StandardCharsets.UTF_8));
                }
                final Uri uri = Uri.parse("content://com.konter.kasir.share/" + Uri.encode(safeName));
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("text/csv");
                            send.putExtra(Intent.EXTRA_STREAM, uri);
                            send.putExtra(Intent.EXTRA_SUBJECT, "Backup Kasir Konter");
                            send.setClipData(ClipData.newRawUri("", uri));
                            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                            startActivity(Intent.createChooser(send, "Bagikan backup"));
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Tidak bisa membuka menu bagikan", Toast.LENGTH_LONG).show();
                        }
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
