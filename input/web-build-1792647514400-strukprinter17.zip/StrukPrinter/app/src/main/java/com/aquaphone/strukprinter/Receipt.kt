package com.aquaphone.strukprinter

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class L(val t: String, val bold: Boolean = false, val big: Boolean = false)

object Receipt {
    const val W = 32
    // Label bisa beda-beda dan OCR kadang salah huruf (TANGGAI), jadi dicocokkan dengan toleransi 1 huruf
    private val alBase = listOf(
        "Tanggal" to "tanggal", "Tanggal" to "tgl", "Waktu" to "waktu transaksi", "Waktu" to "waktu", "Waktu" to "jam",
        "No. Ref" to "no referensi", "No. Ref" to "nomor referensi", "No. Ref" to "no ref", "No. Ref" to "nomor ref", "No. Ref" to "ref",
        "Jenis Transaksi" to "jenis transaksi", "Sumber Dana" to "sumber dana",
        "Bank Tujuan" to "bank tujuan", "Bank Tujuan" to "bank penerima", "Bank Tujuan" to "bank",
        "No. Rekening" to "no rekening tujuan", "No. Rekening" to "nomor rekening tujuan", "No. Rekening" to "no rekening",
        "No. Rekening" to "nomor rekening", "No. Rekening" to "no rek", "No. Rekening" to "rekening tujuan",
        "Nama Tujuan" to "nama tujuan", "Nama Tujuan" to "nama penerima", "Nama Tujuan" to "penerima", "Tujuan" to "tujuan",
        "Keterangan" to "keterangan", "Keterangan" to "catatan", "Keterangan" to "berita",
        "Nominal" to "nominal", "Nominal" to "jumlah transfer", "Nominal" to "jumlah",
        "Biaya Admin" to "biaya admin", "Biaya Admin" to "biaya transaksi", "Biaya Admin" to "biaya",
        "Total" to "total transaksi", "Total" to "total"
    ).sortedByDescending { it.second.length }

    // Tambahan label untuk dompet digital & aplikasi bank lain (DANA, ShopeePay, GoPay, SeaBank, dst)
    private val alAll = (alBase + listOf(
        "No. Ref" to "id transaksi", "No. Ref" to "nomor transaksi", "No. Ref" to "no transaksi", "No. Ref" to "kode transaksi",
        "No. Ref" to "id pesanan", "No. Ref" to "nomor pesanan", "No. Ref" to "no pesanan",
        "No. Rekening" to "nomor tujuan", "No. Rekening" to "no tujuan", "No. Rekening" to "nomor hp tujuan", "No. Rekening" to "nomor hp",
        "No. Rekening" to "no hp", "No. Rekening" to "nomor akun", "No. Rekening" to "ke rekening",
        "Nama Tujuan" to "dikirim ke", "Nama Tujuan" to "kirim ke", "Nama Tujuan" to "transfer ke", "Nama Tujuan" to "nama akun",
        "Nama Tujuan" to "nama rekening", "Nama Tujuan" to "nama pemilik rekening", "Nama Tujuan" to "nama pemilik",
        "Bank Tujuan" to "nama bank", "Nominal" to "jumlah kirim", "Nominal" to "nominal transfer", "Nominal" to "jumlah pembayaran",
        "Total" to "total pembayaran", "Total" to "total bayar", "Total" to "total transfer", "Total" to "total dibayar",
        "Biaya Admin" to "biaya layanan", "Biaya Admin" to "biaya transfer", "Keterangan" to "pesan", "Tanggal" to "tanggal transaksi"
    )).sortedByDescending { it.second.length }
    private var al = alBase

    val sources = listOf("BRImo", "DANA", "SeaBank", "ShopeePay", "GoPay", "OVO", "LinkAja", "Jago", "BCA", "Livin", "Umum")
    private val wallets = setOf("DANA", "ShopeePay", "GoPay", "OVO", "LinkAja")

    // Tebak aplikasi asal bukti dari kata kunci di teks hasil baca
    fun detect(t: String): String {
        val low = t.lowercase()
        val sq = low.replace(Regex("\\s+"), "")
        val noSd = low.replace(Regex("sumber\\s+dana"), " ")
        return when {
            "brimo" in sq || "bankrakyatindonesia" in sq || ("sumberdana" in sq && "jenistransaksi" in sq) -> "BRImo"
            "shopeepay" in sq || "shopee" in sq -> "ShopeePay"
            "seabank" in sq -> "SeaBank"
            "gopay" in sq || "gojek" in sq || "gotogroup" in sq -> "GoPay"
            Regex("\\bovo\\b").containsMatchIn(low) -> "OVO"
            "linkaja" in sq -> "LinkAja"
            "bankjago" in sq || Regex("\\bjago\\b").containsMatchIn(low) -> "Jago"
            "livin" in sq -> "Livin"
            "m-bca" in sq || "mbca" in sq || "bcamobile" in sq -> "BCA"
            Regex("\\bdana\\b").containsMatchIn(noSd) -> "DANA"
            else -> "Umum"
        }
    }

    private val noise = Regex("(?i)^[a-z]{0,2}BR[IN]?$")
    private fun clean(s: String) = s.split(" ").filter { it.isNotBlank() && !(noise.matches(it) && !it.equals("BRI", true)) }.joinToString(" ")

    private val wd = Regex("[A-Za-z0-9]+")

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var p = d[0]; d[0] = i
            for (j in 1..b.length) { val t = d[j]; d[j] = minOf(d[j] + 1, d[j - 1] + 1, p + if (a[i - 1] == b[j - 1]) 0 else 1); p = t }
        }
        return d[b.length]
    }

    private fun match(line: String): Pair<String, String>? {
        val ws = wd.findAll(line).toList()
        for ((k, a) in al) {
            val n = a.split(" ").size
            if (ws.size < n) continue
            val cand = ws.take(n).joinToString("") { it.value.lowercase() }
            val tgt = a.replace(" ", "")
            if (lev(cand, tgt) <= (if (tgt.length >= 6) 1 else 0))
                return k to line.substring(ws[n - 1].range.last + 1).trimStart(' ', ':', '.', '-', '\t')
        }
        return null
    }

    // Baris angka hasil OCR -> digit saja. Huruf mirip angka dikoreksi, sisa noise pendek (BR/BRI) dibuang.
    private fun fixDigits(l: String): String? {
        val like = mapOf('B' to '8', 'O' to '0', 'o' to '0', 'D' to '0', 'I' to '1', 'l' to '1', 'i' to '1', '|' to '1',
            'S' to '5', 's' to '5', 'Z' to '2', 'z' to '2', 'G' to '6', 'g' to '9', 'q' to '9')
        val sb = StringBuilder()
        for (tok in l.trim().split(Regex("[\\s\\-]+"))) {
            if (tok.isEmpty()) continue
            val dg = tok.count { it.isDigit() }
            if (dg * 2 >= tok.length) { for (c in tok) { val x = if (c.isDigit()) c else like[c]; if (x != null) sb.append(x) } }
            else if (tok.length > 3) return null
        }
        return if (sb.length >= 3) sb.toString() else null
    }

    private val monthNum = mapOf("jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5, "jun" to 6, "jul" to 7, "agu" to 8, "agt" to 8,
        "aug" to 8, "sep" to 9, "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12)

    private val bankList = "BRI|BCA|BNI|MANDIRI|BSI|CIMB|PERMATA|DANAMON|BTN|MEGA|OCBC|PANIN|BTPN|JAGO|SEABANK|MAYBANK|SINARMAS|MUAMALAT|NEO|BNC"
    private fun zero(s: String) = s.map { if (it == 'O' || it == 'o') '0' else it }.joinToString("")

    // Nama yang terpotong di baris sambungan ("SANTOS" + "O") dilengkapi dari teks lain yang memuat nama utuh
    private fun fullName(name: String, flat: String): String =
        Regex(Regex.escape(name) + "\\w*").findAll(flat).map { it.value }.maxByOrNull { it.length } ?: name

    // Bukti DANA: "Kirim Uang Rp260.000 ke MOCH. ARIS SANTOSO - BRI ••••0534". Rekening disamarkan, ditulis apa adanya (....0534).
    private fun parseDana(t: String, ls: List<String>, m: LinkedHashMap<String, String>) {
        val flat = t.replace(Regex("\\s+"), " ")
        val sep = "[-–—−~|•·]"
        val mask = "(?:[^\\w\\s]|[xX*]){0,8}"
        var name: String? = null; var bank: String? = null; var acc: String? = null
        fun setLast(d: String) { val z = zero(d).filter { it.isDigit() }; if (z.length >= 3) acc = "...." + z.takeLast(4) }

        // 1) kalimat ringkasan
        val head = "(?i)kirim\\s+uang\\s+rp\\s*[\\d.,]+\\s+ke\\s+(.+?)"
        Regex("$head\\s*$sep?\\s*\\b($bankList)\\b\\s*$mask\\s*([0-9Oo]{3,12})\\b").find(flat)?.let {
            name = it.groupValues[1]; bank = it.groupValues[2].uppercase(); setLast(it.groupValues[3])
        }
        if (acc == null) Regex("$head\\s+$sep\\s+([A-Za-z]{2,12})\\s*$mask\\s*([0-9Oo]{3,12})\\b").find(flat)?.let {
            name = it.groupValues[1]; bank = it.groupValues[2].uppercase(); setLast(it.groupValues[3])
        }
        if (acc == null) Regex("$head\\s+$sep\\s+(\\S*\\d\\S*)").find(flat)?.let {
            name = it.groupValues[1]; bank = "DANA"; acc = it.groupValues[2].replace(Regex("[^\\w]"), ".")
        }
        // 2) bagian "Detail Penerima": Nama + Akun Bank
        val di = ls.indexOfFirst { Regex("(?i)detail\\s+penerima").containsMatchIn(it) }
        if (di >= 0) for (j in di + 1 until minOf(ls.size, di + 8)) {
            if (name == null) Regex("(?i)^nama\\b\\s*(.*)$").find(ls[j])?.let { x ->
                var v = x.groupValues[1].trim()
                if (v.isBlank()) v = ls.getOrNull(j + 1)?.trim() ?: ""
                else { val nx = ls.getOrNull(j + 1)?.trim() ?: ""; if (nx.length in 1..3 && nx.all { c -> c.isLetter() }) v += nx }
                if (v.isNotBlank()) name = v
            }
            if (acc == null) Regex("(?i)^akun\\s+bank\\b\\s*(.*)$").find(ls[j])?.let { x ->
                val rest = x.groupValues[1].ifBlank { ls.getOrNull(j + 1) ?: "" }
                Regex("([A-Za-z]{2,12})\\b(.*)$").find(rest)?.let { y -> bank = y.groupValues[1].uppercase(); setLast(y.groupValues[2]) }
            }
        }
        // 3) cadangan: "BRI ••••0534" di mana saja setelah kalimat ringkasan
        if (acc == null) {
            val from = maxOf(flat.indexOf("Kirim Uang", ignoreCase = true), 0)
            Regex("(?i)\\b($bankList)\\b\\s*(?:[^\\w\\s]|[xX*]){2,8}\\s*([0-9Oo]{3,6})\\b").find(flat, from)?.let { bank = it.groupValues[1].uppercase(); setLast(it.groupValues[2]) }
        }
        name?.let { m["Nama Tujuan"] = fullName(it.trim(), flat) }
        bank?.let { m["Bank Tujuan"] = it }
        acc?.let { m["No. Rekening"] = it }

        // "ID Transaksi" panjang sering terbungkus beberapa baris angka -> disambung
        val ri = ls.indexOfFirst { Regex("(?i)^id\\s+transaksi").containsMatchIn(it) }
        if (ri >= 0) {
            val sb = StringBuilder(ls[ri].replace(Regex("(?i)^id\\s+transaksi"), "").filter { it.isDigit() })
            var j = ri + 1
            while (j < ls.size && Regex("^[\\d\\s]+$").matches(ls[j])) { sb.append(ls[j].filter { it.isDigit() }); j++ }
            if (sb.length >= 6) m["No. Ref"] = sb.toString()
        }
        setDate(flat, m)
    }

    // "22 Okt 2026 • 11:04" / "10 Okt 2026, 14:49"
    private fun setDate(flat: String, m: LinkedHashMap<String, String>) {
        Regex("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?,?\\s+(\\d{4})\\s*[^\\w\\s]{0,3}\\s*(\\d{1,2}[:.]\\d{2})").findAll(flat)
            .firstOrNull { monthNum.containsKey(it.groupValues[2].take(3).lowercase()) }?.let { x ->
                m["Tanggal"] = "%04d-%02d-%02d".format(x.groupValues[3].toInt(), monthNum[x.groupValues[2].take(3).lowercase()]!!, x.groupValues[1].toInt())
                m["Waktu"] = x.groupValues[4].replace('.', ':') + ":00"
            }
    }

    // ShopeePay: "Kirim Ke  MOCH. ARIS SANTOSO / BRI: 608201033860534", referensi = "Order SN", biaya admin bisa "Gratis"
    private fun parseShopee(t: String, ls: List<String>, m: LinkedHashMap<String, String>) {
        val flat = t.replace(Regex("\\s+"), " ")
        val lbl = Regex("(?i)^kirim\\s*ke\\s*")
        val accRx = Regex("\\b([A-Za-z]{2,12})\\s*:\\s*(\\d{6,20})\\b")
        val ai = ls.indexOfFirst { accRx.containsMatchIn(it) }
        if (ai >= 0) {
            val x = accRx.find(ls[ai])!!
            val bank = x.groupValues[1].uppercase()
            m["Bank Tujuan"] = bank; m["No. Rekening"] = x.groupValues[2]
            val bad = Regex("(?i)dikirim|dari|waktu|selesai|berhasil|shopeepay|sumber|saldo|jumlah|pembayaran|biaya|admin|rincian|referensi|order|download|aplikasi|pasti|gratis|kirim uang")
            val bankLead = Regex("(?i)^$bank\\s+")
            var best: String? = null; var bestScore = 0
            // nama = baris huruf kapital terpanjang di sekitar baris rekening (noise watermark seperti "Pee E" kalah panjang)
            for (k in maxOf(0, ai - 3)..minOf(ls.size - 1, ai + 2)) {
                var c = (if (k == ai) ls[k].substring(0, x.range.first) else ls[k]).replace(lbl, "").replace(bankLead, "").trim()
                if (c.any { it.isDigit() } || bad.containsMatchIn(c)) continue
                val letters = c.count { it.isLetter() }
                if (letters < 3) continue
                val upper = c.count { it.isUpperCase() }
                val caps = upper * 10 >= letters * 7
                if (caps) c = c.split(" ").filter { tk -> tk.none { ch -> ch.isLowerCase() } }.joinToString(" ").trim()
                val l2 = c.count { it.isLetter() }
                if (l2 < 3) continue
                val score = l2 + (if (caps) 100 else 0)
                if (score > bestScore) { best = c; bestScore = score }
            }
            best?.let { m["Nama Tujuan"] = it }
        }
        Regex("(?i)jumlah\\s+kirim\\s+uang\\s*(Rp\\s*[\\d.,]+)").find(flat)?.let { m["Nominal"] = it.groupValues[1] }
        val bi = ls.indexOfFirst { Regex("(?i)biaya\\s+admin").containsMatchIn(it) }
        if (bi >= 0 && (bi..minOf(bi + 1, ls.size - 1)).any { ls[it].contains("gratis", true) }) m["Biaya Admin"] = "Rp0"
        // "Order SN": kode campuran huruf+angka, sering terbungkus 2 baris dan label bisa terselip di tengah
        val oi = ls.indexOfFirst { Regex("(?i)order\\s*[s5][nm]\\b").containsMatchIn(it) }
        val ri = ls.indexOfFirst { Regex("(?i)rincian\\s+referensi").containsMatchIn(it) }
        val st = if (oi >= 0) maxOf(0, oi - 1) else if (ri >= 0) ri + 1 else -1
        if (st >= 0) {
            val tk = Regex("^(?=.*\\d)(?=.*[A-Za-z])[A-Za-z0-9]{6,}$")
            val sb = StringBuilder(); var found = false
            for (j in st..minOf(ls.size - 1, st + 4)) {
                val toks = ls[j].split(Regex("\\s+")).filter { tk.matches(it) }
                if (toks.isEmpty()) { if (found) break else continue }
                toks.forEach { sb.append(it) }; found = true
            }
            if (sb.length >= 6) m["No. Ref"] = sb.toString().uppercase()
        }
        setDate(flat, m)
    }

    fun parse(t: String, src: String = "Otomatis"): LinkedHashMap<String, String> {
        val eff = if (src == "Otomatis") detect(t) else src
        al = if (eff == "BRImo") alBase else alAll
        val m = LinkedHashMap<String, String>()
        val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < ls.size) {
            val mt = match(ls[i])
            if (mt != null) {
                var v = mt.second
                if (v.isEmpty() && i + 1 < ls.size && match(ls[i + 1]) == null) v = ls[++i]
                if (m[mt.first].isNullOrBlank()) m[mt.first] = v
            }
            i++
        }
        if (eff == "DANA") parseDana(t, ls, m)
        if (eff == "ShopeePay") parseShopee(t, ls, m)
        // Format BRImo: bagian "Tujuan" berisi nama, "BANK xxx", dan nomor rekening (kadang terpisah spasi)
        // Judul "Tujuan" kadang ikut sisa watermark di baris yang sama ("Tujuan BR KER"), jadi sisa pendek dianggap noise
        fun blankish(r: String) = r.isBlank() || (eff == "BRImo" && r.split(Regex("[\\s:]+")).filter { it.isNotEmpty() }.all { w -> w.length <= 3 && w.none { c -> c.isDigit() } })
        val ti = ls.indexOfFirst { l -> match(l).let { it != null && it.first == "Tujuan" && blankish(it.second) } }
        if (ti >= 0) {
            val sec = ArrayList<String>()
            var j = ti + 1
            while (j < ls.size) {
                val k = match(ls[j])?.first
                if (k != null && k != "Bank Tujuan" && k != "No. Rekening") break
                sec.add(ls[j++])
            }
            val bankRx = Regex("(?i)\\bBANK\\b")
            val bi = sec.indexOfFirst { bankRx.containsMatchIn(it) }
            val pool = (if (bi > 0) sec.take(bi) else sec).filter { l -> l.none { it.isDigit() } && !bankRx.containsMatchIn(l) }
            pool.maxByOrNull { l -> clean(l).count { it.isLetter() } }?.takeIf { clean(it).count { c -> c.isLetter() } >= 3 }
                ?.let { m["Nama Tujuan"] = clean(it) }
            sec.firstNotNullOfOrNull { Regex("(?i)\\bBANK\\s+([A-Za-z]+)").find(it)?.groupValues?.get(1) }?.let { m["Bank Tujuan"] = it.uppercase() }
            // Nomor rekening sering salah baca karena watermark BRI (mis. 8 jadi B) atau terpotong jadi beberapa baris
            val frag = StringBuilder()
            for (l in sec) {
                val d = fixDigits(l)
                if (d != null) frag.append(d) else if (frag.isNotEmpty()) break
            }
            if (frag.length in 8..20) m["No. Rekening"] = frag.toString()
        }
        // Tanggal BRImo: "20 Oktober 2026, 14:02:29 WIB" -> 2026-10-20 + 14:02:29
        if (m["Tanggal"].isNullOrBlank()) {
            val mn = mapOf("jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5, "jun" to 6, "jul" to 7, "agu" to 8, "agt" to 8,
                "aug" to 8, "sep" to 9, "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12)
            val x = Regex("(\\d{1,2})\\s+([A-Za-z]{3,9})\\.?,?\\s+(\\d{4})(?:[,\\s•·|\\-]+(\\d{1,2}:\\d{2}(?::\\d{2})?))?").findAll(t)
                .firstOrNull { mn.containsKey(it.groupValues[2].take(3).lowercase()) }
            if (x != null) {
                m["Tanggal"] = "%04d-%02d-%02d".format(x.groupValues[3].toInt(), mn[x.groupValues[2].take(3).lowercase()]!!, x.groupValues[1].toInt())
                if (x.groupValues[4].isNotEmpty()) m["Waktu"] = x.groupValues[4].let { if (it.count { c -> c == ':' } == 1) "$it:00" else it }
            }
        }
        // Tanggal format angka: 20/10/2026 19:26:41, 20-10-2026, 2026-10-20 19:26
        if (m["Tanggal"].isNullOrBlank()) {
            val x = Regex("(\\d{1,2})[/-](\\d{1,2})[/-](\\d{4})(?:[,\\s]+(\\d{1,2}[:.]\\d{2}(?:[:.]\\d{2})?))?").find(t)
            if (x != null) {
                m["Tanggal"] = "%04d-%02d-%02d".format(x.groupValues[3].toInt(), x.groupValues[2].toInt(), x.groupValues[1].toInt())
                if (x.groupValues[4].isNotEmpty()) m["Waktu"] = x.groupValues[4].replace('.', ':').let { if (it.count { c -> c == ':' } == 1) "$it:00" else it }
            }
        }
        // Nominal/biaya: ambil hanya bagian "Rp123.456" (buang huruf sisa logo seperti "BR")
        val rpx = Regex("(?i)Rp\\s*[\\d.,]+")
        for (k in listOf("Nominal", "Biaya Admin", "Total")) m[k]?.let { v -> val x = rpx.find(v); if (x != null) m[k] = x.value else m.remove(k) }
        if (m["Nominal"].isNullOrBlank() && !m["Total"].isNullOrBlank()) {
            val tot = num(m["Total"]); val fee = num(m["Biaya Admin"])
            m["Nominal"] = "Rp " + (if (tot - fee > 0) tot - fee else tot)
        }
        if (m["Nominal"].isNullOrBlank()) rpx.find(t)?.let { m["Nominal"] = it.value }
        // Cadangan: cari nomor rekening (8-20 digit) dan nama bank bila labelnya tidak terbaca
        if (m["No. Rekening"].isNullOrBlank()) {
            val refD = m["No. Ref"]?.filter { it.isDigit() }
            val ok = setOf("Tujuan", "Bank Tujuan", "Nama Tujuan", "No. Rekening")
            val c = ArrayList<String>()
            for (l in ls) {
                val k = match(l)?.first
                if ((k != null && k !in ok) || Regex("\\d{4}-\\d{2}-\\d{2}").containsMatchIn(l)) continue
                fixDigits(l)?.let { dg -> if (dg.length in 8..20 && dg != refD) c.add(dg) }
                for (x in Regex("\\d[\\d \\-]{6,26}\\d").findAll(l)) {
                    val dg = x.value.filter { it.isDigit() }
                    if (dg.length in 8..20 && dg != refD) c.add(dg)
                }
            }
            c.lastOrNull()?.let { m["No. Rekening"] = it }
        }
        if (m["Bank Tujuan"].isNullOrBlank()) {
            val b = Regex("\\b(BRI|BCA|BNI|MANDIRI|BSI|CIMB|PERMATA|DANAMON|BTN|MEGA|OCBC|PANIN|BTPN|JAGO|SEABANK|DANA|OVO|GOPAY|SHOPEEPAY|LINKAJA)\\b", RegexOption.IGNORE_CASE)
                .findAll(t.replace(Regex("(?i)sumber\\s+dana"), " ")).map { it.value.uppercase() }.firstOrNull { !it.equals(eff, true) }
            if (b != null) m["Bank Tujuan"] = b
            else if (eff in wallets) m["Bank Tujuan"] = eff.uppercase()
        }
        m["Sumber"] = eff
        return m
    }

    fun num(s: String?): Long = s?.substringBefore(',')?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
    fun rp(n: Long) = "RP " + n.toString().reversed().chunked(3).joinToString(".").reversed()

    private fun cen(s: String, w: Int = W) = s.chunked(w).map { " ".repeat((w - it.length) / 2) + it }
    private fun row(k: String, v: String): List<String> =
        if (k.length + 1 + v.length <= W) listOf(k + " ".repeat(W - k.length - v.length) + v)
        else listOf(k) + v.chunked(W).map { " ".repeat(W - it.length) + it }

    // tanggal mentah BRImo -> (tanggal, waktu)
    private fun dt(raw: String?): Pair<String, String> {
        if (raw.isNullOrBlank()) { val n = Date(); return Pair(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(n), SimpleDateFormat("HH:mm:ss", Locale.US).format(n)) }
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(raw)
        val time = m?.let { "%02d:%s:%s".format(it.groupValues[1].toInt(), it.groupValues[2], it.groupValues[3].ifEmpty { "00" }) } ?: ""
        val date = raw.replace(m?.value ?: "", "").replace("WIB", "", true).trim(' ', ',', '-', '\u2022')
        return Pair(date.uppercase(), time)
    }

    fun lines(d: Map<String, String>, admin: Long, name: String, addr: String, foot: String, nameSize: Int = 1): List<L> {
        val o = ArrayList<L>()
        fun rows(k: String, v: String) = row(k, v.uppercase()).forEach { o.add(L(it)) }
        // Ukuran font toko: 0 = kecil (biasa), 1 = normal (tebal), 2 = besar (tebal, 2x lipat)
        name.uppercase().lines().filter { it.isNotBlank() }.forEach { l ->
            when (nameSize) {
                0 -> cen(l.trim()).forEach { o.add(L(it)) }
                2 -> cen(l.trim(), W / 2).forEach { o.add(L(it, true, true)) }
                else -> cen(l.trim()).forEach { o.add(L(it, true)) }
            }
        }
        addr.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it)) } }
        o.add(L(""))
        o.add(L("=".repeat(W))); o.add(L(cen("BUKTI TRANSFER")[0], true)); o.add(L("=".repeat(W)))
        val (tg, wk) = dt(listOf(d["Tanggal"], d["Waktu"]).filter { !it.isNullOrBlank() }.joinToString(" "))
        rows("TANGGAL", tg); if (wk.isNotBlank()) rows("WAKTU", wk); run {
            val ref = (d["No. Ref"]?.ifBlank { "-" } ?: "-").uppercase()
            if (3 + 1 + ref.length <= W) rows("REF", ref) else {
                // ID panjang: label di baris pertama, nilai dibagi rata & rata kanan (seperti struk asli)
                val n = (ref.length + W - 5) / (W - 4)
                val per = (ref.length + n - 1) / n
                ref.chunked(per).forEachIndexed { i, c -> o.add(L(if (i == 0) "REF" + " ".repeat(W - 3 - c.length) + c else " ".repeat(W - c.length) + c)) }
            }
        }
        o.add(L("")); o.add(L("KEPADA:"))
        listOf("PENERIMA" to (d["Nama Tujuan"] ?: d["Tujuan"] ?: ""), "BANK" to (d["Bank Tujuan"] ?: ""),
            "NO REKENING" to (d["No. Rekening"] ?: ""), "KETERANGAN" to (d["Keterangan"] ?: "").replace("|", " "))
            .filter { it.second.isNotBlank() }.forEach { rows(it.first, it.second.trim()) }
        o.add(L(""))
        val nom = num(d["Nominal"])
        if (admin > 0) { rows("NOMINAL", rp(nom)); rows("BIAYA ADMIN", rp(admin)); o.add(L("")) }
        o.add(L(cen("TOTAL BAYAR")[0], true))
        o.add(L(cen(rp(nom + admin), W / 2)[0], true, true))
        o.add(L("")); o.add(L("-".repeat(W)))
        o.add(L(cen("** TRANSAKSI BERHASIL **")[0], true))
        foot.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        return o
    }
}
