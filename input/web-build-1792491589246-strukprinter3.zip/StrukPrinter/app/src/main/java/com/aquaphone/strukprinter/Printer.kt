package com.aquaphone.strukprinter

import android.bluetooth.BluetoothAdapter
import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream
import java.util.UUID

object Printer {
    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    private val cs = Charsets.ISO_8859_1

    private fun raster(b: Bitmap): ByteArray {
        val w = b.width; val h = b.height; val wb = (w + 7) / 8
        val o = ByteArrayOutputStream()
        o.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00, (wb and 255).toByte(), (wb shr 8).toByte(), (h and 255).toByte(), (h shr 8).toByte()))
        for (y in 0 until h) for (xb in 0 until wb) {
            var v = 0
            for (k in 0 until 8) {
                val x = xb * 8 + k
                if (x < w) {
                    val p = b.getPixel(x, y)
                    val lum = (Color.red(p) * 299 + Color.green(p) * 587 + Color.blue(p) * 114) / 1000
                    if (Color.alpha(p) > 128 && lum < 128) v = v or (0x80 shr k)
                }
            }
            o.write(v)
        }
        return o.toByteArray()
    }

    fun print(addr: String, logo: Bitmap?, name: String, address: String, body: String, footer: String) {
        val s = BluetoothAdapter.getDefaultAdapter().getRemoteDevice(addr).createRfcommSocketToServiceRecord(SPP)
        s.connect()
        s.outputStream.use { o ->
            fun w(vararg b: Int) = o.write(ByteArray(b.size) { b[it].toByte() })
            fun t(x: String) = o.write(x.toByteArray(cs))
            w(0x1B, 0x40); w(0x1B, 0x61, 1)
            if (logo != null) { o.write(raster(logo)); t("\n") }
            if (name.isNotBlank()) { w(0x1D, 0x21, 0x11); t(name.uppercase().chunked(16).joinToString("\n") + "\n"); w(0x1D, 0x21, 0x00) }
            if (address.isNotBlank()) t(Receipt.center(address) + "\n")
            w(0x1B, 0x61, 0); t(body)
            if (footer.isNotBlank()) { w(0x1B, 0x61, 1); t(Receipt.center(footer) + "\n"); w(0x1B, 0x61, 0) }
            w(0x1B, 0x64, 4)
            o.flush(); Thread.sleep(800)
        }
        s.close()
    }
}
