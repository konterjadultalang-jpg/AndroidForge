# AQUA PHONE STRUK

Proyek awal Android (Kotlin) untuk membuat struk informasi transaksi tanpa kuota pemakaian:
- OCR screenshot memakai Google ML Kit Text Recognition on-device.
- Input dan koreksi manual.
- Pratinjau struk.
- Cetak ke printer thermal Bluetooth klasik yang sudah dipasangkan (target 58 mm).
- Tidak membutuhkan akun atau kuota layanan berlangganan untuk fitur inti.

## Penting
Aplikasi ini sengaja membuat **struk informasi transaksi**, bukan tiruan bukti transfer resmi. Struk selalu diberi label “BUKAN BUKTI TRANSFER BANK”. Data hasil OCR hanya draf dan harus diverifikasi pengguna. Jangan gunakan untuk menyesatkan orang atau menyatakan transfer terjadi tanpa verifikasi di aplikasi bank.

## Cara membuka
1. Instal Android Studio versi stabil.
2. Pilih **Open** dan buka folder `AQUA_PHONE_STRUK`.
3. Tunggu Gradle Sync selesai. Pastikan JDK 17 tersedia.
4. Sambungkan HP Android atau buat emulator, lalu tekan Run.
5. Untuk membangun APK: **Build > Build APK(s)**. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Menggunakan printer
1. Pasangkan printer thermal lewat Settings > Bluetooth Android.
2. Buka aplikasi dan pilih printer yang telah dipasangkan.
3. Masukkan data, tinjau pratinjau, lalu cetak.
4. Beberapa printer memerlukan encoding/ESC-POS yang berbeda. Uji dengan struk contoh terlebih dahulu.

## Batasan prototipe
- OCR menggunakan Latin script dan pola sederhana untuk menduga nominal/tanggal/nama. OCR tidak menjamin hasil akurat.
- Pemilihan printer memakai perangkat Bluetooth yang sudah dipasangkan dan profil SPP. Printer BLE-only atau printer dengan protokol khusus mungkin perlu integrasi tambahan.
- Layout saat ini berupa teks sederhana untuk kertas 58 mm; belum meniru desain bank mana pun.
- Proyek ini adalah source code awal, bukan APK yang sudah dikompilasi atau diuji di semua perangkat.
