package com.aquaphone.strukprinter

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Preview kertas. Memakai Receipt.toLines() yang sama dengan yang dikirim ke printer.
 * Ukuran huruf disesuaikan otomatis agar 32 kolom pas selebar layar.
 */
@Composable
fun ReceiptPreview(r: Receipt) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .border(1.dp, Color.LightGray)
            .background(Color.White)
    ) {
        val pad = 12.dp
        val fontSize = with(LocalDensity.current) {
            ((maxWidth - pad * 2) / (COLS * 0.63f)).toSp()
        }
        Column(Modifier.padding(pad)) {
            r.toLines().forEach { l ->
                Text(
                    text = l.text.ifEmpty { " " },
                    color = Color.Black,
                    fontFamily = FontFamily.Monospace,
                    fontSize = fontSize,
                    softWrap = false,
                    fontWeight = if (l.bold) FontWeight.Bold else FontWeight.Normal
                )
            }
        }
    }
}

/** Form edit data struk. Dipakai untuk memperbaiki salah baca OCR. */
@Composable
fun ReceiptFields(r: Receipt, onChange: (Receipt) -> Unit) {
    Column {
        Field("Tanggal (yyyy-MM-dd)", r.date) { onChange(r.copy(date = it)) }
        Field("Waktu (HH:mm:ss)", r.time) { onChange(r.copy(time = it)) }
        Field("Kode referensi", r.refCode) { onChange(r.copy(refCode = it)) }
        Field("Bank tujuan", r.bank) { onChange(r.copy(bank = it)) }
        Field("No rekening", r.accountNo) { onChange(r.copy(accountNo = it)) }
        Field("Penerima", r.recipient) { onChange(r.copy(recipient = it)) }
        Field("Nominal", r.amount.toString()) {
            onChange(r.copy(amount = it.filter(Char::isDigit).toLongOrNull() ?: 0L))
        }
        Field("Admin", r.admin.toString()) {
            onChange(r.copy(admin = it.filter(Char::isDigit).toLongOrNull() ?: 0L))
        }
    }
}

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
    )
}
