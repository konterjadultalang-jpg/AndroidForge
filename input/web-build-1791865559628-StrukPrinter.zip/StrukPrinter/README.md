# Struk Printer 58mm (com.aquaphone.strukprinter)

Cetak struk transfer BRImo ke printer thermal Bluetooth 58mm (32 kolom, ESC/POS).
Alur: Halaman 1 = Preview + Edit, tombol Selanjutnya, Halaman 2 = pilih printer + Cetak.

## Build APK lewat GitHub Actions
1. Upload isi folder ini ke repository GitHub (termasuk folder .github).
2. Tab Actions > Build APK > Run workflow. Unduh artifact "StrukPrinter-apk".

## APK ditandatangani (release)
Buat keystore SEKALI (simpan cadangannya, jangan di-commit):

    keytool -genkeypair -v -keystore release.jks -alias strukprinter \
      -keyalg RSA -keysize 2048 -validity 10000
    base64 -w 0 release.jks

Di GitHub: Settings > Secrets and variables > Actions > New repository secret:
- KEYSTORE_BASE64   : hasil perintah base64 di atas
- KEYSTORE_PASSWORD : password keystore
- KEY_ALIAS         : strukprinter
- KEY_PASSWORD      : sama dengan password keystore

Tanpa secret, workflow tetap membuat debug APK.
