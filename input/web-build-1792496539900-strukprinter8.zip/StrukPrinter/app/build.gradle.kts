plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
dependencies { implementation("com.google.mlkit:text-recognition:16.0.1"); implementation("androidx.core:core:1.12.0") }
android {
    namespace = "com.aquaphone.strukprinter"
    compileSdk = 34
    defaultConfig { applicationId = "com.aquaphone.strukprinter"; minSdk = 21; targetSdk = 34; versionCode = 1; versionName = "1.0"; ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") } }
    buildTypes { debug { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro") } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
