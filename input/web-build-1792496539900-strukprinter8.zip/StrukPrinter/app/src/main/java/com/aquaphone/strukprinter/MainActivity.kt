package com.aquaphone.strukprinter

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import androidx.core.content.FileProvider
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val ACC = 0xFF5046E5.toInt()
    private val BG = 0xFFF3F4F6.toInt()
    private val GRAY = 0xFF6B7280.toInt()
    private lateinit var prefs: SharedPreferences
    private lateinit var rootF: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private lateinit var beam: View
    private var tab = 0
    private var data = LinkedHashMap<String, String>()
    private var adminV = 0L
    private var raw = ""
    private var inFull = false
    private var scanAnim: ObjectAnimator? = null
    private var scanT0 = 0L
    private var holder: FrameLayout? = null
    private var adminTv: TextView? = null
    private var curTitle = "Struk"
    private var fromShare = false
    private lateinit var fName: EditText
    private lateinit var fAddr: EditText
    private lateinit var fFoot: EditText
    private lateinit var fFee: EditText

    private fun dp(i: Int) = (i * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply { setColor(c); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(2), stroke) }
    private fun tv(s: String, sz: Float = 15f, col: Int = 0xFF111827.toInt(), bold: Boolean = false) =
        TextView(this).apply { text = s; textSize = sz; setTextColor(col); if (bold) setTypeface(null, Typeface.BOLD) }
    private fun label(s: String) = tv(s.uppercase(), 12f, GRAY, true).apply { setPadding(0, dp(16), 0, dp(8)) }
    private fun card(stroke: Int = 0) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(Color.WHITE, 18, stroke)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(10)) }
    }
    private fun btn(s: String, fill: Int, fg: Int, f: () -> Unit) = Button(this).apply {
        text = s; isAllCaps = false; setTextColor(fg); background = rounded(fill, 14); setOnClickListener { f() }
    }
    private fun field(h: String, v: String, multi: Boolean = false) = EditText(this).apply {
        hint = h; setText(v); background = rounded(Color.WHITE, 14); setPadding(dp(14), dp(12), dp(14), dp(12))
        if (multi) { minLines = 2; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE }
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(8)) }
    }
    private fun watch(f: () -> Unit) = object : TextWatcher {
        override fun afterTextChanged(s: Editable?) { f() }
        override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    }
    private fun page(v: LinearLayout): View { v.setPadding(dp(20), dp(28), dp(20), dp(8)); return ScrollView(this).apply { addView(v) } }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("p", 0)
        rootF = FrameLayout(this).apply { setBackgroundColor(BG) }
        content = FrameLayout(this)
        nav = LinearLayout(this).apply { background = rounded(Color.WHITE, 24); setPadding(dp(8), dp(10), dp(8), dp(10)) }
        listOf("🏠 Beranda", "🖨 Printer", "⚙ Setelan").forEachIndexed { i, s ->
            nav.addView(tv(s, 14f).apply { gravity = Gravity.CENTER; setOnClickListener { show(i) } }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(nav, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(16), dp(4), dp(16), dp(16)) })
        beam = View(this).apply {
            visibility = View.GONE
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0x0000E5FF, 0xAA00E5FF.toInt(), 0x0000E5FF))
        }
        rootF.addView(col, FrameLayout.LayoutParams(-1, -1))
        rootF.addView(beam, FrameLayout.LayoutParams(-1, dp(90)))
        setContentView(rootF)
        show(0); startScan(false); handle(intent)
    }

    override fun onNewIntent(i: Intent) { super.onNewIntent(i); handle(i) }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { if (!inFull) show(tab) }

    override fun onBackPressed() {
        if (inFull) { stopScan(); if (fromShare) finish() else show(0) } else super.onBackPressed()
    }

    // Cahaya memindai dari atas ke bawah (loop = terus berulang selama struk dibaca)
    private fun startScan(loop: Boolean) {
        rootF.post {
            scanAnim?.cancel()
            beam.visibility = View.VISIBLE
            scanAnim = ObjectAnimator.ofFloat(beam, "translationY", -dp(90).toFloat(), rootF.height.toFloat()).apply {
                duration = 1400; repeatCount = if (loop) ObjectAnimator.INFINITE else 1; interpolator = LinearInterpolator()
                addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { beam.visibility = View.GONE } })
                start()
            }
        }
    }

    private fun stopScan() { scanAnim?.cancel(); beam.visibility = View.GONE }
    private fun fullMode(on: Boolean) { inFull = on; nav.visibility = if (on) View.GONE else View.VISIBLE }

    private fun show(i: Int) {
        stopScan(); fullMode(false); holder = null; adminTv = null
        tab = i
        content.removeAllViews()
        content.addView(when (i) { 0 -> home(); 1 -> printerTab(); else -> settings() }, FrameLayout.LayoutParams(-1, -1))
        for (k in 0 until nav.childCount) (nav.getChildAt(k) as TextView).apply { setTextColor(if (k == i) ACC else GRAY); setTypeface(null, if (k == i) Typeface.BOLD else Typeface.NORMAL) }
    }

    // ---------- Beranda: riwayat cetak ----------
    private fun hist() = JSONArray(prefs.getString("hist", "[]"))
    private fun addHist(t: String, m: Map<String, String>, a: Long) {
        val h = hist(); val n = JSONArray()
        n.put(JSONObject().put("t", t).put("d", SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())).put("m", JSONObject(m)).put("a", a))
        for (i in 0 until minOf(h.length(), 49)) n.put(h.get(i))
        prefs.edit().putString("hist", n.toString()).apply()
    }

    private fun openHist(o: JSONObject) {
        val m = o.optJSONObject("m") ?: return
        data = LinkedHashMap(); m.keys().forEach { data[it] = m.getString(it) }
        raw = ""; adminV = o.optLong("a"); curTitle = o.getString("t"); fromShare = false; showPreview()
    }

    private fun home(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        v.addView(tv("Printer Struk", 26f, bold = true))
        val pn = prefs.getString("pname", null)
        v.addView(tv(if (pn != null) "● $pn" else "● Belum ada printer", 14f, if (pn != null) 0xFF10B981.toInt() else GRAY, true))
        v.addView(label("Riwayat Cetak"))
        val a = hist()
        if (a.length() == 0) v.addView(tv("Belum ada riwayat. Bagikan struk dari BRImo ke aplikasi ini.", 14f, GRAY))
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            v.addView(card().apply {
                addView(tv(o.getString("t"), 17f, bold = true)); addView(tv(o.getString("d"), 13f, GRAY))
                setOnClickListener { openHist(o) }
            })
        }
        return page(v)
    }

    // ---------- Pratinjau & cetak ----------
    private fun lines() = Receipt.lines(data, adminV, prefs.getString("name", "")!!, prefs.getString("saddr", "")!!, prefs.getString("foot", "")!!)

    // Kertas 32 kolom, sama persis dengan hasil cetak; ukuran otomatis muat satu layar
    private fun paper(ls: List<L>, cwIn: Float? = null, pad: Int = dp(14)): View {
        val pw = resources.displayMetrics.widthPixels - dp(40) - 2 * pad
        val units = ls.sumOf { if (it.big) 4 else 2 }
        val availH = resources.displayMetrics.heightPixels - dp(300) - 2 * pad
        val cw = cwIn ?: minOf(pw / Receipt.W.toFloat(), availH / units.toFloat())
        val p = Paint().apply { typeface = Typeface.MONOSPACE; textSize = 100f }
        val sz = 100f * cw * Receipt.W / p.measureText("M".repeat(Receipt.W)) * 0.99f
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.WHITE, 10); setPadding(pad, pad, pad, pad) }
        for (l in ls) v.addView(TextView(this).apply {
            text = if (l.t.isEmpty()) " " else l.t
            typeface = Typeface.create(Typeface.MONOSPACE, if (l.bold) Typeface.BOLD else Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_PX, if (l.big) sz * 2 else sz)
            setTextColor(Color.BLACK); includeFontPadding = false; setSingleLine(); setHorizontallyScrolling(true); gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams((cw * Receipt.W).toInt(), (cw * 2 * (if (l.big) 2 else 1)).toInt()))
        return v
    }

    private fun redraw() {
        holder?.removeAllViews()
        holder?.addView(paper(lines()), FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_HORIZONTAL))
        adminTv?.text = "Biaya admin: ${Receipt.rp(adminV)}  \u270E"
    }

    private fun showPreview() {
        stopScan(); fullMode(true); content.removeAllViews()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(12)) }
        col.addView(tv("Pratinjau Struk", 20f, bold = true))
        holder = FrameLayout(this)
        col.addView(ScrollView(this).apply { addView(holder) }, LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(8), 0, dp(8)) })
        adminTv = tv("", 15f, ACC, true).apply {
            gravity = Gravity.CENTER; background = rounded(Color.WHITE, 14); setPadding(dp(12), dp(12), dp(12), dp(12)); setOnClickListener { editAdmin() }
        }
        col.addView(adminTv, LinearLayout.LayoutParams(-1, -2))
        val bar = LinearLayout(this)
        fun lp(l: Int) = LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(l, dp(8), 0, 0) }
        bar.addView(btn("\u270E Edit", 0xFFE5E7EB.toInt(), 0xFF111827.toInt()) { editDialog() }, lp(0))
        bar.addView(btn("\u2934 Bagikan", 0xFFE5E7EB.toInt(), 0xFF111827.toInt()) { shareImage() }, lp(dp(8)))
        bar.addView(btn("\uD83D\uDDA8 Cetak", ACC, Color.WHITE) { pickPrinter() }, lp(dp(8)))
        col.addView(bar)
        content.addView(col, FrameLayout.LayoutParams(-1, -1))
        redraw()
    }

    private fun showScanning(bmp: Bitmap) {
        fullMode(true); content.removeAllViews(); scanT0 = System.currentTimeMillis()
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(28), dp(20), dp(20)) }
        col.addView(tv("Membaca struk...", 20f, bold = true))
        col.addView(ImageView(this).apply { setImageBitmap(bmp); scaleType = ImageView.ScaleType.FIT_CENTER; background = rounded(Color.WHITE, 16) },
            LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(0, dp(12), 0, 0) })
        content.addView(col, FrameLayout.LayoutParams(-1, -1))
        startScan(true)
    }

    private fun editAdmin() {
        val f = field("Biaya admin (Rp)", adminV.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        val box = LinearLayout(this).apply { setPadding(dp(20), dp(12), dp(20), 0); addView(f, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(this).setTitle("Biaya admin").setView(box)
            .setPositiveButton("Simpan") { _, _ -> adminV = f.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0; redraw() }
            .setNegativeButton("Batal", null).show()
    }

    private fun editDialog() {
        val ks = listOf("Penerima" to "Nama Tujuan", "Bank" to "Bank Tujuan", "No rekening" to "No. Rekening", "Keterangan" to "Keterangan", "Nominal" to "Nominal")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(12), dp(20), 0) }
        val fs = ks.map { field(it.first, data[it.second] ?: "").also { f -> box.addView(f) } }
        val fa = field("Biaya admin (Rp)", adminV.toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        box.addView(fa)
        AlertDialog.Builder(this).setTitle("Edit struk").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Simpan") { _, _ ->
                ks.forEachIndexed { i, k -> data[k.second] = fs[i].text.toString() }
                adminV = fa.text.toString().filter { it.isDigit() }.toLongOrNull() ?: 0; redraw()
            }.setNegativeButton("Batal", null).show()
    }

    private fun shareImage() {
        try {
            val v = paper(lines(), 12f, 24)
            val u = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            v.measure(u, u); v.layout(0, 0, v.measuredWidth, v.measuredHeight)
            val bmp = Bitmap.createBitmap(v.measuredWidth, v.measuredHeight, Bitmap.Config.ARGB_8888)
            Canvas(bmp).also { it.drawColor(Color.WHITE); v.draw(it) }
            val f = File(cacheDir, "struk.png"); f.outputStream().use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            val send = Intent(Intent.ACTION_SEND).setType("image/png").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                .putExtra(Intent.EXTRA_STREAM, FileProvider.getUriForFile(this, "com.aquaphone.strukprinter.fp", f))
            val ch = Intent.createChooser(send, "Bagikan struk")
            if (Build.VERSION.SDK_INT >= 24) ch.putExtra(Intent.EXTRA_EXCLUDE_COMPONENTS, arrayOf(ComponentName(this, MainActivity::class.java)))
            startActivity(ch)
        } catch (e: Exception) { toast("Gagal bagikan: ${e.message}") }
    }

    // Tombol Cetak: langsung tampil daftar Bluetooth untuk dipilih, lalu dicetak
    private fun pickPrinter() {
        if (needPerm()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return }
        val devs = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }
        val b = AlertDialog.Builder(this).setTitle("Pilih printer Bluetooth")
        if (devs.isEmpty()) {
            b.setMessage("Belum ada printer yang ter-pair. Pair printer dulu di pengaturan Bluetooth.")
                .setPositiveButton("Buka Bluetooth") { _, _ -> startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)) }
        } else {
            val sel = prefs.getString("addr", null)
            b.setItems(devs.map { (if (it.address == sel) "\u2713 " else "") + (it.name ?: it.address) }.toTypedArray()) { _, i ->
                prefs.edit().putString("addr", devs[i].address).putString("pname", devs[i].name ?: devs[i].address).apply()
                doPrint()
            }
        }
        b.setNegativeButton("Batal", null).show()
    }

    private fun needPerm() = Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != 0
    private fun logoFile() = File(filesDir, "logo.png")
    private fun logo(): Bitmap? = if (logoFile().exists()) BitmapFactory.decodeFile(logoFile().path) else null

    private fun doPrint() {
        if (needPerm()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return }
        val addr = prefs.getString("addr", null)
        if (addr == null) { toast("Pilih printer di menu Printer"); return }
        val ls = lines(); val lg = logo(); val title = curTitle; val m = LinkedHashMap(data); val ad = adminV
        Thread {
            try {
                Printer.print(addr, lg, ls); addHist(title, m, ad)
                runOnUiThread { toast("Selesai dicetak"); if (fromShare) finish() else show(0) }
            } catch (e: Exception) { runOnUiThread { toast("Gagal: ${e.message}") } }
        }.start()
    }

    // ---------- Printer ----------
    private fun printerTab(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        v.addView(tv("Koneksi Printer", 24f, bold = true))
        if (needPerm()) { requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 1); return page(v) }
        v.addView(label("Status saat ini"))
        val pn = prefs.getString("pname", null)
        v.addView(card().apply {
            addView(tv("Printer", 18f, bold = true))
            addView(tv(if (pn != null) "● Terpilih: $pn" else "● Belum dipilih", 14f, if (pn != null) 0xFF10B981.toInt() else GRAY))
            val r = LinearLayout(this@MainActivity).apply { setPadding(0, dp(10), 0, 0) }
            r.addView(btn("Hapus", 0xFFFEE2E2.toInt(), 0xFFDC2626.toInt()) { prefs.edit().remove("addr").remove("pname").apply(); show(1) }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, 0, dp(8), 0) })
            r.addView(btn("Test Print", ACC, Color.WHITE) { testPrint() }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(r)
        })
        val h = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        h.addView(label("Perangkat tersedia"), LinearLayout.LayoutParams(0, -2, 1f))
        h.addView(tv("↻ Cari Ulang", 14f, ACC, true).apply { setOnClickListener { show(1) } })
        v.addView(h)
        val devs = try { BluetoothAdapter.getDefaultAdapter()?.bondedDevices?.toList() ?: emptyList() } catch (e: SecurityException) { emptyList() }
        if (devs.isEmpty()) v.addView(tv("Tidak ada perangkat. Pair printer dulu di Bluetooth HP/PDA.", 14f, GRAY))
        val sel = prefs.getString("addr", null)
        for (d in devs) v.addView(card(if (d.address == sel) ACC else 0).apply {
            addView(tv(d.name ?: d.address, 17f, bold = true)); addView(tv(d.address, 13f, GRAY))
            setOnClickListener { prefs.edit().putString("addr", d.address).putString("pname", d.name ?: d.address).apply(); show(1) }
        })
        return page(v)
    }

    private fun testPrint() {
        val addr = prefs.getString("addr", null) ?: run { toast("Pilih printer dulu"); return }
        Thread {
            try { Printer.print(addr, null, listOf(L("TEST PRINT", true), L("PRINTER OK"))); runOnUiThread { toast("Test terkirim") } }
            catch (e: Exception) { runOnUiThread { toast("Gagal: ${e.message}") } }
        }.start()
    }

    // ---------- Setelan ----------
    private fun settings(): View {
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        v.addView(tv("Setelan Struk", 24f, bold = true))
        v.addView(label("Logo"))
        logo()?.let { v.addView(ImageView(this).apply { setImageBitmap(it); background = rounded(Color.WHITE, 14); setPadding(dp(8), dp(8), dp(8), dp(8)); adjustViewBounds = true; maxHeight = dp(90) }, LinearLayout.LayoutParams(-2, -2)) }
        val r = LinearLayout(this)
        r.addView(btn("Pilih Logo", ACC, Color.WHITE) { save(false); startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), 7) }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, dp(6), dp(8), 0) })
        r.addView(btn("Hapus Logo", 0xFFFEE2E2.toInt(), 0xFFDC2626.toInt()) { logoFile().delete(); show(2) }, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(0, dp(6), 0, 0) })
        v.addView(r)
        fName = field("Nama toko", prefs.getString("name", "")!!)
        fAddr = field("Alamat toko", prefs.getString("saddr", "")!!, true)
        fFoot = field("Pesan footer (mis. Terima kasih)", prefs.getString("foot", "")!!, true)
        fFee = field("Biaya admin default (Rp)", prefs.getLong("admin", 0).toString()).apply { inputType = InputType.TYPE_CLASS_NUMBER }
        v.addView(label("Nama toko")); v.addView(fName)
        v.addView(label("Alamat")); v.addView(fAddr)
        v.addView(label("Pesan footer")); v.addView(fFoot)
        v.addView(label("Biaya admin default")); v.addView(fFee)
        v.addView(btn("Simpan", ACC, Color.WHITE) { save(true) }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(12), 0, dp(12)) })
        return page(v)
    }

    private fun save(msg: Boolean) {
        prefs.edit().putString("name", fName.text.toString()).putString("saddr", fAddr.text.toString())
            .putString("foot", fFoot.text.toString()).putLong("admin", fFee.text.toString().toLongOrNull() ?: 0).apply()
        if (msg) toast("Tersimpan")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        super.onActivityResult(rc, res, d)
        if (rc == 7 && res == RESULT_OK && d?.data != null) {
            try {
                val bmp = contentResolver.openInputStream(d.data!!)!!.use { BitmapFactory.decodeStream(it) }
                val sc = minOf(384f / bmp.width, 160f / bmp.height, 1f)
                val out = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).toInt().coerceAtLeast(1), (bmp.height * sc).toInt().coerceAtLeast(1), true)
                logoFile().outputStream().use { out.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } catch (e: Exception) { toast("Logo gagal: ${e.message}") }
        }
        show(2)
    }

    // ---------- Terima share (teks / gambar / PDF) ----------
    @Suppress("DEPRECATION")
    private fun handle(i: Intent) {
        if (i.action != Intent.ACTION_SEND) return
        fromShare = true
        val t = i.getStringExtra(Intent.EXTRA_TEXT)
        if (!t.isNullOrBlank()) { onText(t); startScan(false); return }
        val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        Thread {
            try { val bm = loadBitmap(u); runOnUiThread { showScanning(bm) }; recognize(bm) } catch (e: Exception) { runOnUiThread { toast("Gagal baca: ${e.message}") } }
        }.start()
    }

    private fun onText(t: String) {
        raw = t
        data = Receipt.parse(t)
        if (!data.containsKey("Nama Tujuan") && data.containsKey("Tujuan")) data["Nama Tujuan"] = data["Tujuan"]!!
        curTitle = data["Nama Tujuan"] ?: "Struk"
        adminV = data["Biaya Admin"]?.let { Receipt.num(it) } ?: prefs.getLong("admin", 0)
        showPreview()
    }

    private fun loadBitmap(u: Uri): Bitmap {
        if (contentResolver.getType(u) == "application/pdf") {
            val fd = contentResolver.openFileDescriptor(u, "r")!!
            val r = PdfRenderer(fd); val pg = r.openPage(0)
            val bmp = Bitmap.createBitmap(pg.width * 2, pg.height * 2, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            pg.close(); r.close(); fd.close()
            return bmp
        }
        return contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it) }
    }

    private fun recognize(bmp: Bitmap) {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { res ->
                val ls = res.textBlocks.flatMap { it.lines }.filter { it.boundingBox != null }.sortedBy { it.boundingBox!!.centerY() }
                val rows = ArrayList<MutableList<com.google.mlkit.vision.text.Text.Line>>()
                for (l in ls) {
                    val last = rows.lastOrNull()
                    if (last != null && Math.abs(last[0].boundingBox!!.centerY() - l.boundingBox!!.centerY()) < l.boundingBox!!.height() * 0.6) last.add(l)
                    else rows.add(mutableListOf(l))
                }
                val text = rows.joinToString("\n") { r -> r.sortedBy { it.boundingBox!!.left }.joinToString(" ") { it.text } }
                runOnUiThread { rootF.postDelayed({ onText(text) }, maxOf(0L, 1600 - (System.currentTimeMillis() - scanT0))) }
            }
            .addOnFailureListener { runOnUiThread { toast("OCR gagal: ${it.message}") } }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
