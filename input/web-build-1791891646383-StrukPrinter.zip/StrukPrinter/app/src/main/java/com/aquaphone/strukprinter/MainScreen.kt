package com.aquaphone.strukprinter

import android.Manifest
import android.bluetooth.BluetoothDevice
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

@Composable
fun MainScreen() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("struk", Context.MODE_PRIVATE) }

    var shop by remember { mutableStateOf(prefs.getString("shop", "NAMA TOKO") ?: "") }
    var desc1 by remember { mutableStateOf(prefs.getString("desc1", "") ?: "") }
    var desc2 by remember { mutableStateOf(prefs.getString("desc2", "") ?: "") }
    var tid by remember { mutableStateOf(prefs.getString("tid", "") ?: "") }
    var mac by remember { mutableStateOf(prefs.getString("mac", "") ?: "") }
    var autoOpen by remember { mutableStateOf(prefs.getBoolean("auto_open", false)) }
    var type by remember { mutableStateOf(prefs.getString("type", "auto") ?: "auto") }
    var showOcr by remember { mutableStateOf(false) }

    // State struk berasal dari ReceiptStore (tahan layar ditutup, tersimpan di penyimpanan)
    val receipt = ReceiptStore.receipt
    val page = ReceiptStore.page
    val busy = ReceiptStore.busy
    val status = ReceiptStore.status
    val ocrRaw = ReceiptStore.ocrRaw

    var hasBt by remember { mutableStateOf(hasBtPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasBt = granted }

    var devices by remember { mutableStateOf(emptyList<BluetoothDevice>()) }
    LaunchedEffect(hasBt) { devices = pairedPrinters(ctx) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri -> if (uri != null) ReceiptStore.process(ctx, uri) }

    BackHandler(enabled = page == 2) {
        ReceiptStore.status = ""
        ReceiptStore.goTo(1)
    }

    val scroll1 = rememberScrollState()
    val scroll2 = rememberScrollState()

    Column(Modifier.fillMaxSize()) {

        Column(
            Modifier
                .weight(1f)
                .verticalScroll(if (page == 1) scroll1 else scroll2)
                .padding(16.dp)
        ) {
            if (page == 1) {
                // ---------- HALAMAN 1: PREVIEW + EDIT ----------
                Text("Preview", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                if (receipt != null) {
                    ReceiptPreview(receipt)
                } else {
                    Text(
                        "Belum ada struk. Buka BRImo, pilih riwayat, tekan Bagikan lalu pilih " +
                            "aplikasi ini, atau tekan Pilih gambar struk di bawah.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Spacer(Modifier.height(24.dp))
                Text("Edit", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Jenis struk", style = MaterialTheme.typography.titleMedium)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    listOf("auto" to "Otomatis", "brimo" to "BRImo", "dana" to "DANA")
                        .forEach { (key, label) ->
                            val pick = {
                                type = key
                                prefs.edit().putString("type", key).apply()
                                ReceiptStore.reparse(ctx)   // baca ulang struk yang sedang tampil
                            }
                            Row(
                                Modifier
                                    .weight(1f)
                                    .clickable { pick() },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = type == key, onClick = { pick() })
                                Text(label)
                            }
                        }
                }
                Spacer(Modifier.height(8.dp))
                Button(
                    onClick = { picker.launch("image/*") },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Pilih gambar struk BRImo") }
                Spacer(Modifier.height(8.dp))

                if (receipt != null) {
                    ReceiptFields(receipt) { ReceiptStore.update(it) }
                    TextButton(onClick = { ReceiptStore.clear() }) { Text("Hapus struk ini") }
                }

                Spacer(Modifier.height(8.dp))
                Text("Pengaturan struk", style = MaterialTheme.typography.titleMedium)
                Field("Nama toko", shop) {
                    shop = it
                    prefs.edit().putString("shop", it).apply()
                    ReceiptStore.receipt?.let { r -> ReceiptStore.update(r.copy(shopName = it)) }
                }
                Field("Deskripsi toko - paragraf 1", desc1, minLines = 2) {
                    desc1 = it
                    prefs.edit().putString("desc1", it).apply()
                    ReceiptStore.receipt?.let { r -> ReceiptStore.update(r.copy(desc1 = it)) }
                }
                Field("Deskripsi toko - paragraf 2", desc2, minLines = 2) {
                    desc2 = it
                    prefs.edit().putString("desc2", it).apply()
                    ReceiptStore.receipt?.let { r -> ReceiptStore.update(r.copy(desc2 = it)) }
                }
                Field("TID (opsional)", tid) {
                    tid = it
                    prefs.edit().putString("tid", it).apply()
                    ReceiptStore.receipt?.let { r -> ReceiptStore.update(r.copy(terminalId = it)) }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Buka aplikasi otomatis setelah struk dibagikan dari BRImo",
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Switch(
                        checked = autoOpen,
                        onCheckedChange = {
                            autoOpen = it
                            prefs.edit().putBoolean("auto_open", it).apply()
                        }
                    )
                }

                if (ocrRaw.isNotEmpty()) {
                    TextButton(onClick = { showOcr = !showOcr }) {
                        Text(if (showOcr) "Sembunyikan teks OCR" else "Lihat teks OCR (untuk cek)")
                    }
                    if (showOcr) Text(ocrRaw, style = MaterialTheme.typography.bodySmall)
                }
            } else {
                // ---------- HALAMAN 2: CETAK PRINTER BLUETOOTH ----------
                Text("Cetak", style = MaterialTheme.typography.titleLarge)
                if (receipt != null) {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "${receipt.recipient} - ${rp(receipt.total)}",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }

                Spacer(Modifier.height(16.dp))
                Text("Printer Bluetooth", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                if (!hasBt) {
                    Button(onClick = { permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT) }) {
                        Text("Izinkan akses Bluetooth")
                    }
                } else {
                    if (devices.isEmpty()) {
                        Text(
                            "Belum ada printer yang dipasangkan. Pasangkan dulu di " +
                                "Pengaturan Bluetooth HP, lalu tekan Muat ulang.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    devices.forEach { d ->
                        val select = {
                            mac = d.address
                            prefs.edit().putString("mac", d.address).apply()
                        }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { select() },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = d.address == mac, onClick = { select() })
                            Text(deviceLabel(d))
                        }
                    }
                    OutlinedButton(onClick = { devices = pairedPrinters(ctx) }) { Text("Muat ulang") }
                }
            }
        }

        // ================= Bilah bawah: status + tombol navigasi =================
        Surface(shadowElevation = 8.dp) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {
                if (status.isNotEmpty()) {
                    Text(status, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(8.dp))
                }

                if (page == 1) {
                    Button(
                        enabled = receipt != null && !busy,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            ReceiptStore.status = ""
                            ReceiptStore.goTo(2)
                        }
                    ) { Text("Selanjutnya") }
                } else {
                    Button(
                        enabled = receipt != null && !busy,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            val cur = ReceiptStore.receipt
                            val dev = if (mac.isEmpty()) null else deviceByMac(ctx, mac)
                            if (cur == null) {
                                ReceiptStore.status = "Belum ada struk."
                            } else if (!hasBt) {
                                ReceiptStore.status = "Izinkan akses Bluetooth dulu."
                            } else if (dev == null) {
                                ReceiptStore.status = "Pilih printer dulu."
                            } else {
                                ReceiptStore.print(dev, cur)
                            }
                        }
                    ) { Text("Cetak") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        enabled = !busy,
                        modifier = Modifier.fillMaxWidth(),
                        onClick = {
                            ReceiptStore.status = ""
                            ReceiptStore.goTo(1)
                        }
                    ) { Text("Kembali") }
                }
            }
        }
    }
}
