package com.aquaphone.strukprinter

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.util.Locale
import java.util.UUID

// build.gradle (app):
//   implementation("com.google.mlkit:text-recognition:16.0.1")   // cek versi terbaru
// Manifest: BLUETOOTH_CONNECT + BLUETOOTH_SCAN (Android 12+), BLUETOOTH (Android 11 ke bawah)

/* ------------------------------------------------------------------ */
/* 1. Model data struk (diisi dari OCR, lalu bisa diedit di form)      */
/* ------------------------------------------------------------------ */
data class Receipt(
    val shopName: String = "NAMA TOKO",
    val date: String = "",          // 2026-10-11
    val time: String = "",          // 09:03:00
    val refCode: String = "",
    val bank: String = "BANK BRI",
    val accountNo: String = "",
    val recipient: String = "",
    val amount: Long = 0,
    val admin: Long = 0,
    val desc1: String = "",         // deskripsi toko paragraf 1 (di bawah nama toko)
    val desc2: String = "",         // deskripsi toko paragraf 2
    val thanks: String = "TERIMA KASIH",
    val terminalId: String = ""
) {
    val total: Long get() = amount + admin
}

/* ------------------------------------------------------------------ */
/* 2. Format teks 32 kolom (58mm, Font A 12x24 dot => 384 / 12 = 32)   */
/*    Preview dan cetak memakai daftar Line yang sama => hasil sama.   */
/* ------------------------------------------------------------------ */
const val COLS = 32

/** scale 2 = huruf 2x lebar dan 2x tinggi (hanya muat COLS/2 karakter per baris). */
data class Line(val text: String, val bold: Boolean = false, val scale: Int = 1)

fun rp(n: Long) = "RP " + String.format(Locale.US, "%,d", n).replace(',', '.')

private fun center(s: String, width: Int = COLS): String {
    val t = s.take(width)
    return " ".repeat((width - t.length) / 2) + t
}

/** Bungkus teks per kata agar tiap baris maksimal [width] karakter. */
private fun wrap(text: String, width: Int): List<String> {
    val out = mutableListOf<String>()
    var cur = ""
    for (raw in text.trim().split(Regex("\\s+"))) {
        if (raw.isEmpty()) continue
        var word = raw
        while (word.length > width) {   // pecah kata yang lebih panjang dari lebar baris
            if (cur.isNotEmpty()) { out.add(cur); cur = "" }
            out.add(word.take(width))
            word = word.drop(width)
        }
        cur = when {
            cur.isEmpty() -> word
            cur.length + 1 + word.length <= width -> "$cur $word"
            else -> { out.add(cur); word }
        }
    }
    if (cur.isNotEmpty()) out.add(cur)
    return out
}

/** Kiri-kanan: label di kiri, nilai rata kanan. */
private fun lr(left: String, right: String): String {
    val r = right.take(COLS - 1)
    val l = left.take(COLS - r.length - 1)
    return l + " ".repeat(COLS - l.length - r.length) + r
}

fun Receipt.toLines(): List<Line> = buildList<Line> {
    val eq = "=".repeat(COLS)
    val dash = "-".repeat(COLS)

    // Nama toko: huruf besar 2x (16 karakter per baris)
    wrap(shopName, COLS / 2).forEach { add(Line(center(it, COLS / 2), bold = true, scale = 2)) }
    // Deskripsi toko: 2 paragraf, rata tengah, di bawah nama toko
    listOf(desc1, desc2).map { wrap(it, COLS) }.filter { it.isNotEmpty() }
        .forEachIndexed { i, para ->
            if (i > 0) add(Line(""))
            para.forEach { add(Line(center(it))) }
        }
    add(Line(eq))
    add(Line(lr("TANGGAL", date)))
    add(Line(lr("WAKTU", time)))
    add(Line(dash))
    add(Line(center("KODE REFERENSI")))
    if (refCode.isEmpty()) add(Line(""))
    refCode.chunked(COLS).forEach { add(Line(center(it), bold = true)) }
    add(Line(dash))
    add(Line(center("DATA PENERIMA"), bold = true))
    add(Line(lr("BANK TUJUAN", bank)))
    add(Line(lr("NO REKENING", accountNo)))
    add(Line(lr("PENERIMA", recipient.take(20))))
    add(Line(dash))
    add(Line(lr("NOMINAL", rp(amount))))
    add(Line(lr("ADMIN", rp(admin))))
    add(Line(eq))
    add(Line(lr("TOTAL", rp(total)), bold = true))
    add(Line(eq))
    add(Line(""))
    add(Line(dash))
    add(Line(center("** TRANSAKSI BERHASIL **"), bold = true))
    add(Line(center(thanks), bold = true))
    if (terminalId.isNotBlank()) add(Line(center("TID: $terminalId")))
}.map { it.copy(text = it.text.uppercase()) }

/* ------------------------------------------------------------------ */
/* 3. ESC/POS                                                          */
/* ------------------------------------------------------------------ */
object EscPos {
    private fun bold(on: Boolean) = byteArrayOf(0x1B, 0x45, (if (on) 1 else 0).toByte())
    // GS ! n : 0x11 = lebar 2x + tinggi 2x, 0x00 = normal
    private fun size(scale: Int) = byteArrayOf(0x1D, 0x21, (if (scale >= 2) 0x11 else 0x00).toByte())

    fun build(lines: List<Line>): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1B, 0x40))            // ESC @  : reset printer
        for (l in lines) {
            out.write(size(l.scale))
            out.write(bold(l.bold))                    // ESC E n: bold on/off
            out.write((l.text + "\n").toByteArray(Charsets.US_ASCII))
        }
        out.write(size(1))
        out.write(bold(false))
        out.write(byteArrayOf(0x0A, 0x0A, 0x0A))       // feed 3 baris agar struk bisa disobek
        return out.toByteArray()
    }
}

/* ------------------------------------------------------------------ */
/* 4. Kirim ke printer Bluetooth Classic (SPP)                         */
/*    Panggil dari background thread (Dispatchers.IO), bukan main.     */
/* ------------------------------------------------------------------ */
@SuppressLint("MissingPermission")
fun printBluetooth(device: BluetoothDevice, data: ByteArray) {
    val sppUuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    device.createRfcommSocketToServiceRecord(sppUuid).use { socket ->
        socket.connect()
        socket.outputStream.apply { write(data); flush() }
        Thread.sleep(500) // beri waktu buffer printer sebelum socket ditutup
    }
}

/* ------------------------------------------------------------------ */
/* 5. OCR struk BRImo (gambar hasil Bagikan) -> Receipt                */
/* ------------------------------------------------------------------ */
fun recognizeText(bitmap: Bitmap, onDone: (String) -> Unit, onError: (Exception) -> Unit = {}) {
    TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        .process(InputImage.fromBitmap(bitmap, 0))
        .addOnSuccessListener { onDone(readingOrder(it)) }
        .addOnFailureListener(onError)
}

/** Urutkan baris OCR dari atas ke bawah menurut posisi di gambar (urutan blok bawaan ML Kit bisa acak). */
private fun readingOrder(t: Text): String {
    val sorted = t.textBlocks.flatMap { it.lines }
        .filter { it.boundingBox != null }
        .sortedWith(compareBy<Text.Line>({ it.boundingBox!!.top }, { it.boundingBox!!.left }))
    return if (sorted.isEmpty()) t.text else sorted.joinToString("\n") { it.text }
}

private val MONTHS = mapOf(
    "jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "mei" to 5, "may" to 5,
    "jun" to 6, "jul" to 7, "agu" to 8, "aug" to 8, "sep" to 9,
    "okt" to 10, "oct" to 10, "nov" to 11, "des" to 12, "dec" to 12
)

private val RP = Regex("""\b[Rr][Pp]\s?([\dOo][\dOo.]*)""")

private fun String.toRupiah(): Long =
    replace('O', '0').replace('o', '0').filter { it.isDigit() }.toLongOrNull() ?: 0L

/**
 * Parser berdasarkan layout asli struk BRImo "Transfer Bank BRI":
 *   "11 Oktober 2026, 09:03:10 WIB" / Total Transaksi / No. Ref /
 *   Sumber Dana (pengirim, TIDAK dipakai) / Tujuan (inisial, nama, bank, no rek) /
 *   Nominal / Biaya Admin
 * Dibuat tahan terhadap urutan baris OCR yang kadang tertukar.
 * Jenis transaksi lain (BI-FAST, antarbank, dll) mungkin perlu penyesuaian.
 */
fun parseBrimo(text: String): Receipt {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }

    // Tanggal & jam
    val time = Regex("""\d{2}:\d{2}:\d{2}""").find(text)?.value.orEmpty()
    val date = Regex("""\b(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})""").find(text)?.let { m ->
        val (d, mon, y) = m.destructured
        val mm = MONTHS[mon.lowercase()] ?: return@let ""
        String.format(Locale.US, "%s-%02d-%02d", y, mm, d.toInt())
    }.orEmpty()

    // Nomor referensi (12 digit)
    val ref = Regex("""No\.?\s*Ref\D*(\d{8,})""", RegexOption.IGNORE_CASE)
        .find(text)?.groupValues?.get(1)
        ?: Regex("""\b\d{12}\b""").find(text)?.value.orEmpty()

    // Bagian "Tujuan": [inisial] nama / bank / no rekening
    val t = lines.indexOfFirst { it.equals("Tujuan", ignoreCase = true) }
    val region = if (t >= 0) lines.drop(t + 1) else lines
    val bankIdx = if (t >= 0) region.indexOfFirst { it.startsWith("BANK", ignoreCase = true) }
    else region.indexOfLast { it.startsWith("BANK", ignoreCase = true) }
    val bank = region.getOrNull(bankIdx) ?: "BANK BRI"
    // nama = baris terdekat di atas baris bank (inisial 2-3 huruf diabaikan)
    val recipient = region.take(maxOf(bankIdx, 0))
        .lastOrNull { it.length > 3 && !it.first().isDigit() }
        .orEmpty()
        .ifEmpty {
            if (t < 0) "" else region.firstOrNull {
                it.length > 3 && !it.first().isDigit() && !it.startsWith("BANK", ignoreCase = true)
            }.orEmpty()
        }
    val account = (if (t < 0 && bankIdx < 0) emptyList<String>() else region.drop(maxOf(bankIdx, 0))).firstNotNullOfOrNull { l ->
        Regex("""\d[\d ]{7,}\d""").find(l)?.value?.filter(Char::isDigit)
    }.orEmpty()

    // Nominal: urutan Rp di struk = Total Transaksi, Nominal, Biaya Admin
    val amounts = RP.findAll(text).map { it.groupValues[1].toRupiah() }.toList()

    return Receipt(
        date = date,
        time = time,
        refCode = ref,
        bank = bank.uppercase(),
        accountNo = account,
        recipient = recipient,
        amount = amounts.getOrNull(1) ?: amounts.firstOrNull() ?: 0L,
        admin = amounts.getOrNull(2) ?: 0L
    )
}


/* ------------------------------------------------------------------ */
/* 6. Deteksi jenis struk (BRImo / DANA) + parser DANA                 */
/* ------------------------------------------------------------------ */
/** mode: "auto" (deteksi otomatis), "brimo", atau "dana". */
fun parseReceipt(text: String, mode: String = "auto"): Receipt = when (mode) {
    "brimo" -> parseBrimo(text)
    "dana" -> parseDana(text)
    else -> if (isDana(text)) parseDana(text) else parseBrimo(text)
}

private fun isDana(text: String): Boolean =
    text.contains("Total Bayar", ignoreCase = true) ||
        text.contains("ID DANA", ignoreCase = true) ||
        text.contains("Kirim Uang", ignoreCase = true)

private val DATE_RE = Regex("""\b(\d{1,2})\s+([A-Za-z]{3})[A-Za-z]*\s+(\d{4})""")

private fun parseDate(text: String): String {
    val m = DATE_RE.find(text) ?: return ""
    val (d, mon, y) = m.destructured
    val mm = MONTHS[mon.lowercase()] ?: return ""
    return String.format(Locale.US, "%s-%02d-%02d", y, mm, d.toInt())
}

/** Jam diambil dari baris yang memuat tanggal (menghindari jam di status bar HP). Tanpa detik => :00. */
private fun parseTime(lines: List<String>, text: String): String {
    val src = lines.firstOrNull { DATE_RE.containsMatchIn(it) } ?: text
    val m = Regex("""(\d{1,2}):(\d{2})(?::(\d{2}))?""").find(src) ?: return ""
    val (h, mi, sec) = m.destructured
    return String.format(Locale.US, "%02d:%s:%s", h.toInt(), mi, sec.ifEmpty { "00" })
}

/**
 * Struk DANA "Kirim Uang":
 *   05 Okt 2026 - 09:58 / ID DANA (pengirim, TIDAK dipakai)
 *   Kirim Uang Rp200.000 ke NAMA - BRI ****0534   (kalimat ini bisa terpotong ke 2 baris)
 *   Total Bayar Rp200.000 / Detail Penerima / Nama / Akun Bank / ID Transaksi (angka panjang, 2-3 baris)
 * Nama diambil dari kalimat "Kirim Uang ..." karena kolom "Nama" sering terpotong ke baris kedua.
 */
fun parseDana(text: String): Receipt {
    val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }

    // Kalimat utama
    val hi = lines.indexOfFirst { it.contains("Kirim Uang", ignoreCase = true) }
    val hEnd = lines.indexOfFirst { it.contains("Total Bayar", ignoreCase = true) }
    val headline = if (hi < 0) "" else
        lines.subList(hi, if (hEnd > hi) hEnd else minOf(hi + 3, lines.size)).joinToString(" ")

    var recipient = ""
    var rest = ""
    val keIdx = headline.indexOf(" ke ", ignoreCase = true)
    val dashIdx = headline.lastIndexOf(" - ")
    if (keIdx >= 0 && dashIdx > keIdx) {
        recipient = headline.substring(keIdx + 4, dashIdx).trim()
        rest = headline.substring(dashIdx + 3).trim()           // contoh: BRI ****0534
    }
    // Cadangan: baris "Akun Bank" dan "Nama"
    if (rest.isEmpty()) {
        val bi = lines.indexOfFirst { it.startsWith("Akun Bank", ignoreCase = true) }
        if (bi >= 0) {
            rest = lines[bi].substring("Akun Bank".length).trim()
                .ifEmpty { lines.getOrNull(bi + 1).orEmpty() }
        }
    }
    if (recipient.isEmpty()) {
        val ni = lines.indexOfFirst { it.equals("Nama", ignoreCase = true) }
        if (ni >= 0) recipient = lines.getOrNull(ni + 1).orEmpty()
    }

    // Bank + nomor tersamarkan
    val bm = Regex("""^(.*?)[\s\u2022\u00B7*xX.\-]*?(\d{3,})\s*$""").find(rest)
    val bank = bm?.groupValues?.get(1)?.trim().orEmpty().ifEmpty { rest }
    val digits = bm?.groupValues?.get(2).orEmpty()
    val account = when {
        digits.isEmpty() -> ""
        digits.length <= 6 -> "XXX" + digits.takeLast(4)      // DANA menyamarkan nomor rekening
        else -> digits
    }

    // ID Transaksi: kelompok baris yang seluruhnya angka (nomor panjang terpotong beberapa baris)
    var ref = ""
    val run = StringBuilder()
    for (l in lines + "") {
        val d = l.replace(" ", "")
        if (d.isNotEmpty() && d.all { it.isDigit() }) {
            run.append(d)
        } else {
            if (ref.isEmpty() && run.length >= 16) ref = run.toString()
            run.setLength(0)
        }
    }
    if (ref.isEmpty()) {
        ref = Regex("""ID\s*Transaksi\D*(\d{10,})""", RegexOption.IGNORE_CASE)
            .find(text)?.groupValues?.get(1).orEmpty()
    }

    // Nominal dari kalimat utama, total dari "Total Bayar"; admin = selisihnya
    val amounts = RP.findAll(text).map { it.groupValues[1].toRupiah() }.toList()
    val nominal = RP.find(headline)?.groupValues?.get(1)?.toRupiah() ?: amounts.firstOrNull() ?: 0L
    val ti = lines.indexOfFirst { it.contains("Total Bayar", ignoreCase = true) }
    val totalAmt = listOf(ti, ti + 1, ti - 1)
        .filter { ti >= 0 && it in lines.indices }
        .firstNotNullOfOrNull { i -> RP.find(lines[i])?.groupValues?.get(1)?.toRupiah() }
    val total = totalAmt ?: nominal
    val admin = if (total > nominal) total - nominal else 0L

    return Receipt(
        date = parseDate(text),
        time = parseTime(lines, text),
        refCode = ref,
        bank = bank.uppercase(),
        accountNo = account,
        recipient = recipient,
        amount = nominal,
        admin = admin
    )
}
