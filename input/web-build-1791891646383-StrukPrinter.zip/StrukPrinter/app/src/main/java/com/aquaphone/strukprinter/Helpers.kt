package com.aquaphone.strukprinter

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import androidx.core.content.ContextCompat
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Uri file yang dibagikan lewat menu "Bagikan". */
@Suppress("DEPRECATION")
fun Intent.streamUri(): Uri? =
    if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
    else getParcelableExtra(Intent.EXTRA_STREAM)

/* ---------------- Bluetooth ---------------- */

fun hasBtPermission(ctx: Context): Boolean =
    Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.BLUETOOTH_CONNECT) ==
        PackageManager.PERMISSION_GRANTED

private fun btAdapter(ctx: Context): BluetoothAdapter? =
    ctx.getSystemService(BluetoothManager::class.java)?.adapter

/** Printer yang sudah dipasangkan (paired) di pengaturan Bluetooth HP. */
@SuppressLint("MissingPermission")
fun pairedPrinters(ctx: Context): List<BluetoothDevice> =
    if (!hasBtPermission(ctx)) emptyList()
    else btAdapter(ctx)?.bondedDevices?.sortedBy { it.name ?: it.address }.orEmpty()

fun deviceByMac(ctx: Context, mac: String): BluetoothDevice? =
    runCatching { btAdapter(ctx)?.getRemoteDevice(mac) }.getOrNull()

@SuppressLint("MissingPermission")
fun deviceLabel(d: BluetoothDevice): String = (d.name ?: "Tanpa nama") + " (" + d.address + ")"

/* ---------------- Gambar / PDF + OCR ---------------- */

fun loadBitmap(ctx: Context, uri: Uri): Bitmap? {
    val type = ctx.contentResolver.getType(uri).orEmpty()
    return if (type.contains("pdf", ignoreCase = true)) renderPdfFirstPage(ctx, uri)
    else ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
}

private fun renderPdfFirstPage(ctx: Context, uri: Uri): Bitmap? {
    val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
    try {
        val renderer = PdfRenderer(pfd)
        try {
            if (renderer.pageCount == 0) return null
            val page = renderer.openPage(0)
            try {
                val bmp = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return bmp
            } finally {
                page.close()
            }
        } finally {
            renderer.close()
        }
    } finally {
        pfd.close()
    }
}

suspend fun ocrText(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
    recognizeText(bitmap, { cont.resume(it) }, { cont.resumeWithException(it) })
}
