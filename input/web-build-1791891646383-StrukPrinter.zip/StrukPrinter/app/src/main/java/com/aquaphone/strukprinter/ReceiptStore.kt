package com.aquaphone.strukprinter

import android.bluetooth.BluetoothDevice
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Penyimpan state tingkat aplikasi (bukan milik layar):
 * - OCR dan cetak berjalan di scope aplikasi, jadi tetap jalan walau layar ditutup / di latar belakang.
 * - Hasil disimpan ke penyimpanan, jadi saat aplikasi dibuka lagi struk langsung tampil
 *   tanpa memproses ulang (juga setelah aplikasi dimatikan sistem).
 */
object ReceiptStore {
    var receipt by mutableStateOf<Receipt?>(null)
        private set
    var ocrRaw by mutableStateOf("")
        private set
    var page by mutableStateOf(1)
        private set
    var busy by mutableStateOf(false)
        private set
    var status by mutableStateOf("")

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("struk_state", Context.MODE_PRIVATE)
        prefs = p
        p.getString("receipt", null)?.let { s ->
            runCatching { receipt = fromJson(JSONObject(s)) }
        }
        ocrRaw = p.getString("ocr", "") ?: ""
        page = if (receipt != null) p.getInt("page", 1) else 1
    }

    fun update(r: Receipt) {
        receipt = r
        save()
    }

    fun goTo(p: Int) {
        page = p
        save()
    }

    fun clear() {
        receipt = null
        ocrRaw = ""
        page = 1
        status = ""
        save()
    }

    /** OCR + parse di scope aplikasi. onDone dipanggil di main thread setelah selesai. */
    fun process(ctx: Context, uri: Uri, onDone: ((Boolean) -> Unit)? = null) {
        val app = ctx.applicationContext
        busy = true
        status = "Membaca struk..."
        scope.launch {
            var ok = false
            try {
                val bmp = loadBitmap(app, uri) ?: error("Gambar tidak bisa dibuka")
                val text = ocrText(bmp)
                val p = buildReceipt(app, text)
                ocrRaw = text
                receipt = p
                page = 1
                status = statusFor(p)
                save()
                ok = true
            } catch (e: Exception) {
                status = "Gagal membaca struk: ${e.message}"
            }
            busy = false
            if (onDone != null) withContext(Dispatchers.Main) { onDone(ok) }
        }
    }

    private fun buildReceipt(ctx: Context, text: String): Receipt {
        val sp = ctx.getSharedPreferences("struk", Context.MODE_PRIVATE)
        return parseReceipt(text, sp.getString("type", "auto") ?: "auto").copy(
            shopName = sp.getString("shop", "NAMA TOKO") ?: "",
            desc1 = sp.getString("desc1", "") ?: "",
            desc2 = sp.getString("desc2", "") ?: "",
            terminalId = sp.getString("tid", "") ?: ""
        )
    }

    private fun statusFor(p: Receipt) =
        if (p.refCode.isEmpty() || p.amount == 0L || p.recipient.isEmpty())
            "Sebagian data tidak terbaca. Periksa dan perbaiki di bagian Edit."
        else ""

    /** Baca ulang teks OCR yang tersimpan dengan jenis struk terpilih (tanpa OCR ulang). */
    fun reparse(ctx: Context) {
        if (ocrRaw.isEmpty()) return
        val p = buildReceipt(ctx.applicationContext, ocrRaw)
        receipt = p
        status = statusFor(p)
        save()
    }

    /** Cetak di scope aplikasi (tetap jalan walau layar ditutup). */
    fun print(dev: BluetoothDevice, r: Receipt) {
        busy = true
        status = "Mencetak..."
        scope.launch(Dispatchers.IO) {
            status = try {
                printBluetooth(dev, EscPos.build(r.toLines()))
                "Selesai dicetak."
            } catch (e: Exception) {
                "Gagal mencetak: ${e.message}"
            }
            busy = false
        }
    }

    private fun save() {
        val p = prefs ?: return
        val r = receipt
        val e = p.edit()
        if (r == null) e.remove("receipt") else e.putString("receipt", toJson(r).toString())
        e.putString("ocr", ocrRaw).putInt("page", page).apply()
    }

    private fun toJson(r: Receipt): JSONObject = JSONObject().apply {
        put("shopName", r.shopName)
        put("date", r.date)
        put("time", r.time)
        put("refCode", r.refCode)
        put("bank", r.bank)
        put("accountNo", r.accountNo)
        put("recipient", r.recipient)
        put("amount", r.amount)
        put("admin", r.admin)
        put("desc1", r.desc1)
        put("desc2", r.desc2)
        put("thanks", r.thanks)
        put("terminalId", r.terminalId)
    }

    private fun fromJson(o: JSONObject) = Receipt(
        shopName = o.optString("shopName"),
        date = o.optString("date"),
        time = o.optString("time"),
        refCode = o.optString("refCode"),
        bank = o.optString("bank", "BANK BRI"),
        accountNo = o.optString("accountNo"),
        recipient = o.optString("recipient"),
        amount = o.optLong("amount"),
        admin = o.optLong("admin"),
        desc1 = o.optString("desc1"),
        desc2 = o.optString("desc2"),
        thanks = o.optString("thanks", "TERIMA KASIH"),
        terminalId = o.optString("terminalId")
    )
}
