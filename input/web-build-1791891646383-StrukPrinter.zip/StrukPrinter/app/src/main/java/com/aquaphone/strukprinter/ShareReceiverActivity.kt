package com.aquaphone.strukprinter

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity

/**
 * Penerima menu "Bagikan" tanpa tampilan (transparan). Struk diproses di latar belakang,
 * lalu aplikasi utama tidak perlu dibuka. Saat aplikasi dibuka nanti, hasilnya sudah siap.
 */
class ShareReceiverActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ReceiptStore.init(this)

        val uri = if (savedInstanceState == null && intent?.action == Intent.ACTION_SEND)
            intent.streamUri() else null
        if (uri == null) {
            finish()
            return
        }

        Toast.makeText(this, "Membaca struk...", Toast.LENGTH_SHORT).show()
        ReceiptStore.process(this, uri) { ok ->
            val app = applicationContext
            val autoOpen = app.getSharedPreferences("struk", Context.MODE_PRIVATE)
                .getBoolean("auto_open", false)
            Toast.makeText(
                app,
                if (ok) "Struk siap. Buka Struk Printer untuk mencetak." else "Gagal membaca struk.",
                Toast.LENGTH_LONG
            ).show()
            if (ok && autoOpen) {
                app.startActivity(
                    Intent(app, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                )
            }
            finish()
        }
    }
}
