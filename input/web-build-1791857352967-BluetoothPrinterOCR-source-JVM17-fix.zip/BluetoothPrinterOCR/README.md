# Bluetooth Printer OCR (starter project)

Android Studio project starter for offline OCR, Android image sharing intents, and basic Bluetooth Classic SPP/ESC-POS printing.

## Build
1. Open this folder in Android Studio (recent version).
2. Let Gradle sync and install the Android SDK Platform 35 if prompted.
3. Build > Build APK(s).

## Important limitations
- This is a starter implementation, not a tested release APK. It has not been compiled or tested against a physical printer in this environment.
- OCR uses ML Kit Latin recognition and runs on-device after the dependency/model is available. First-time dependency/model setup may need internet; verify offline behavior on target devices.
- Many 58 mm printers use ESC/POS, but Bluetooth protocols and character encodings vary. UTF-8 may not print Indonesian symbols correctly on some models. Test with your exact printer.
- Screenshot sharing is registered for image/* via Android Sharesheet. Some gallery apps send content as ClipData rather than EXTRA_STREAM; extend handling if needed.
- For Android 12+, Bluetooth permission is requested. Pair the printer from Android system settings first.
