package com.aquaphone.strukprinter

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class L(val t: String, val bold: Boolean = false, val big: Boolean = false)

object Receipt {
    const val W = 32
    private val keys = listOf("Tanggal", "No. Ref", "Jenis Transaksi", "Sumber Dana", "Bank Tujuan",
        "No. Rekening", "Nama Tujuan", "Tujuan", "Keterangan", "Nominal", "Biaya Admin", "Total")

    fun parse(t: String): LinkedHashMap<String, String> {
        val m = LinkedHashMap<String, String>()
        val ls = t.lines().map { it.trim() }.filter { it.isNotEmpty() }
        var i = 0
        while (i < ls.size) {
            val k = keys.firstOrNull { ls[i].startsWith(it, true) }
            if (k != null) {
                var v = ls[i].substring(k.length).trimStart(':', ' ', '\t')
                if (v.isEmpty() && i + 1 < ls.size && keys.none { ls[i + 1].startsWith(it, true) }) v = ls[++i]
                if (!m.containsKey(k)) m[k] = v
            }
            i++
        }
        return m
    }

    fun num(s: String?): Long = s?.substringBefore(',')?.filter { it.isDigit() }?.toLongOrNull() ?: 0L
    fun rp(n: Long) = "RP " + n.toString().reversed().chunked(3).joinToString(".").reversed()

    private fun cen(s: String, w: Int = W) = s.chunked(w).map { " ".repeat((w - it.length) / 2) + it }
    private fun row(k: String, v: String): List<String> =
        if (k.length + 1 + v.length <= W) listOf(k + " ".repeat(W - k.length - v.length) + v)
        else listOf(k) + v.chunked(W).map { " ".repeat(W - it.length) + it }

    // tanggal mentah BRImo -> (tanggal, waktu)
    private fun dt(raw: String?): Pair<String, String> {
        if (raw.isNullOrBlank()) { val n = Date(); return Pair(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(n), SimpleDateFormat("HH:mm:ss", Locale.US).format(n)) }
        val m = Regex("(\\d{1,2}):(\\d{2})(?::(\\d{2}))?").find(raw)
        val time = m?.let { "%02d:%s:%s".format(it.groupValues[1].toInt(), it.groupValues[2], it.groupValues[3].ifEmpty { "00" }) } ?: ""
        val date = raw.replace(m?.value ?: "", "").replace("WIB", "", true).trim(' ', ',', '-', '\u2022')
        return Pair(date.uppercase(), time)
    }

    fun lines(d: Map<String, String>, admin: Long, name: String, addr: String, foot: String): List<L> {
        val o = ArrayList<L>()
        fun rows(k: String, v: String) = row(k, v.uppercase()).forEach { o.add(L(it)) }
        name.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        addr.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it)) } }
        o.add(L(""))
        o.add(L("=".repeat(W))); o.add(L(cen("BUKTI TRANSFER")[0], true)); o.add(L("=".repeat(W)))
        val (tg, wk) = dt(d["Tanggal"])
        rows("TANGGAL", tg); rows("WAKTU", wk); rows("REF", d["No. Ref"]?.ifBlank { "-" } ?: "-")
        o.add(L("")); o.add(L("KEPADA:"))
        listOf("PENERIMA" to (d["Nama Tujuan"] ?: d["Tujuan"] ?: ""), "BANK" to (d["Bank Tujuan"] ?: ""),
            "NO REKENING" to (d["No. Rekening"] ?: ""), "KETERANGAN" to (d["Keterangan"] ?: "").replace("|", " "))
            .filter { it.second.isNotBlank() }.forEach { rows(it.first, it.second.trim()) }
        o.add(L(""))
        val nom = num(d["Nominal"])
        if (admin > 0) { rows("NOMINAL", rp(nom)); rows("BIAYA ADMIN", rp(admin)); o.add(L("")) }
        o.add(L(cen("TOTAL BAYAR")[0], true))
        o.add(L(cen(rp(nom + admin), W / 2)[0], true, true))
        o.add(L("")); o.add(L("-".repeat(W)))
        o.add(L(cen("** TRANSAKSI BERHASIL **")[0], true))
        foot.uppercase().lines().filter { it.isNotBlank() }.forEach { l -> cen(l.trim()).forEach { o.add(L(it, true)) } }
        return o
    }
}
