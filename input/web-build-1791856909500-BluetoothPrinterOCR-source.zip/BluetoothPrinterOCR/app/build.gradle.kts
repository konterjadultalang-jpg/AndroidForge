plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.bluetoothprinterocr"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.bluetoothprinterocr"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1"
    }
}

dependencies {
    implementation("com.google.mlkit:text-recognition:16.0.1")
}
