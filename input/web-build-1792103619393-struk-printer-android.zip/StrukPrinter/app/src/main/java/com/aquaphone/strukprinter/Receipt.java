package com.aquaphone.strukprinter;

/** Data struk yang dicetak. */
public class Receipt {
    public String tanggal = "";
    public String waktu = "";
    public String noref = "";
    public String bank = "";
    public String rek = "";
    public String penerima = "";
    public String jenis = "";
    public long nominal = 0;
    public long admin = 0;
}
