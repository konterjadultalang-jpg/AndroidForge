# Printer Struk (Android)

Aplikasi cetak struk riwayat BRImo ke printer Bluetooth 58mm, dengan format seperti trfbt.

## Cara pakai
1. Pasangkan printer 58mm lewat pengaturan Bluetooth HP.
2. Buka aplikasi, tekan **Pengaturan**, lalu **Pilih printer Bluetooth**. Isi juga nama toko dan deskripsinya.
3. Di BRImo, buka riwayat transaksi, tekan **Bagikan**, lalu pilih **Printer Bluetooth**.
4. Preview struk langsung tampil. Ubah biaya admin atau kolom lain bila perlu, lalu tekan **Cetak**.

## Membuat APK lewat GitHub
1. Buat repositori baru di GitHub, lalu unggah seluruh isi folder ini (termasuk folder `.github`).
2. Buka tab **Actions**. Proses **Build APK** berjalan sendiri setelah unggah (atau tekan **Run workflow**).
3. Setelah selesai, buka proses tersebut dan unduh **struk-printer-apk** di bagian Artifacts. Di dalamnya ada `app-debug.apk`.
4. Pasang APK di HP (izinkan pemasangan dari sumber lain).

Paket aplikasi: `com.aquaphone.strukprinter`

## Catatan
- Pembacaan teks struk memakai ML Kit di perangkat, jadi tidak perlu internet.
- Font cetak: DejaVu Sans Mono (lisensi ada di `app/src/main/assets/fonts/DEJAVU-LICENSE.txt`).
- Printer harus tipe Bluetooth klasik (SPP), yang umum pada printer 58mm.
